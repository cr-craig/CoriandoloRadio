#define RADIOTEST_CR_C       ///< file tag

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This files contains code that may be used to perform a radio
*              test of Coriandolo Radio protocol
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2016-07-09
*  @date       last modified by Craig Goldman 2017-09-24
*
*
*  @copyright  Copyright (c) 2016, 2017 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*
*  @details
*  This file contains code for both SENSOR and BASE devices.  It may be used
*  to test hardware modules running the Coriandolo Radio (CR) protocol.
*
*  @brief
*  CR = Coriandolo Radio
*
*/

/* ****************************************************************************
*  SPECIAL DEFINITIONS FOR PC-LINT
*/
// Added to ensure PC-Lint knows correct compiler
#ifndef __CC_ARM
#define __CC_ARM        ///< ARM compiler
#endif


/* ***************************************************************************
*  INCLUDE FILES
*/
#include <stdint.h>
#include <stdbool.h>
#include "nrf.h"
#include "../CR/CR.h"
#include "../CR/CrDeviceId.h"
#include "../CR/CR_PublicTypes.h"

/// @note THIS FILE USES "CR SIMPLE" WRAPPER
#include "../CrWrappers/CrSimple.h"


/** ***************************************************************************
*  DOCUMENTATION
*
*  @details
*  This code is designed to test Coriandolo Radio connectivity.
*  This code uses the "CrSimple" wrapper for the protocol; this makes the code 
*  easier to read (and modify).  See "CrSimple.c" for information on the API and
*  the limitations.
*
*  The SENSOR device will "blink" the LED once for every message transmitted and
*  "exchanged"; the LED will not "blink" for an Announcement.  The BASE device 
*  will "blink" the LED for each message received including the Announcement.
*  Under ideal conditions, the BASE device will blink one more time than the 
*  SENSOR device.
*
*  The SENSOR device builds CONST_NUM_TX_MSGS messages to transmit; these 
*  messages are small; they contain the standard CR message header (length byte
*  and a 3-byte Device Identifier) plus 4 additional bytes.
*
*  Neither the BASE devices nor the SENSOR device checks the content of the 
*  received messages.  However, the radio hardware automatically adds a 32-bit 
*  CRC to the transmitted message and checks it on reception.  Coriandolo Radio
*  protocol declares a message as "received" only if the CRC is correct.
*
*  @note
*  This test code was designed to demostrate Coriandolo Radio connectivity.  It
*  should not be used as a guide to performance.  The packets transmitted are
*  small and do not reflect typical usage.  The code performs "busy waits" while
*  blinking the LED.
*
*/


/*  **************************************************************************/
/** ***************************************************************************
*  CONFIGURATION CONSTANTS TO SELECT BASE OR SENSOR DEVICE
*
*  @note
*  The programmer must elect to define exactly one of the two constants 
*  CONFIG_BASE_CODE or CONFIG_SENSOR_CODE.  The other definition should be
*  commented out or removed.
*
*/
#define CONFIG_BASE_CODE
// #define CONFIG_SENSOR_CODE

#if defined(CONFIG_SENSOR_CODE) && defined(CONFIG_BASE_CODE)
    ERROR. PROGRAMMER MUST DEFINE EITHER CONFIG_SENSOR_CODE OR CONFIG_BASE_CODE, NOT BOTH
#endif


/*  **************************************************************************/
/** ***************************************************************************
*  CONFIGURATION CONSTANTS TO SELECT "LED" OUTPUT PIN
*
*  This value is application hardware dependent.
*  The code allows for the programmer to conviently set a different LED pin
*  value for BASE and SENSOR.  The two values may be the same
*
*  @note
*  The value of CONFIG_PIN_OUTPUT_LED is the microprocessor port pin and has
*  a value of 1 to 32 inclusive.  This is NOT the pin number on the microprocessor
*  package NOR is it the pin number of the Coriandolo Radio module.
*/
#if defined CONFIG_BASE_CODE
#define CONFIG_PIN_OUTPUT_LED          ( 15u)  ///< Port Pin number for LED

#elif defined CONFIG_SENSOR_CODE
#define CONFIG_PIN_OUTPUT_LED          ( 15u)  ///< Port Pin number for LED

#else
   ERROR. Exactly one of CONFIG_BASE_CODE or CONFIG_SENSOR_CODE must be defined
#endif


/*  **************************************************************************/
/** ***************************************************************************
*  CONFIGURATION CONSTANT FOR SENSOR DEVICE IDENTIFIER
*
*  @note
*  The defined value for the Sensor Device Identifier can be left unchanged.
*  It needs to be modified only if more than one SENSOR device will 
*  participate in the testing.
*
*  BASE devices do not use a device identifier at this time.
*/
#define CONFIG_SENSOR_DEVICEID         (0x00440004uL) ///< Default Sensor Device Identifier

   
/** ***************************************************************************
*  DEFINED CONSTANTS
*
*  @note
*  These constants have been chosen to demonstate Coriandolo Radio connectivity.
*  They apply to both BASE and SENSOR code.  They should not need to be modified
*  by the programmer.
*/
#define CONST_NUM_RX_BUFRS    ( 9)   ///< number of receive buffers; should be >0 and <=9
#define CONST_NUM_TX_MSGS     ( 8)   ///< number of transmit message buffers;
                                     ///  CR limits the number of messages that
                                     ///  can be transmitted in a single exchange


#define CONST_RX_BUFR_SIZE    (254)  ///< maximum bytes that can be received
                                     ///  this includes "size" byte and "Device Id"
#define CONST_TX_MSG_MAXSIZE  ( 10)  ///< maximum bytes in tx message;
                                     ///  this includes "size" byte and "Device Id"


/* ***************************************************************************
*  PRIVATE VARIABLES
*/
static uint8_t rxBufr[CONST_NUM_RX_BUFRS][CONST_RX_BUFR_SIZE];

// Transmit messages only used by SENSOR code
#ifdef CONFIG_SENSOR_CODE
static uint8_t txMsgD[CONST_NUM_TX_MSGS][CONST_TX_MSG_MAXSIZE];
#endif


/* ***************************************************************************
*  PROTOTYPES FOR SENSOR AND BASE DEVICE TEST CODE
*/
#ifdef CONFIG_BASE_CODE
static void  RadioTest_BaseListen( void);
#endif

#ifdef CONFIG_SENSOR_CODE
static void  RadioTest_SensorAnnounce( uint32_t mySensorId);
static void  RadioTest_SensorTxMsg_InitAll( uint32_t mySensorId);
#endif


/* ***************************************************************************
*  PROTOTYPE FOR MAIN
*/
int32_t  main(void);


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE PROCEDURES
*/
static void     RadioTest_GPIO_Init( void);
static void     RadioTest_LED_DelayOff( uint32_t ticksStart, uint32_t ticksDelay);
static void     RadioTest_LED_Off( void);
static uint32_t RadioTest_LED_On( void);
static __INLINE uint32_t RadioTest_TicksDelta( const uint32_t ticksStart,
                                               const uint32_t ticksStop, 
                                               const uint32_t ticksMask);   
static void     RadioTest_Timer_Init( void);
static uint32_t RadioTest_Timer_Read( void);
static uint32_t RadioTest_Timer_TicksAfterStart( uint32_t ticksStart);



/*  **************************************************************************/
/** ***************************************************************************
*   MAIN TEST CODE
*   @returns     void
*
*   @note
*   This test Code uses the CrSimple wrapper.
*
*   @details
*   Initialize the Clocks, GPIO and Timer.  Disable the CR protocol (in case
*   it was already enabled), then enable CR Protocol.
*   Execute the Radio Test for Sensor or Base.
*/
#ifdef CONFIG_BASE_CODE
int32_t  main( void)
{
   uint32_t  ticksStart;
   // Initialize
   RadioTest_GPIO_Init();
   RadioTest_Timer_Init();
   CrSimple_Disable();
   // Enable the device as a BASE
   (void)CrSimple_EnableAsBase( (uint8_t*)rxBufr, 
                                (CONST_RX_BUFR_SIZE * CONST_RX_BUFR_SIZE),
                                CONST_RX_BUFR_SIZE);
   // Turn on LED for five seconds (5 million ticks) to show hardware starting
   ticksStart = RadioTest_LED_On();
   RadioTest_LED_DelayOff( ticksStart, 5000000uL);
   // The BASE device needs no transmit messages to "run" this test.  All
   //    messages from the SENSOR will be replied to with a Default Acknowledge
   //    message.
   // FOREVER LOOP
   while( 1)
   {
      // Start BASE device listening
      //   (it's ok to call this even if BASE is already listening)
      RadioTest_BaseListen();
      // BASE device keeps listening even after it returns.
      // BASE listen will stop if the code runs out of receive buffers
      //    (or if explicitly stopped by call to "CrSimple_Listen_Stop")
   }
   // CODE SHOULD NEVER REACH HERE
   // (because code can not reach here, some compilers will generate a warning)
}
#endif

#ifdef CONFIG_SENSOR_CODE
int32_t  main( void)
{
   uint32_t  ticksStart;
   // Initialize
   RadioTest_GPIO_Init();
   RadioTest_Timer_Init();
   CrSimple_Disable();
   // Enable the device as a SENSOR
   (void)CrSimple_EnableAsSensor( CONFIG_SENSOR_DEVICEID, 
                                  (uint8_t*)rxBufr, 
                                  (CONST_RX_BUFR_SIZE * CONST_RX_BUFR_SIZE),
                                  CONST_RX_BUFR_SIZE);
   // Turn on LED for five seconds (5 million ticks) to show hardware starting
   ticksStart = RadioTest_LED_On();
   RadioTest_LED_DelayOff( ticksStart, 5000000uL);
   // Initialize SENSOR transmit messages
   RadioTest_SensorTxMsg_InitAll( CONFIG_SENSOR_DEVICEID);
   // FOREVER LOOP
   while( 1)
   {
      // Gets Ticks value for top of loop
      ticksStart = RadioTest_Timer_Read();
      // Perform a CR Radio Announcement
      RadioTest_SensorAnnounce( CONFIG_SENSOR_DEVICEID);
      // Delay in loop until 5 seconds (5 million ticks) from start has passed
      while( RadioTest_Timer_TicksAfterStart( ticksStart) < 5000000uL)
      {
         (void)__NOP;
      }
      // end of loop    
   }
   // CODE SHOULD NEVER REACH HERE
   // (because code can not reach here, some compilers will generate a warning)
}
#endif


/* ***************************************************************************/
/* ***************************************************************************
*  BASE AND SENSOR RADIO TEST PROCEDURES
*/

#ifdef CONFIG_BASE_CODE
/** ***************************************************************************
*  RADIOTEST BASE LISTEN
*
*  Starts the BASE device listening for SENSOR messages.
*  If a message is received, the code "pulses" the LED once, then enters loop 
*  to attempt to read additional messages and generate additional LED pulses.
*  @returns     void
*
*  @note
*  The code delays while "pulsing" the LED for the first received message.
*  This allows plenty of time for additional messages to be received as part of
*  the Listen Exchange.
*
*  @note
*  The CR code will ignore a call to start a BASE device listening, if the
*  device is not IDLE (already listening or actively transmitting or receiving 
*  messages).

*/
static void RadioTest_BaseListen( void)
{
   int32_t  indx;
   bool msgBytesRcvd;
   uint32_t ledOnTime;
   uint8_t rxMsgBytes[CONST_RX_BUFR_SIZE];
   // Start BASE device listening (ignore return value)
   (void)CrSimple_Listen_Start();
   // Check receive buffers for a received message.
   //    Code will try to copy contents of rx message one at-a-time up to 
   //    number of receive buffers plus 1 (as a test check)
   // NOTE: code does not need to check Device Identifier in received message;
   //       for this test the BASE device will accept messages from any SENSOR.
   for( indx = 0; indx < (CONST_NUM_RX_BUFRS + 1); indx +=1)
   {
      msgBytesRcvd = CrSimple_Msg_CopyRcvd( rxMsgBytes, 
                                            CONST_DEVICEID_ALWAYS_MATCH, 
                                            CONST_RX_BUFR_SIZE);
      if( msgBytesRcvd == true)
      {
         // Message must have been received.
         // CrSimple wrapper takes care of Rx Buffer management
         // Code is not interested in contents, but needs to indicate that a
         //    message was received successfully
         // Turn on LED and save time, turn off LED after 1/8th second
         ledOnTime = RadioTest_LED_On();
         RadioTest_LED_DelayOff( ledOnTime, 125000uL);
         // Wait a total of 400 milliseconds from "LED On Time"
         //    (additional 275 milliseconds)
         while( RadioTest_Timer_TicksAfterStart( ledOnTime) < 400000uL)
         {
            (void)__NOP;
         }
      }
      // end of 'indx' loop
   }
   // No transmit messages from BASE to add or remove for this test.
   // BASE device sends "Default Ack" messages to SENSOR during message exhange
   // done
   return;
}
#endif


#ifdef CONFIG_SENSOR_CODE
/** ***************************************************************************
*  RADIOTEST SENSOR ANNOUNCE
*
*  Executes one SENSOR Announcement and associated Exchange.
*  "Pulses" the LED once for each transmitted message that was "Exchanged".
*  @returns     void
*
*  @details
*  Immediately causes a SENSOR Announcement.  The code "CrSimple_AnnounceNow"
*  transmits a default announcement, waits for a response from the BASE and, if
*  a response is received, begins an "Exchange" of messages with the BASE.
*  The return from "CrSimple_AnnounceNow" indicates that the Announcement and
*  any exchange of messages has been completed.
*
*  After the message exchange is complete, this code then processes all of the 
*  transmit messages that have been marked as SENT by CR.  The function 
*  "CrSimple_Msg_GetSent" will return a non-null pointer to any message that 
*  has been sent AND remove it from the CR transmit buffers.  If a non-null 
*  pointer has been returned, the LED blinks once.  The loop repeats the call 
*  to "CrSimple_Msg_GetSent" for the maximum possible number of transmit 
*  messages.
*
*  @note
*  This code uses "CrSimple_Msg_SetReadyToSend" from the "CrSimple" protocol 
*  wrapper to put a message in one of the CR transmit buffers.  The CrSimple
*  wrapper always uses the AUTO RETRY transmit flag when sending SENSOR 
*  messages.  Because of this, all transmitted messages marked as 
*  SENT (message pointer returned by "CrSimple_Msg_GetSent") have been 
*  "Exchanged".
*
*  @note
*  For every message that is sent and exchanged, the code modifies byte 5 of  
*  the message by incrementing it.  This is a convenient way of marking 
*  transmit messages so each message is somewhat different and is helpful if 
*  more detailed investigation of the radio communication process is desired.
*/
static void RadioTest_SensorAnnounce( uint32_t mySensorId)
{
   int32_t  indx;
   bool msgBytesRcvd;
   uint8_t* sentMsgPtr;
   uint32_t ledOnTime;
   uint8_t rxMsgBytes[CONST_RX_BUFR_SIZE];
   // Announce Now (ignore return value)
   (void)CrSimple_AnnounceNow();
   // At this point, the Sensor Announcement and Exchange (if any) has completed.
   // Check status of transmitted messages; blink LED once for every exchanged
   //   message.  "Exchanged message" means a message was received from the 
   //   BASE after the message was transmitted, so the BASE must have received 
   //   the tmessage.
   //   
   for( indx = 0; indx < CONST_NUM_TX_MSGS; indx +=1)
   {
      // Try to get a transmit message marked as "Sent"
      sentMsgPtr = CrSimple_Msg_GetSent( mySensorId, CONST_NULLPTR);
      if( sentMsgPtr != CONST_NULLPTR)
      {
         // Message was sent.
         // Because of CrSimple - all messages marked as Sent have been exchanged
         // (There is no need to check "Exchange Status" value.)
         // Turn on LED and save time, turn off LED after 1/8th second
         ledOnTime = RadioTest_LED_On();
         RadioTest_LED_DelayOff( ledOnTime, 125000uL);
         // Modify byte offset 5 in message (just to keep messages different)
         sentMsgPtr[ 5] +=1u;
         (void)CrSimple_Msg_SetReadyToSend( sentMsgPtr, eADDMSGMODE_IF_NOTFULL);
         // Wait a total of 400 milliseconds from "LED On Time"
         //   -- additional 275 milliseconds
         while( RadioTest_Timer_TicksAfterStart( ledOnTime) < 400000uL)
         {
            (void)__NOP;
         }
      }
      // end of 'indx' loop
   }
   // To make this simple...
   //   copy all received messages into dummy bytes; stop when no more received
   //   messages; this makes the receive buffers buffers ready.
   msgBytesRcvd = true;
   for( indx = 0; (indx < CONST_NUM_RX_BUFRS) && (msgBytesRcvd == true); indx +=1)
   {
      msgBytesRcvd = CrSimple_Msg_CopyRcvd( rxMsgBytes, 
                                            CONST_DEVICEID_ALWAYS_MATCH, 
                                            CONST_RX_BUFR_SIZE);
   }
   // done
   return;
}

/** ***************************************************************************
*  RADIOTEST SENSOR TRANSMIT MESSAGE INITIALIZE ALL
*  Initializes all the SENSOR transmit messages and "adds" them to CR
*  @returns     uint32_t that represents the LED on time in ticks
*  @param[in]   mySensorId - CR Device Identifier for Sensor
*
*  @details
*  The contents of the transmit messages are not really important for this test.
*  They contain the size, the 3-byte deviceId, byte for counter, byte for 
*  txMsgD index, '*'.
*/
static void RadioTest_SensorTxMsg_InitAll( uint32_t mySensorId)
{
   int32_t indx;
   // Initialize SENSOR transmit messages
   //   nothing special, 
   for( indx=0; indx<CONST_NUM_TX_MSGS; indx+=1)
   {
      // Set "payload" of TxMsg
      // Use byte '4' as a spare - set to 0x00
      txMsgD[indx][4] = (uint8_t)0u;
      // Use byte '5' as a counter (just for fun, no real significance)
      txMsgD[indx][5] = (uint8_t)1u;
      txMsgD[indx][6] = (uint8_t)indx;
      txMsgD[indx][7] = (uint8_t)'*';
      // Set "header" of TxMsg - length byte and Device Identifier
      //  -- first byte is length of message not including first byte
      //     in this case it is 3 bytes for DeviceId and 4 other bytes
      txMsgD[indx][0] = (uint8_t)7u;
      (void)CrDeviceId_PutBytes( mySensorId, &txMsgD[indx][1]);
      // Make it "ready" to transmit
      (void)CrSimple_Msg_SetReadyToSend( txMsgD[indx], eADDMSGMODE_IF_NOTFULL);
   }
   // done
   return;
}
#endif


/* ***************************************************************************/
/* ***************************************************************************
*  PRIVATE PROCEDURES -- in alphabetical order
*/

/** ***************************************************************************
*  RADIOTEST GPIO INIT
*
*  Initializes the GPIO ports used by the Speed Test
*  @returns     void
*/
static void RadioTest_GPIO_Init( void)
{
   uint32_t pinInfo;
   // LED
   //   initial output value is low (for LED off)
   //   pin configured with input feedback disconnected, no input resistors
   //   pin configured as push-pull output
   RadioTest_LED_Off();
   // Create Pin Input info
   pinInfo = ( ((uint32_t)GPIO_PIN_CNF_INPUT_Disconnect << GPIO_PIN_CNF_INPUT_Pos) |
               ((uint32_t)GPIO_PIN_CNF_PULL_Disabled << GPIO_PIN_CNF_PULL_Pos)  |
               ((uint32_t)GPIO_PIN_CNF_SENSE_Disabled << GPIO_PIN_CNF_SENSE_Pos)
             );
   // Create Pin Output info
   pinInfo |=  ( ((uint32_t)GPIO_PIN_CNF_DIR_Output << GPIO_PIN_CNF_DIR_Pos) |
                 ((uint32_t)GPIO_PIN_CNF_DRIVE_S0S1 << GPIO_PIN_CNF_DRIVE_Pos)
               );
   // Set Pin Configuration
   NRF_GPIO->PIN_CNF[CONFIG_PIN_OUTPUT_LED] = pinInfo;
   // done
   return;
}




/** ***************************************************************************
*  RADIO TEST LED DELAY OFF
*
*  Turns on the LED for a specified number of clock 'ticks'.
*  Code "loops" until time to turn LED "off"
*  @returns     void
*  @param[in]   ticksStart - 32-bit value
*  @param[in]   ticksDelay - 32-bit value for time LED is on
*
*  @note
*  To turn off LED immediately, call "RadioTest_LED_DelayOff( 0uL, 0uL);"
*/
static void  RadioTest_LED_DelayOff( uint32_t ticksStart, uint32_t ticksDelay)
{
   uint32_t ticksAfterStart;
   ticksAfterStart = RadioTest_Timer_TicksAfterStart( ticksStart);
   while( ticksAfterStart < ticksDelay)
   {
      ticksAfterStart = RadioTest_Timer_TicksAfterStart( ticksStart);
   }
   // Turn off LED
   RadioTest_LED_Off();
   return;
}


/** ***************************************************************************
*  RADIOTEST LED OFF
*
*  Turns off the LED
*  @returns     void
*/
static void  RadioTest_LED_Off( void)
{
   NRF_GPIO->OUTCLR = (1uL << CONFIG_PIN_OUTPUT_LED);
   return;
}


/** ***************************************************************************
*  RADIOTEST LED ON
*
*  Turns on the LED and returns the start time in Ticks
*  @returns     uint32_t that represents the LED on time in ticks
*/
static uint32_t  RadioTest_LED_On( void)
{
   uint32_t  ticksStart;
   NRF_GPIO->OUTSET = (1uL << CONFIG_PIN_OUTPUT_LED);
   ticksStart = RadioTest_Timer_Read();
   // done
   return ticksStart;
}


/** ***************************************************************************
*  RADIO TEST TIMER TICKS DELTA
*
*  Returns the difference between two "ticks" values using a mask.  The mask
*  allows the timer to be less than 32-bits wide.
*  @returns     uint32_t result of calculation
*  @param[in]   ticksStop  - ending "ticks" value used in calculations
*  @param[in]   ticksStart - starting "ticks" value used in calculations
*  @param[in]   ticksMask  - bit mask of "ticks" counter
*/
static __INLINE uint32_t RadioTest_TicksDelta( const uint32_t ticksStop,
                                               const uint32_t ticksStart, 
                                               const uint32_t ticksMask)
{
   uint32_t result;
   result = ((ticksStop - ticksStart) & ticksMask);
   return result;
}


/** ***************************************************************************
*  RADIOTEST TIMER INIT
*
*  Initializes and Starts the Timer used by the Speed Test
*  @returns     void
*
*  @details
*  Timer 0 is sourced from HFCLK (16 MHz) or HFCLK/16; the source is automatically
*  selected based upon the pre-scaler value.  The timer prescaler is set to 2^4
*  so there is 1 microsecond between 'ticks' (prescaler of 2^4); timer size set
*  to 32-bits.
*
*  @warning
*  On the nRF51 not all timers can be configured for 32-bits; be careful if
*  modifying code to use a different timer.
*/
static void RadioTest_Timer_Init( void)
{
   // Stop Timer, Clear and Configure
   NRF_TIMER0->TASKS_STOP = 1uL;
   NRF_TIMER0->TASKS_CLEAR = 1uL;
   NRF_TIMER0->MODE = (TIMER_MODE_MODE_Timer << TIMER_MODE_MODE_Pos);
   NRF_TIMER0->BITMODE = (TIMER_BITMODE_BITMODE_32Bit << TIMER_BITMODE_BITMODE_Pos);
   NRF_TIMER0->PRESCALER  = (4uL << TIMER_PRESCALER_PRESCALER_Pos);
   // Start Timer
   NRF_TIMER0->TASKS_START = 1uL;
   //done
   return;
}


/** ***************************************************************************
*  RADIO TEST TIMER READ
*
*  Returns the value of the timer
*  @returns     uint32_t value of timer
*
*  @details
*  In the nRF51 architecture, the timer values can not be read directly.  A 
*  capture of the value is forced and then the value of the capture register is
*  returned.  This function uses CC[0].
*/
static uint32_t RadioTest_Timer_Read( void)
{
   NRF_TIMER0->TASKS_CAPTURE[0] = 1uL;
   (void)__NOP;
   return NRF_TIMER0->CC[0];
}


/** ***************************************************************************
*  RADIO TEST TIMER TICKS AFTER START
*
*  Returns the number of ticks after the "ticks start" value
*  @returns     uint32_t result of calculation
*  @param[in]   ticksStart - starting "ticks" value used in calculations
*
*  @note
*  If this function is passed a 'ticksStart' value equal to zero, the return 
*  value is the current value of the timer.
*
*  @note
*  The function defines a constant variable for timer mask.  The current code
*  uses Timer0, which is 32-bits.  Other timers in the nRF51 may be implemented
*  with less bits.  The timer mask allows for easy use of these "smaller" 
*  timers.  
*/
static uint32_t RadioTest_Timer_TicksAfterStart( uint32_t ticksStart)
{
   uint32_t  result;
   uint32_t  ticksNow;
   const uint32_t cntrMask = 0xFFFFFFFFuL;
   ticksNow = RadioTest_Timer_Read();
   result = RadioTest_TicksDelta( ticksNow, ticksStart, cntrMask);
   // done
   return result;
}


/* ************** END OF FILE   RADIOTEST_CR_C ***************************** */

#ifndef CR_PUBLICTYPES_H
#define CR_PUBLICTYPES_H

/** ********************** FILE HEADER ****************************************
*  @file
*  @brief      CR Public Types - public type definitions for Coriandolo Radio Protocol
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2015-08-10
*  @date       last modified by Craig Goldman 2017-09-16
*
*  @copyright  Copyright (c) 2015, 2016, 2017 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*  @details
*  This file is a public include file for the Coriandolo Radio Protocol.
*  It declares public types that are used with Coriandolo and the CR APIs.
*  Application programs will need to use these type to interface with
*  Coriandolo Radio.
*
*  It should be included in all files.
*
*  @brief
*  CR = Coriandolo Radio
*
*  @warning
*  *** THIS FILE SHOULD NOT BE MODIFIED. ***
*/


/* ***************************************************************************
*  INCLUDE FILE
*/
#include <stdint.h>




/** ***************************************************************************
*  PUBLIC CONSTANT FOR NULL POINTER
*/
#define CONST_NULLPTR        ((void *)0)


/** ***************************************************************************
*  PUBLIC DEFINITION FOR SPECIAL INLINE MACRO
*/
#ifndef __INLINE
#if   defined ( __CC_ARM )
  #define __INLINE           __inline       /*!< inline keyword for ARM Compiler       */

#elif defined ( __ICCARM__ )
  #define __INLINE           inline         /*!< inline keyword for IAR Compiler. Only available in High optimization mode! */

#elif defined ( __GNUC__ )
  #define __INLINE           inline         /*!< inline keyword for GNU Compiler       */

#elif defined ( __TASKING__ )
  #define __INLINE           inline         /*!< inline keyword for TASKING Compiler   */

#endif
#endif


/* ***************************************************************************
*  PUBLIC TYPES
*/
/// @enum crhwtimer_t
/// @brief
/// "Coriandolo Radio Hardware Timer" is an enumerated type that is a list of 
///    acceptable timer hardware modules that can be used by the radio code.
/// @details
///    The code supports only RTC1 as the hardware timer for the radio code.
///    RTC1 is used instead of RTC0 for historical reasons.
/// @warning
///    The Coriandolo Radio code presumes it has total control of the selected
///    hardware timer; it will start, stop and set configuration registers.
/// @note
///    WARNING THIS LIST IS SUBJECT TO CHANGE.
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE.
typedef enum
{
   eCRHWTIMER_ERROR  = 0,
   eCRHWTIMER_RTC1
} crhwtimer_t;


/// @enum crtickscntr_t
/// @brief
/// "Coriandolo Ticks Counter" is an enumerated type that is a list of acceptable
///    timers that can be used to generate a "Ticks Time Stamp" value.
/// @details
///    The application may select the same hardware timer for this enum as 'crhwtimer_t'.
/// @note
///    NUMERICAL VALUES ARE SUBJECT TO CHANGE.
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE.
typedef enum
{
   eCRTICKSCNTR_NONE   = 0,       ///< NO Ticks Counter Selected
   eCRTICKSCNTR_TIMER0_CC0,       ///< Ticks Counter is Timer 0 using CC[0]
   eCRTICKSCNTR_TIMER0_CC1,       ///< Ticks Counter is Timer 0 using CC[1]
   eCRTICKSCNTR_TIMER0_CC2,       ///< Ticks Counter is Timer 0 using CC[2]
   eCRTICKSCNTR_TIMER0_CC3,       ///< Ticks Counter is Timer 0 using CC[3]
   eCRTICKSCNTR_TIMER1_CC0,       ///< Ticks Counter is Timer 1 using CC[0]
   eCRTICKSCNTR_TIMER1_CC1,       ///< Ticks Counter is Timer 1 using CC[1]
   eCRTICKSCNTR_TIMER1_CC2,       ///< Ticks Counter is Timer 1 using CC[2]
   eCRTICKSCNTR_TIMER1_CC3,       ///< Ticks Counter is Timer 1 using CC[3]
   eCRTICKSCNTR_RTC0,             ///< Ticks Counter is RTC0 (doesn't use CC register)
   eCRTICKSCNTR_RTC1,             ///< Ticks Counter is RTC1 (doesn't use CC register)
   eCRTICKSCNTR_TESTDEFAULT       ///< This value is used to force testing of case Default;
                                  ///  it should only be used in test code
} crtickscntr_t;


/// @struct crcntrinfo_t
/// @brief
/// "Coriandolo Radio Counter Information" is a structure describing the hardware
///    counters/timers used by Coriandolo Radio Protocol.
/// @details
///    The 'revision' field allows this structure to be modified in the future.
///    The current value of 'revision' is '0x00000000'
/// @details
///    The field 'crTimerSelect' is an enumerated constant that indicates the timer/
///       counter used by the Coriandolo Radio.
/// @details
///    The field 'crTicksCntrSelect'is an enumerated constant that indicates the
///       timer/counter, which is read by Coriandolo Radio to get the current
//        "Ticks Value".
///       This value refer to the same timer/counter hardware selected by 'crTimerSelect'.
#define CONST_CNTRINFO_REVISION  (0uL)      ///< current revision of 'crcntrinfo_t'
typedef struct
{
   uint32_t      revision;             ///< revision of this structure
   crhwtimer_t   crTimerSelect;        ///< Hardware Timer to be used by CR code
   crtickscntr_t crTicksCntrSelect;    ///< Ticks Timer to be used for CR timestamps
} crcntrinfo_t;


/// @enum crrxflags_t
/// @brief
/// "Coriandolo Radio receive flags" is an an enumerated type for describing
///   receive message options.
/// @note
///    THIS IS A PLACE-HOLDER FOR FUTURE USE.
///
/// @note
///    NUMERICAL VALUES ARE SUBJECT TO CHANGE.
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE.
/// @warning
///    All numerical values of 'crrxflags_t' must fit within 8 bits
///    (i.e. they all must be greater-than or equal-to zero and less-than
///    or equal-to 255).
typedef enum
{
   eCRRXFLAGS_NONE = 0,           ///< No Receive Flags
   eCRRXFLAGS_ERROR               ///< Error value
} crrxflags_t;


/// @enum crstatus_t
/// @brief
/// "Coriandolo Radio Status"is an assessment of the operation of the radio protocol
/// @note
///    NUMERICAL VALUES ARE SUBJECT TO CHANGE.
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE.
typedef enum
{
   eCR_STATUS_ERROR       = 0,    ///< CR Error Detected
   eCR_STATUS_DISABLED,           ///< CR Protocol is Disabled
   eCR_STATUS_IDLE,               ///< CR Protocol is Enabble, but not active
   eCR_STATUS_BASELISTEN,         ///< CR BASE is Listening
   eCR_STATUS_BASEEXCHANGE,       ///< CR BASE is Exchanging messages
   eCR_STATUS_SENSORANNOUNCE,     ///< CR SENSOR is Announcing
   eCR_STATUS_SENSOREXCHANGE      ///< CR SENSOR is Exchanging messages
} crstatus_t;

/// @enum crtxflags_t
/// @brief
/// "Coriandolo Radio transmit flags" is an an enumerated type for describing
///   transmit message options.
/// @note
///    NUMERICAL VALUES ARE SUBJECT TO CHANGE.
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE.
/// @warning
///    All numerical values of 'crtxflags_t' must fit within 8 bits
///    (i.e. they all must be greater-than or equal-to zero and less-than
///    or equal-to 255).
typedef enum
{
   eCRTXFLAGS_NONE               =  0, ///< No Transmit Flags
   eCRTXFLAGS_AUTORETRY          =  1, ///< Automatic retransmit message if not Exchanged
   eCRTXFLAGS_AUTOREMOVE         =  2, ///< Automatic remove of tx message if Exchanged (SENSOR ONLY)
                                       ///  (WARNING no info about tx message is preserved)
   eCRTXFLAGS_AUTORETRYAUTOREMOVE = 3, ///< Both "Auto Retry" and "Auto Remove"
   eCRTXFLAGS_SYNC               = 16, ///< USED FOR CLOCK SYNCHRONIZATION - UNDER DEVELOPMENT
   eCRTXFLAGS_SYNCAUTOREMOVE     = 18, ///< Both "Sync" and "Auto Remove"
   eCRTXFLAGS_ERROR              = 64  ///< Error value
} crtxflags_t;

    
/// @enum crtype_t
/// @brief
/// "Coriandolo Radio type" is an enumerated type describing the role of the 
///    device in the radio protocol.  Currently only two types are supported
///    (plus the error and testing values)
/// @note
///    NUMERICAL VALUES ARE SUBJECT TO CHANGE.
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE.
typedef enum
{
   eCRTYPE_ERROR   = 0,           ///< Error value
   eCRTYPE_BASE    = 1,           ///< CR Device is BASE
   eCRTYPE_SENSOR  = 2,           ///< CR Device is SENSOR
   eCRTYPE_TEST    = 8,           ///< value reserved for testing
   eCRTYPE_MAXVALUE = 0x7FFFFFFF  ///< value to ensure enumerated type is 32 bits
} crtype_t;


/// @enum crdevopt_t
/// @brief
/// "Coriandolo Radio device option" is an enumerated type describing options
///    for the protocol.
/// @note
///    NUMERICAL VALUES ARE SUBJECT TO CHANGE.
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE.
typedef enum
{
   eCRDEVICEOPT_NONE = 0,                   ///< No Device Option
   eCRDEVICEOPT_REMOVE_DEFAULT_ACKS = 1,    ///< SENSOR Option: Automatic removal of default ACKs 
                                            ///                 received from BASE
   eCRDEVICEOPT_AUTOLISTEN_RESUME   = 2,    ///< BASE Option: Automatic start of Listen after
                                            ///               "adding" Rx Buffer
	eCRDEVICEOPT_FASTRADIOSTART       = 256,  ///< Option for nRF52840 device: 
	                                          ///               fast start-up of radio Rx or Tx
   eCRDEVICEOPT_MAXVALUE  = 32767           ///< value to ensure enumerated type is at least 16 bits
} crdevopt_t;


/// @struct deviceinfo_t
/// @brief
/// "Device Information Type" is a structure that contains important information
///    that is needed for initialization of the Coriandolo Radio Protocol values.
/// @details
///    The information in this structure is COPIED on each call to "CR_Enable"
/// @details
///   The 'revision' field allows this structure to be modified in the future.
///   The current value of 'revision' is '0x00000000'
/// @details
///   The "Connection Value" facilitates the use of multiple CR BASE devices in
///   close proximity to each other by distinguishing groups by Radio Addresses.
///   This value should be left at 0xFFFF unless changed by a knowledgable 
///   Application programmer.
/// 
#define CONST_DEVICEINFO_REVISION (0uL)     ///< current revision level of 'deviceinfo_t'
typedef struct
{
   uint32_t    revision;          ///< Revision of Structure
   crtype_t    deviceType;        ///< Type of Device - BASE or SENSOR
   uint32_t    deviceID;          ///< CR Device Identifier
   crdevopt_t  deviceOption;      ///< CR Device Option 
   uint16_t    connectionValue;   ///< CR Connection Value
} deviceinfo_t;



/// @enum exchangestatus_t
/// @brief
/// "Exchange status" is an enumerated type describing the status of Sensor or
///    Base "Message Exchange"
///    This value is usually valid only for a Transmit message and indicates 
///    whether a message was received after a message was transmitted indicating 
///    successful completion of an "exchange".
/// @note
///    NUMERICAL VALUES ARE SUBJECT TO CHANGE.
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE.
/// @warning
///    All numerical values of 'exchangestatus_t' must fit within 8 bits
///    (i.e. they all must be greater-than or equal-to zero and less-than
///    or equal-to 255).
typedef enum
{
   eEXCHANGE_ERROR   = 0,         ///< An error occur, value is invalid
   eEXCHANGE_MSG_RDY,             ///< Msg is ready - no exchange
   eEXCHANGE_NO_RX,               ///< Tx Msg has no corresponding Rx Msg
   eEXCHANGE_RX_RCVD              ///< Tx Msg has a corresponding Rx Msg
} exchangestatus_t;




#endif /* ifndef CR_PUBLICTYPES_H */

/* ************** END OF FILE   CR_PUBLICTYPES_H ************************** */

#ifndef _CALLBACK_H
#define _CALLBACK_H     ///< file tag

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This is the public include file for Callback.c
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2014-12-19
*  @date       last modified by Craig Goldman 2016-09-16
*
*  @copyright  Copyright (c) 2014, 2015, 2016, 2017 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*  @details
*  This file is the public include file for Callback.c; it declares
*  the public type 'callback_t' and a public prototype for the 
*  "Null Callback".
*
*  @brief
*  CR = Coriandolo Radio
*/


/* ***************************************************************************
*  INCLUDE FILE
*/
#include <stdint.h>


/** ***************************************************************************
*  @def NULL_CALLBACK_ARG
*  PUBLIC CONSTANT FOR NULL PARAMETER TO A CALLBACK PROCEDURED
*/
#define NULL_CALLBACK_ARG   (void*)0


/** ***************************************************************************
*  PUBLIC CALLBACK TYPE
*
*  @typedef callback_t
*  @details
*  Callback type is simply a function pointer which has one parameter and
*  no return value.  The paramter is a generic pointer, which can be NULL POINTER,
*  a pointer to a scalar or a pointer to a structure.
*  It is strongly suggested that the parameter point to a STATIC value.
*
*/
typedef void (*callback_t)( void* argPtr);


/* ***************************************************************************
*  PUBLIC PROTOTYPES
*/
void  Callback_InitStatics( void);
void  Callback_Null( void* argPtr);


#endif /* ifndef _CALLACK_H */

/* ************** END OF FILE   CALLBACK_H ********************************* */

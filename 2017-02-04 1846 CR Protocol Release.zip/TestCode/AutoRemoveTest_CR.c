#define AUTOREMOVE_TEST_C

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This files contains code that is used to test the AUTOREMOVE
*              transmit flag in Coriandolo Radio protocol
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2017-01-02
*  @date       last modified by Craig Goldman 2017-02-04
*
*
*  @copyright  Copyright (c) 2017 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*
*  @details
*  This file contains code for a SENSOR to simulate transmission of data 
*  from SENSOR to BASE.  The code contains very simple code to activate
*  a simulated BASE device which will send default acknowledgement messages
*  to the sensor.
*  This code uses the Coriandolo Radio (CR) protocol.
*
*  @brief
*  CR = Coriandolo Radio
*
*  @note
*  This is very simple test code and has little information about using the
*  CR protocol
*/

/* ****************************************************************************
*  SPECIAL DEFINITIONS FOR PC-LINT
*/
// Added to ensure PC-Lint knows correct compiler
#ifndef __CC_ARM
#define __CC_ARM
#endif

// Added to ensure specific Nordic CPU is defined
#ifndef NRF51
#define NRF51
#endif


/* ***************************************************************************
*  INCLUDE FILES
*/
#include <stdint.h>
#include "nrf.h"
#include "../CR/CR.h"
#include "../CR/CrDeviceId.h"
#include "../CR/CR_PublicTypes.h"



/** ***************************************************************************
*  DOCUMENTATION
*
*  @details
*   This is very simple code for testing eCRTXFLAGS_AUTOREMOVE.
*
*  @details
*   The BASE test code does very little.  It receives messages, and replies
*   default Acknowledge message - no transmit messages.  The received messages
*   are manually removed and the empty buffer "added" back.
*   The BASE device blinks once for each message received (including the
*   Announcement message). 
*
*  @details
*   The SENSOR test code builds and "adds" transmit CONFIG_NUM_TX_MSGS messages 
*   to send with eCRTXFLAGS_AUTOREMOVE.  The SENSOR performs an announcement,  
*   then "gets" transmit messages and the exchange status.  Since transmit 
*   messages were sent with eCRTXFLAGS_AUTOREMOVE, no messages in the transmit 
*   buffer should be found with eEXCHANGE_RX_RCVD.  (Such messages should have 
*   been automatically removed.)  If such a messages is found, the LED turns on 
*   and the messaging stops.
*
*   The Announcement should be performed once every four seconds.  The test
*   will continue to run as long as the BASE and SENSOR are active
*
*  @note
*   If the test is running properly, the BASE LED should blink quickly three 
*   times every four seconds (for one Annuncement and two transmit messages).
*   Occaisionally there may be less than three blinks due to corrupted message
*   transmission.
*
*   If the test is running properly, the SENSOR LED should remain off.
*/


/*  **************************************************************************/
/** ***************************************************************************
*  SELECT BASE OR SENSOR CONFIGURATION
*
*  @note
*  Programmer should uncomment EXACTLY ONE of the following definitions.
*  A "test" will generate a compile-time error if both SENSOR and BASE code are
*  defined.
*/
#define CONFIG_BASE_CODE
 #define CONFIG_SENSOR_CODE

#if defined(CONFIG_SENSOR_CODE) && defined(CONFIG_BASE_CODE)
    ERROR. PROGRAMMER MUST DEFINE EITHER CONFIG_SENSOR_CODE OR CONFIG_BASE_CODE, NOT BOTH
#endif


/*  **************************************************************************/
/** ***************************************************************************
*  CONFIGURATION CONSTANTS
*
*  @note
*  CR limits the number of receive buffers and transmit messages that can be
*  "ready" in the system.  These constants can be found in "CrBufr.c".
*  This is open-source code, but the programmer is advised to be careful when
*  changing these constants.
*
*  @warning
*  If changing CONFIG_RX_BUFR_SIZE, it should be set to a value larger than
*  CONFIG_TX_MSG_MAXSIZE.
*
*  @warning
*  CONFIG_TX_MSG_MAXSIZE must be a even number.
*/
#if defined(CONFIG_SENSOR_CODE)
#define CONFIG_NUM_RX_BUFRS    ( 9)  ///< number of receive buffers; should be >0
#define CONFIG_NUM_TX_MSGS     ( 2)  ///< number of transmit message buffers;
                                     ///  CR limits the number of messages that
                                     ///  can be transmitted in a single exchange

#elif defined(CONFIG_BASE_CODE)
#define CONFIG_NUM_RX_BUFRS    ( 9)  ///< number of receive buffers; should be as large as legal
                                     ///  CR limits the number of messages that
                                     ///  can be received in a single exchange
#define CONFIG_NUM_TX_MSGS     ( 1)  ///< number of transmit message buffers;
                                     ///  BASE transmit messages not used in this speed test
                                     ///  The BASE is expected to transmit the Default Ackowledgement

#else
    ERROR. PROGRAMMER MUST DEFINE EITHER CONFIG_SENSOR_CODE OR CONFIG_BASE_CODE
#endif


#define CONFIG_RX_BUFR_SIZE   (254)  ///< maximum bytes that can be received
                                     ///  this includes "size" byte and "Device Id"
#define CONFIG_TX_MSG_MAXSIZE (254)  ///< maximum bytes in tx message;
                                     ///  this includes "size" byte and "Device Id"

#if CONFIG_RX_BUFR_SIZE > 254
   ERROR. CONFIG_RX_BUFR_SIZE MUST BE 254 BYTES OR SMALLER.
#endif

#if CONFIG_TX_MSG_MAXSIZE > 254
   ERROR. CONFIG_TX_MSG_MAXSIZE MUST BE 254 BYTES OR SMALLER.
#endif



/** ***************************************************************************
*  TEST CONSTANTS
*/
#define CONST_PIN_OUTPUT_LED            ( 15u)  ///< Port Pin number for LED


/* ***************************************************************************
*  PRIVATE CONSTANT VARS FOR CORIANDOLO RADIO INITIALIZATION
*/
#define CONST_AUTOREMOVE_TEST_CONNECTION   (0xFFFAu) ///< Connection value for "AutoRemove Test"

#ifdef CONFIG_BASE_CODE
/// CR Device Information
static const deviceinfo_t  myDeviceInfo = 
{
   0uL,                 ///< revision number of structure
   eCRTYPE_BASE,        ///< BASE device
   0x00FFFFFCuL,        ///< Device Identifier
   eCRDEVICEOPT_AUTOLISTEN_RESUME,   ///< Automatically re-start BASE Listen when receive buffer available 
   CONST_AUTOREMOVE_TEST_CONNECTION  ///< Connection value (this should only be modified by advanced users)
};

/// CR Counter Information
/// @note
/// This counter info structure is used by the CR protocol for it's timeout and 
/// timestamps.  The application may use a different counter to measure "ticks"
static const crcntrinfo_t  myCrCntrInfo = 
{
   0uL,                 ///< revision number of structure
   eCRHWTIMER_RTC1,     ///< use RTC1 for hardware timer
   eCRTICKSCNTR_RTC1    ///< use RTC1 for "Ticks" (time stamp)
};
#endif

#ifdef CONFIG_SENSOR_CODE
/// CR Device Information
static const deviceinfo_t  myDeviceInfo = 
{
   0uL,                 ///< revision number of structure
   eCRTYPE_SENSOR,      ///< SENSOR device
   0x00440004uL,        ///< Device Identifier
   eCRDEVICEOPT_REMOVE_DEFAULT_ACKS,   ///< Automatically remove default ACKs from Rx Buffers
                                       ///  (this is not the flag being tested, just a convenient feature)
   CONST_AUTOREMOVE_TEST_CONNECTION    ///< Connection value (this should only be modified by advanced users)
};

/// CR Counter Information
/// @note
/// This counter info structure is used by the CR protocol for it's timeout and 
/// timestamps.  The "Speed Test" application may use a different counter to
/// measure "ticks"
static const crcntrinfo_t  myCrCntrInfo = 
{
   0uL,               ///< revision number of structure
   eCRHWTIMER_RTC1,   ///< use RTC1 for hardware timer
   eCRTICKSCNTR_RTC1  ///< use RTC1 for "Ticks" (time stamp)
};
#endif


/* ***************************************************************************
*  CONFIGURATION FOR ANNOUNCEMENT TIMING
*/
#define CONFIG_TICKS_BETWEEN_ANNOUNCEMENTS  (4000000uL /*4 seconds*/)  ///< microseconds between announcements


/* ***************************************************************************
*  PRIVATE VARIABLES
*/
static uint8_t rxBufr[CONFIG_NUM_RX_BUFRS][CONFIG_RX_BUFR_SIZE];

#ifdef CONFIG_SENSOR_CODE
static uint8_t txMsgD[CONFIG_NUM_TX_MSGS ][CONFIG_TX_MSG_MAXSIZE];
#endif


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE PROCEDURES
*/
static void     RadioTest_Clock_Init( void);
static void     RadioTest_DelayAfterStart( uint32_t ticksStart, uint32_t ticksDelay);
static void     RadioTest_GPIO_Init( void);
static void     RadioTest_LED_DelayOff( uint32_t ticksStart, uint32_t ticksDelay);
static void     RadioTest_LED_Off( void);
static uint32_t RadioTest_LED_On( void);
static void     RadioTest_Timer_Init( void);
static uint32_t RadioTest_Timer_Read( void);
static uint32_t RadioTest_Timer_TicksAfterStart( uint32_t ticksStart);
static __INLINE uint32_t RadioTest_Timer_TicksDelta( const uint32_t ticksStart,
                                                     const uint32_t ticksStop, 
                                                     const uint32_t ticksMask);   

#ifdef CONFIG_SENSOR_CODE
static void     AutoRemoveTest_TxMsg_Fill( uint8_t txMsg[], uint8_t txMsgSize, uint8_t msgCntr);
#endif

/*  **************************************************************************/
/** ***************************************************************************
*   MAIN TEST CODE (for base or sensor)
*   @returns     void
*
*   @details
*   This section contains test code for both BASE and SENSOR
*  (only one should be active).
*
*/
#ifdef CONFIG_BASE_CODE
int  main( void)
{
   int indx;
   uint8_t* rxMsgPtr;
   uint32_t ticksDelayStart;
   // Initialize
   RadioTest_Clock_Init();
   RadioTest_GPIO_Init();
   RadioTest_Timer_Init();
   CR_Disable();
   // Enable the device as a BASE and using RTC1
   (void)CR_Enable( &myDeviceInfo, &myCrCntrInfo);
   // "Add" receive buffer(s) to CR
   for( indx=0; indx<CONFIG_NUM_RX_BUFRS; indx+=1)
   {
      (void)CR_AddRxBufr( rxBufr[indx], CONFIG_RX_BUFR_SIZE);
   }
   // Flash LED for 2 seconds
   ticksDelayStart = RadioTest_LED_On();
   RadioTest_LED_DelayOff( ticksDelayStart, 2000000uL/*two seconds*/);
   // Start BASE Listening (if not already started)
   // -- this needs to be done only once because eCRDEVICEOPT_AUTOLISTEN_RESUME
   CR_Listen();
   // 
   // FOREVER LOOP
   while( 1)
   {
      // Top of Loop
      // Try to fetch a received message
      rxMsgPtr = CR_GetRxMsg( CONST_DEVICEID_ALWAYS_MATCH, CONST_NULLPTR);
      if( rxMsgPtr != CONST_NULLPTR)
      {
         // found received message...
         // Remove message, then "Add" receive buffer back into CR
         // (received messages are not examined by BASE for this test)
         (void)CR_RemoveRxBufr( rxMsgPtr);
         (void)CR_AddRxBufr( rxMsgPtr, CONFIG_RX_BUFR_SIZE);
         // Flash LED on for 100 milliseconds, minimum off for 200 milliseconds
         ticksDelayStart = RadioTest_LED_On();
         RadioTest_LED_DelayOff( ticksDelayStart, 100000uL/*100 milliseconds*/);
         ticksDelayStart = RadioTest_Timer_Read();
         RadioTest_DelayAfterStart( ticksDelayStart, 200000uL/*200 milliseconds*/);
      }
      // bottom of "forever" loop     
   }
   // CODE SHOULD NEVER REACH HERE
}
#endif

#ifdef CONFIG_SENSOR_CODE
int  main( void)
{
   int indx;
   uint8_t  msgCntr;
   uint8_t  msgSize;
   uint8_t* txMsgPtr;
   uint32_t ticksAnnounce;
   uint32_t ticksDelayStart;
   bool     errorFlag;
   crstatus_t       protocolStatus;
   exchangestatus_t exchangeStatus;
   // Initialize
   RadioTest_Clock_Init();
   RadioTest_GPIO_Init();
   RadioTest_Timer_Init();
   CR_Disable();
   // Enable the device as a SENSOR and using RTC1
   (void)CR_Enable( &myDeviceInfo, &myCrCntrInfo);
   // "Add" receive buffer(s) to CR
   for( indx=0; indx<CONFIG_NUM_RX_BUFRS; indx+=1)
   {
      (void)CR_AddRxBufr( rxBufr[indx], sizeof(rxBufr[indx]));
   }
   // Flash LED for 2 seconds
   ticksDelayStart = RadioTest_LED_On();
   RadioTest_LED_DelayOff( ticksDelayStart, 2000000uL/*two seconds*/);
   // Initialize transmit messages using 'msgCntr' to simulate data
   //  and add messages to the Buffers
   for( indx=0; indx<CONFIG_NUM_TX_MSGS; indx+=1)
   {
      msgSize = (uint8_t)CONFIG_TX_MSG_MAXSIZE - (uint8_t)1u;
      AutoRemoveTest_TxMsg_Fill( txMsgD[indx], msgSize, msgCntr);
      (void)CR_AddTxMsg( txMsgD[indx], eCRTXFLAGS_AUTOREMOVE, 
                                       eADDMSGMODE_IF_NOTFULL);
      msgCntr += 1u;
   }
   // Clear Error Flag
   errorFlag = false;
   // LOOP while no error
   while( errorFlag == false)
   {
      // Top of Loop
      // Announce Now
      ticksAnnounce = RadioTest_Timer_Read();
      CR_Announce( CONST_NULLPTR);
      // Wait for Announcement to finish
      protocolStatus = CR_Status_Get();
      while( (protocolStatus == eCR_STATUS_SENSORANNOUNCE) ||
             (protocolStatus == eCR_STATUS_SENSOREXCHANGE) )
      {
         protocolStatus = CR_Status_Get();
      }
      // Announcement complete
      // Check transmitted messages for exchange status
      txMsgPtr = CR_GetTxMsg( myDeviceInfo.deviceID, CONST_NULLPTR, &exchangeStatus);
      for( indx=0; (indx<CONFIG_NUM_TX_MSGS) && (txMsgPtr != CONST_NULLPTR); indx+=1)
      {
         // For each message transmitted...
         if( exchangeStatus == eEXCHANGE_RX_RCVD)
         {
            // Transmit message with exchange status indicating "Exchanged"
            // A transmit message that has been exchanged should not be found.
            // THIS IS AN ERROR CONDITION
            // Set Error Flag
            errorFlag = true;
         }
         else
         {
            // do nothing
         }
      }
      // Remove all transmit message buffers
      //   (some of these will have already been removed)
      //   And put message back, so it can be transmitted again
      //   (no need to reload data)      
      for( indx=0; indx<CONFIG_NUM_TX_MSGS; indx+=1)
      {
         (void)CR_RemoveTxMsg( txMsgD[indx]);
         (void)CR_AddTxMsg( txMsgD[indx], eCRTXFLAGS_AUTOREMOVE, 
                                          eADDMSGMODE_IF_NOTFULL);
      }
      // Wait for time between announcements
      RadioTest_DelayAfterStart( ticksAnnounce, CONFIG_TICKS_BETWEEN_ANNOUNCEMENTS);
      // end of loop while errorFlag is false
   }
   //
   // If code reaches here, error occurred
  (void)RadioTest_LED_On();
   // FOREVER LOOP
   while( 1)
   {
      // do nothing
   }
   // CODE SHOULD NEVER REACH HERE
}
#endif

/* ***************************************************************************/
/* ***************************************************************************
*  PRIVATE PROCEDURES -- in alphabetical order
*/

/** ***************************************************************************
*  RADIO TEST CLOCK INIT
*
*  Initializes and Starts the Crystals and Clocks on CR hardware module
*  @returns     void
*
*  @note
*  Radio hardware requires HFCLK to operate.
*  RTC1 uses LFCLK.
*/
static void RadioTest_Clock_Init( void)
{
   // Set for 16MHz crystal
   NRF_CLOCK->XTALFREQ = CLOCK_XTALFREQ_XTALFREQ_16MHz;
   // Start high-frequency crystal oscillator 
   NRF_CLOCK->EVENTS_HFCLKSTARTED  = 0uL;
   NRF_CLOCK->TASKS_HFCLKSTART = 1uL;
   // Start low-frequency crystal and use as source for LFCLK
   NRF_CLOCK->LFCLKSRC = CLOCK_LFCLKSRC_SRC_Xtal;
   NRF_CLOCK->EVENTS_LFCLKSTARTED = 0uL;
   NRF_CLOCK->TASKS_LFCLKSTART = 1uL;
   // Wait for HFCLK to start
   while( NRF_CLOCK->EVENTS_HFCLKSTARTED == 0uL)
   {
      // do nothing
   }
   // Wait for LFCLK to start
   while( NRF_CLOCK->EVENTS_LFCLKSTARTED == 0uL)
   {
      // do nothing
   }
   // Clocks started
   return;
}


/** ***************************************************************************
*  RADIO TEST DELAY AFTER START
*
*  Code "loops" until delay in ticks has occurred
*  @returns     void
*  @param[in]   ticksStart - 32-bit value
*  @param[in]   ticksDelay - 32-bit value for number ot ticks from 'ticksStart'
*/
static void  RadioTest_DelayAfterStart( uint32_t ticksStart, uint32_t ticksDelay)
{
   uint32_t ticksAfterStart;
   ticksStart = RadioTest_Timer_Read();
   ticksAfterStart = RadioTest_Timer_TicksAfterStart( ticksStart);
   while( ticksAfterStart < ticksDelay)
   {
      ticksAfterStart = RadioTest_Timer_TicksAfterStart( ticksStart);
   }
   // done
   return;
}


/** ***************************************************************************
*  RADIO TEST GPIO INIT
*
*  Initializes the GPIO ports used by the Speed Test
*  @returns     void
*/
static void RadioTest_GPIO_Init( void)
{
   uint32_t pinInfo;
   // LED
   //   initial output value is low (for LED off)
   //   pin configured with input feedback disconnected, no input resistors
   //   pin configured as push-pull output
   RadioTest_LED_Off();
   // Create Pin Input info
   pinInfo = ( ((uint32_t)GPIO_PIN_CNF_INPUT_Disconnect << GPIO_PIN_CNF_INPUT_Pos) |
               ((uint32_t)GPIO_PIN_CNF_PULL_Disabled << GPIO_PIN_CNF_PULL_Pos)  |
               ((uint32_t)GPIO_PIN_CNF_SENSE_Disabled << GPIO_PIN_CNF_SENSE_Pos)
             );
   // Create Pin Output info
   pinInfo |=  ( ((uint32_t)GPIO_PIN_CNF_DIR_Output << GPIO_PIN_CNF_DIR_Pos) |
                 ((uint32_t)GPIO_PIN_CNF_DRIVE_S0S1 << GPIO_PIN_CNF_DRIVE_Pos)
               );
   // Set Pin Configuration
   NRF_GPIO->PIN_CNF[CONST_PIN_OUTPUT_LED] = pinInfo;
   // done
   return;
}


/** ***************************************************************************
*  RADIO TEST LED DELAY OFF
*
*  Turns on the LED for a specified number of clock 'ticks'.
*  Code "loops" until time to turn LED "off"
*  @returns     void
*  @param[in]   ticksStart - 32-bit value
*  @param[in]   ticksDelay - 32-bit value for time LED is on
*
*  @note
*  To turn off LED immediately, call "RadioTest_LED_DelayOff( 0uL, 0uL);"
*/
static void  RadioTest_LED_DelayOff( uint32_t ticksStart, uint32_t ticksDelay)
{
   uint32_t ticksAfterStart;
   ticksAfterStart = RadioTest_Timer_TicksAfterStart( ticksStart);
   while( ticksAfterStart < ticksDelay)
   {
      ticksAfterStart = RadioTest_Timer_TicksAfterStart( ticksStart);
   }
   // Turn off LED
   RadioTest_LED_Off();
   return;
}


/** ***************************************************************************
*  RADIO TEST LED OFF
*
*  Turns off the LED
*  @returns     void
*/
static void  RadioTest_LED_Off( void)
{
   NRF_GPIO->OUTCLR = (1uL << CONST_PIN_OUTPUT_LED);
   return;
}


/** ***************************************************************************
*  RADIO TEST LED ON
*
*  Turns on the LED and returns the start time in Ticks
*  @returns     uint32_t that represents the LED on time in ticks
*/
static uint32_t  RadioTest_LED_On( void)
{
   uint32_t  ticksStart;
   NRF_GPIO->OUTSET = (1uL << CONST_PIN_OUTPUT_LED);
   ticksStart = RadioTest_Timer_Read();
   // done
   return ticksStart;
}


/** ***************************************************************************
*  RADIO TEST TIMER INIT
*
*  Initializes and Starts the Timer used by the Speed Test
*  @returns     void
*
*  @details
*  Timer 0 is sourced from HFCLK (16 MHz) or HFCLK/16; the source is automatically
*  selected based upon the pre-scaler value.  The timer prescaler is set to 2^4
*  so there is 1 microsecond between 'ticks' (prescaler of 2^4); timer size set
*  to 32-bits.
*
*  @warning
*  On the nRF51 not all timers can be configured for 32-bits; be careful if
*  modifying code to use a different timer.
*/
static void RadioTest_Timer_Init( void)
{
   // Stop Timer, Clear and Configure
   NRF_TIMER0->TASKS_STOP = 1uL;
   NRF_TIMER0->TASKS_CLEAR = 1uL;
   NRF_TIMER0->MODE = (TIMER_MODE_MODE_Timer << TIMER_MODE_MODE_Pos);
   NRF_TIMER0->BITMODE = (TIMER_BITMODE_BITMODE_32Bit << TIMER_BITMODE_BITMODE_Pos);
   NRF_TIMER0->PRESCALER  = ((uint32_t)4u << TIMER_PRESCALER_PRESCALER_Pos);
   // Start Timer
   NRF_TIMER0->TASKS_START = 1uL;
   //done
   return;
}


/** ***************************************************************************
*  RADIO TEST TIMER READ
*
*  Returns the value of the timer
*  @returns     uint32_t value of timer
*
*  @details
*  In the nRF51 architecture, the timer values can not be read directly.  A 
*  capture of the value is forced and then the value of the capture register is
*  returned.  This function uses CC[0].
*/
static uint32_t RadioTest_Timer_Read( void)
{
   NRF_TIMER0->TASKS_CAPTURE[0] = 1uL;
   (void)__NOP;
   return NRF_TIMER0->CC[0];
}


/** ***************************************************************************
*  RADIO TEST TIMER TICKS AFTER START
*
*  Returns the number of ticks after the "ticks start" value
*  @returns     uint32_t result of calculation
*  @param[in]   ticksStart - starting "ticks" value used in calculations
*
*  @note
*  If this function is passed a 'ticksStart' value equal to zero, the return 
*  value is the current value of the timer.
*
*  @note
*  The function defines a constant variable for timer mask.  The current code
*  uses Timer0, which is 32-bits.  Other timers in the nRF51 may be implemented
*  with less bits.  The timer mask allows for easy use of these "smaller" 
*  timers.  
*/
static uint32_t RadioTest_Timer_TicksAfterStart( uint32_t ticksStart)
{
   uint32_t  result;
   uint32_t  ticksNow;
   const uint32_t cntrMask = 0xFFFFFFFFuL;
   ticksNow = RadioTest_Timer_Read();
   result = RadioTest_Timer_TicksDelta( ticksNow, ticksStart, cntrMask);
   // done
   return result;
}


/** ***************************************************************************
*  RADIO TEST TIMER TICKS DELTA
*
*  Returns the difference between two "ticks" values using a mask.  The mask
*  allows the timer to be less than 32-bits wide.
*  @returns     uint32_t result of calculation
*  @param[in]   ticksStop  - ending "ticks" value used in calculations
*  @param[in]   ticksStart - starting "ticks" value used in calculations
*  @param[in]   ticksMask  - bit mask of "ticks" counter
*/
static __INLINE uint32_t RadioTest_Timer_TicksDelta( const uint32_t ticksStop,
                                               const uint32_t ticksStart, 
                                               const uint32_t ticksMask)
{
   uint32_t result;
   result = ((ticksStop - ticksStart) & ticksMask);
   return result;
}


#ifdef CONFIG_SENSOR_CODE
/** ***************************************************************************
*   TRANSMIT MESSAGE FILL
*   @returns     void
*
*   @details
*   To make tracking messages easier, the data in each message is a repeated
*   pair of bytes.  The first byte is an 8-bit byte counter and the second
*   byte is an 8-bit message counter.
*   Each transmit message may contain up to 250 data bytes, so the byte counter
*   may range from 0 to 249.  (Assumes CONFIG_TX_MSG_MAXSIZE equals 254.)
*/
static void  AutoRemoveTest_TxMsg_Fill( uint8_t txMsg[], uint8_t txMsgSize, uint8_t msgCntr)
{
   uint32_t byteCntr;
   // Initialize "size" byte
   txMsg[0] = txMsgSize;
   // "Put" device identifier into message starting a byte offset 1
   CrDeviceId_PutBytes( myDeviceInfo.deviceID, &txMsg[1]);
   for( byteCntr = 4u; byteCntr < (uint32_t)CONFIG_TX_MSG_MAXSIZE; byteCntr +=2u)
   {
      txMsg[byteCntr + 0u] = (uint8_t)byteCntr;
      txMsg[byteCntr + 1u] = msgCntr;
   }
   // done
   return;
}
#endif

/* ************** END OF FILE   AUTOREMOVE_TEST_C ************************** */

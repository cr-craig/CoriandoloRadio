#ifndef NRF51_RADIOHW_H
#define NRF51_RADIOHW_H

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This is the public include file for nRF51_RadioHW.c
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2016-04-24
*  @date       last modified by Craig Goldman 2016-11-06
*
*
*  @copyright  Copyright (c) 2015, 2016 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*  @details
*  This file is the public include file for nRF51_RadioHw.c.
*
*  @warning
*  *** THIS FILE SHOULD NOT BE MODIFIED. ***
*
*  @warning
*  Any modification to this file may cause the Coriandolo Radio Protocol to
*  operate improperly.
*/


/* ***************************************************************************
*  INCLUDE FILE
*/
#include <stdint.h>
#include <stdbool.h>
#include "nrf51_bitfields.h"
#include "Callback.h"


/** ***************************************************************************
*  PUBLIC TYPE FOR RADIO ADDRESSES
*/
/// @typedef radioaddr_t
/// @details
/// This is the type definition for radio addresses.  These are used by the
/// radio hardware to facilitate communications.  The radio address is part of
/// the radio packet.  This type is not associated with "Device Identifier"
/// value(s), which are included in the packet payload.
typedef uint64_t  radioaddr_t;


/** ***************************************************************************
*   PUBLIC TYPE FOR RADIO STATUS
*/

/// @enum radiostatus_t
/// @details
/// This is an enumerated type of the radio status.  The code only supports 
/// three values.
/// @note
///    NUMERICAL VALUES ARE SUBJECT TO CHANGE.
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE.
typedef enum
{
   eRADIOSTATUS_RX = RADIO_STATE_STATE_Rx,    ///< Radio Status Receive
   eRADIOSTATUS_TX = RADIO_STATE_STATE_Tx,    ///< Radio Status Transmit
   eRADIOSTATUS_UNKNOWN = 0xFFFFuL            ///< Radio Status Unknown
} radiostatus_t;


/* ***************************************************************************
*  PUBLIC PROTOTYPES
*/
void     RadioHw_Init( void);
void     RadioHw_AddressRx_Set( const radioaddr_t addrRx);
void     RadioHw_AddressTx_Set( const radioaddr_t addrTx);
void     RadioHw_Callbacks_Set( callback_t pktBeginCallback,
                                callback_t pktEndCallback);
void     RadioHw_Config( void);
bool     RadioHw_ForceIdle( void);
bool     RadioHw_FrequencySet( uint32_t frequencyMhz);
bool     RadioHw_RxPacket_IsOK( void);
void     RadioHw_RxStart( uint8_t* rxBufrPtr, const uint8_t rxBufrLen);
void     RadioHw_Shutdown( void);
void     RadioHw_TxStart( uint8_t* txPayloadPtr, const uint8_t txPayloadLen);
void     RadioHw_TxStartConstantCarrier( void);
bool     RadioHw_WaitForIdle( void);


#endif /* ifndef NRF51_RADIOHW_H */

/* ************** END OF FILE   NRF51_RADIOHW_H **************************** */

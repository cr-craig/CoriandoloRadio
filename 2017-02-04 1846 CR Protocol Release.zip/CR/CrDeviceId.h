#ifndef CRDEVICEID_H
#define CRDEVICEID_H

/** ********************** FILE HEADER ****************************************
*  @file
*  @brief      CR Device Identifier - inline functions to support CR Device Identifiers
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2015-10-31
*  @date       last modified by Craig Goldman 2017-02-04
*
*  @copyright  Copyright (c) 2015, 2016, 2017 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*  @details
*  This file is an include file that contains functions and procedures related
*  to "Device Identifiers".  These subroutines API is used internally by CR 
*  code.  Application programs may use these APIs.
*
*  @brief
*  CR = Coriandolo Radio
*
*  @warning
*  *** THIS FILE SHOULD NOT BE MODIFIED. ***
*
*  @warning
*  Any modification to this file may cause the Coriandolo Radio Protocol to
*  operate improperly.
*/

/* ***************************************************************************
*  INCLUDE FILE
*/
#include <stdint.h>
#include <stdbool.h>
#include "nrf51.h"
#include "CR.h"


/** ***************************************************************************
*  @page CrDeviceIdDoc  CR Device Identifier Documentation
*  DOCUMENTATION
*
*  CONST_DEVICEID_SIZEINMESSAGE is the number of bytes in a Device Identifier.
*  It is defined in "CR.h"
*
*  "DEVICEID (Device Identifier)".
*  The DEVICEID is a multi-byte unsigned integer value that must be unique
*  among all devices participating in the protocol.  It is converted into a
*  32-bit unsinged integer for comparison and for internal use.
*  The application programmer should use the procedures "CrDeviceId_GetBytes"
*  and "CrDeviceId_PutBytes" to get a DEVICEID from a message or to put a 
*  DEVICEID into a message.
*
*  "DEVICEID IS LEGAL".
*  The function tests for a valid value for DEVICEID.
*  A DEVICEID MUST:
*     1) ...not be equal to zero - a zero value is reserved;
*     2) ...not be equal to the defined constant for universal match;
*     3) ...must fit in the allowed number of bytes in the message; and
*     4) ...must not be the "all 1's" value for the allowed number of bytes.
*
*  "DEVICE ID MATCH".
*  A DEVICEID contained in a message is said to "match" a constant value if the 
*  the DEVICEID is equal-to the constant value or if the constant value is 
*  equal-to CONST_SENSORID_ALWAYS_MATCH.
*  The reader should note that THE REVERSE IS NOT TRUE.  A Device Identifier
*  contained in a message will not "match" another Device Identifier contained
*  in a message UNLESS the two have the same value.
*  TO AVOID THIS CONFUSION AND THE RESULTING ISSUES IT MAY GENERATE, the 
*  function "CrDeviceID_IsLegal" returns false for a DEVICEID equal to
*  CONST_SENSORID_ALWAYS_MATCH.
*/



/** ***************************************************************************
*  @def CONST_DEVICEID_ALWAYS_MATCH
*  @def CONST_DEVICEID_INVALID
*  PUBLIC CONSTANTS FOR MATCHING DEVICE IDENTIFIER
*
*  This constant should be used to always "match" a 'deviceId'.
*
*  @warning
*  Never use CONST_DEVICEID_ALWAYS_MATCH as a Device Identifier; 
*  use only as the 'matchIdValue'
*/
#define CONST_DEVICEID_ALWAYS_MATCH    ((uint32_t)0xFFFFFFFFuL)
#define CONST_DEVICEID_INVALID         ((uint32_t)0u)


/* ***************************************************************************
*  FUNCTION PROTOTYPES
*  (because the functions are declared below, this is not needed, but is useful)
*/
static __INLINE bool  CrDeviceID_IsLegal( const uint32_t deviceIdValue);
static __INLINE bool  CrDeviceID_IsMatch( const uint32_t deviceIdValue,
                                          const uint32_t matchIdValue);
static __INLINE void  CrDeviceId_GetBytes( uint32_t* deviceIdValuePtr, 
                                           uint8_t*  deviceIdBytesPtr);
static __INLINE void  CrDeviceId_PutBytes( const uint32_t  deviceIdValue, 
                                            uint8_t*  deviceIdBytesPtr);



/* ***************************************************************************
*  PUBLIC INLINE PROCEDURES
*/

/** ***************************************************************************
*  CORIANDOLO RADIO DEVICE ID IS LEGAL
*
*  This is a function that checks the 'deviceIdValue' for legality.
*  The rules for a legal Device Identifier are described above.
*  @returns    boolean 'true' if device identifier is "legal"
*  @param[in]  deviceIdValue - device identifier value
*
*  NOTE: Conditional compiled code allows CONST_DEVICEID_SIZEINMESSAGE to be  
*        equal-to 2, 3 or 4 bytes.
*  NOTE: Depending upon the value of CONST_DEVICEID_ALWAYS_MATCH some of the
*        conditional code may be redundant; the compiler should remove redundant
*        tests.
*/
#if CONST_DEVICEID_SIZEINMESSAGE == 2u
static __INLINE bool  CrDeviceID_IsLegal( const uint32_t deviceIdValue)
{
   bool  isLegal;
   if( (deviceIdValue != CONST_DEVICEID_INVALID) &&
       (deviceIdValue != CONST_DEVICEID_ALWAYS_MATCH) &&
       (deviceIdValue != (CONST_DEVICEID_ALWAYS_MATCH & 0x0000FFFFuL) &&
       (deviceIdValue < 0x0000FFFFuL)) )
   {
      isLegal = true;
   }
   else
   {
      isLegal = false;
   }
   return isLegal;
}

#elif CONST_DEVICEID_SIZEINMESSAGE == 3u
static __INLINE bool  CrDeviceID_IsLegal( const uint32_t deviceIdValue)
{
   bool  isLegal;
   if( (deviceIdValue != CONST_DEVICEID_INVALID) && 
       (deviceIdValue != CONST_DEVICEID_ALWAYS_MATCH) &&
       (deviceIdValue != (CONST_DEVICEID_ALWAYS_MATCH & 0x00FFFFFFuL)) &&
       (deviceIdValue < 0x00FFFFFFuL))
   {
      isLegal = true;
   }
   else
   {
      isLegal = false;
   }
   return isLegal;
}

#elif CONST_DEVICEID_SIZEINMESSAGE == 4u
static __INLINE bool  CrDeviceID_IsLegal( const uint32_t deviceIdValue)
{
   bool  isLegal;
   if( (deviceIdValue != CONST_DEVICEID_INVALID) && 
       (deviceIdValue != CONST_DEVICEID_ALWAYS_MATCH) &&
       (deviceIdValue < 0xFFFFFFFFuL) )
   {
      isLegal = true;
   }
   else
   {
      isLegal = false;
   }
   return isLegal;
}

#else
   ERROR. DEFINED VALUE OF CONST_DEVICEID_SIZEINMESSAGE IS NOT SUPPORTED
#endif


/** ***************************************************************************
*  CORIANDOLO RADIO DEVICE ID IS MATCH
*
*  This is a function that checks the 'deviceIdValue' for a "match" with the
*  'matchIdValue'.
*  @returns    boolean 'true' if device identifier value matches match idetifier value
*  @param[in]  deviceIdValue - device identifier value
*  @param[in]  matchIdValue - value to match
*
*  For performance, comparisons for "match" are done using 32-bit values; it
*  is presummed that higher-level code has masked the bits, if necessary.
*
*  @warning
*  The order of the parameters is important;
*  do not reverse 'deviceIdValue' and 'matchIdValue'
*
*  @note
*  Conditional compiled code allows CONST_DEVICEID_SIZEINMESSAGE to be  
*  equal-to 2, 3 or 4 bytes.
*
*  @note
*  Depending upon the value of CONST_DEVICEID_ALWAYS_MATCH some of the
*  conditional code may be redundant; the compiler should remove redundant
*  tests.
*/
static __INLINE bool  CrDeviceID_IsMatch( const uint32_t deviceIdValue,
                                          const uint32_t matchIdValue)
{
   bool  isMatch;
   if( matchIdValue == CONST_DEVICEID_ALWAYS_MATCH)
   {
      isMatch = true;
   }
   else if( matchIdValue == deviceIdValue)
   {
      isMatch = true;
   }
   else
   {
      isMatch = false;
   }
   // done
   return isMatch;
}


/** ***************************************************************************
*  CORIANDOLO RADIO DEVICE IDENTIFIER GET BYTES
*
*  This code copies the bytes of the Device Identifier from an array of bytes 
*  into a 32-bit unsigned variable.  Bytes in array are LSB first. 
*  @returns    void
*  @param[in]  deviceIdValuePtr - pointer to 32-bit memory for device identifier
*  @param[in]  deviceIdBytesPtr - pointer to bytes containing device identifer.
*                                 Number of bytes depends on CONST_DEVICEID_SIZEINMESSAGE
*
*  @warning
*  Pointer values are NOT checked for NULL
*
*  @note
*  Conditional compiled code allows CONST_DEVICEID_SIZEINMESSAGE to be  
*  equal-to 2, 3 or 4 bytes.
*
*  @note
*  Code has been written to be MISRA compatible.
*  MISRA does not allow pointer math.
*  This produces more code text for expressions to create 'deviceId', but compiler
*  does not produce more code.
*/
#if CONST_DEVICEID_SIZEINMESSAGE == 2u
static __INLINE void  CrDeviceId_GetBytes( uint32_t* deviceIdValuePtr, 
                                           uint8_t*  deviceIdBytesPtr)
{
   uint32_t deviceId;
   /* Set deviceId = (((uint32_t)*(deviceIdBytesPtr + 0))) +
                     (((uint32_t)*(deviceIdBytesPtr + 1)) <<  8);
   */
   deviceId = (uint32_t)deviceIdBytesPtr[1];
   deviceId = deviceId << 8;
   deviceId += (uint32_t)deviceIdBytesPtr[0];
   *deviceIdValuePtr = deviceId;
   return;
}

#elif CONST_DEVICEID_SIZEINMESSAGE == 3u
static __INLINE void  CrDeviceId_GetBytes( uint32_t* deviceIdValuePtr, 
                                           uint8_t*  deviceIdBytesPtr)
{
   uint32_t deviceId;
   /* Set deviceId = (((uint32_t)*(deviceIdBytesPtr + 0))) +
                     (((uint32_t)*(deviceIdBytesPtr + 1)) <<  8) +
                     (((uint32_t)*(deviceIdBytesPtr + 2)) << 16);
   */
   deviceId = (uint32_t)deviceIdBytesPtr[2];
   deviceId = deviceId << 8;
   deviceId += (uint32_t)deviceIdBytesPtr[1];
   deviceId = deviceId << 8;
   deviceId += (uint32_t)deviceIdBytesPtr[0];
   *deviceIdValuePtr = deviceId;
   return;
}

#elif CONST_DEVICEID_SIZEINMESSAGE == 4u
static __INLINE void  CrDeviceId_GetBytes( uint32_t* deviceIdValuePtr, 
                                           uint8_t*  deviceIdBytesPtr)
{
   uint32_t deviceId;
   /* Set deviceId = (((uint32_t)*(deviceIdBytesPtr + 0))) +
                     (((uint32_t)*(deviceIdBytesPtr + 1)) <<  8) +
                     (((uint32_t)*(deviceIdBytesPtr + 2)) << 16) +
                     (((uint32_t)*(deviceIdBytesPtr + 3)) << 24);
   */
   deviceId = (uint32_t)deviceIdBytesPtr[3];
   deviceId = deviceId << 8;
   deviceId += (uint32_t)deviceIdBytesPtr[2];
   deviceId = deviceId << 8;
   deviceId += (uint32_t)deviceIdBytesPtr[1];
   deviceId = deviceId << 8;
   deviceId += (uint32_t)deviceIdBytesPtr[0];
   *deviceIdValuePtr = deviceId;
   return;
}

#else
   ERROR. DEFINED VALUE OF CONST_DEVICEID_SIZEINMESSAGE IS NOT SUPPORTED
#endif


/** ***************************************************************************
*  CORIANDOLO RADIO DEVICE IDENTIFIER PUT BYTES
*
*  This code copies the bytes of a 32-bit unsigned variable representing the
*  value of a Device Identifier to an array of bytes.  Bytes in array are LSB first.
*  @returns    void
*  @param[in]  deviceIdValue - 32-bit value of device identifier
*  @param[in]  deviceIdBytesPtr - pointer to bytes containing device identifer.
*                                 Number of bytes depends on CONST_DEVICEID_SIZEINMESSAGE
*
*  @warning
*  Pointer values are NOT checked for NULL
*
*  @note
*  Conditional compiled code allows CONST_DEVICEID_SIZEINMESSAGE to be  
*  equal-to 2, 3 or 4 bytes.
*
*  @note
*  Code has been written to be MISRA compatible.
*  MISRA does not allow pointer math.
*/
#if CONST_DEVICEID_SIZEINMESSAGE == 2u
static __INLINE void  CrDeviceId_PutBytes( const uint32_t  deviceIdValue, 
                                           uint8_t*  deviceIdBytesPtr)
{
   deviceIdBytesPtr[0] = (uint8_t)deviceIdValue;
   deviceIdBytesPtr[1] = (uint8_t)(deviceIdValue >>  8);
   return;
}

#elif CONST_DEVICEID_SIZEINMESSAGE == 3u
static __INLINE void  CrDeviceId_PutBytes( const uint32_t  deviceIdValue, 
                                           uint8_t*  deviceIdBytesPtr)
{
   deviceIdBytesPtr[0] = (uint8_t)deviceIdValue;
   deviceIdBytesPtr[1] = (uint8_t)(deviceIdValue >>  8);
   deviceIdBytesPtr[2] = (uint8_t)(deviceIdValue >> 16);
   return;
}

#elif CONST_DEVICEID_SIZEINMESSAGE == 4u
static __INLINE void  CrDeviceId_PutBytes( const uint32_t  deviceIdValue, 
                                            uint8_t*  deviceIdBytesPtr)
{
   deviceIdBytesPtr[0] = (uint8_t)deviceIdValue;
   deviceIdBytesPtr[1] = (uint8_t)(deviceIdValue >>  8);
   deviceIdBytesPtr[2] = (uint8_t)(deviceIdValue >> 16);
   deviceIdBytesPtr[3] = (uint8_t)(deviceIdValue >> 24);
   return;
}

#else
   ERROR. DEFINED VALUE OF CONST_DEVICEID_SIZEINMESSAGE IS NOT SUPPORTED
#endif



#endif /* ifndef CRDEVICEID_H */

/* ************** END OF FILE   CRDEVICEID_H ******************************* */

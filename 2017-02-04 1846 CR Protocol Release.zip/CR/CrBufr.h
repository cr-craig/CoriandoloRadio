#ifndef CRBUFR_H
#define CRBUFR_H

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This is the public include file for CrBufr.c
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2015-06-16
*  @date       last modified by Craig Goldman 2016-11-26

*  @copyright  Copyright (c) 2015, 2016 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*  @details
*  This file is the public include file for CrBufr.c.
*
*  @brief
*  CR = Coriandolo Radio
*
*  @warning
*  Although this file is a public include file, the "CrBufr" functionality is 
*  considered by the authors to be internal to Coriandolo Radio.  The interface
*  for functions and procedures may be changed to support new features.
*/



/* ***************************************************************************
*  INCLUDE FILE
*/
#include <stdint.h>
#include <stdbool.h>
#include "CR_PublicTypes.h"


/** ***************************************************************************
*  PUBLIC CONSTANT FOR MINIMUM RECEIVE BUFFER SIZE
*/
#define CONST_RXBUFFER_SIZE_MIN        ( CONST_DEVICEID_SIZEINMESSAGE + 1u)


/* ***************************************************************************
*  PUBLIC TYPES
*/

/// @typedef crsequencnum_t
/// @brief
/// "Coriandolo Radio Sequence Number" is a defined type to provide a central
///    point to control the number of bytes of a sequence number.
///    Current definition is 'uint16_t' which is 2 bytes.
typedef uint16_t crsequencnum_t;


/// @struct crbufrinfo_t
/// @brief
/// "Coriandolo Radio Buffer Information" is a structure type that indicates
///    the information needed by the CR Protocol to select and use messages and
///    message buffers.
typedef struct
    {
       uint8_t*  bufrPtr;              ///< Pointer to bytes of message
       uint32_t  tickValue;            ///< 32-bit Time Stamp value in "ticks"
       uint16_t  sequenceNum;          ///< sequence number to determine which msg is older
       uint16_t  reserved16;           ///< reserved 16-bit field; Do not use.
       uint8_t   statusByte;           ///< 8-bit version of 'crbufrstatus_t'
       uint8_t   exchangeStatusByte;   ///< 8-bit version of 'exchangestatus_t'
       uint8_t   msgFlagsByte;         ///< holds message flags
       uint8_t   bufrSize;             ///< holds received message or transmit msg size
       uint32_t  deviceID;             ///< 32-bit version of Device Identifier
    } crbufrinfo_t;
/// @note
/// 'reserved16' has been added to make structure a multiple of 32-bits;
/// THIS FIELD IS RESERVED FOR FUTURE USE - DO NOT STORE DATA INTO THIS FIELD
/// @note
/// 'deviceID' is a copy of the Device Identifier found in the message, the copy
/// is used to speed-up "..._Find..." functions.
/// @warning
/// This structure is subject to change as future features are added.

    
/// @enum crbufrstatus_t
/// @brief
/// "Coriandolo Radio buffer status" is an enumerated type describing the status
///    of Coriandolo Buffers - most of these status represent radio operations.
///
/// @details
/// eCRBUFRSTATUS_NULL and eCRBUFRSTATUS_UNUSED are different.
/// eCRBUFRSTATUS_NULL is a special return value to indicate a NULL POINTER
/// has been detected; eCRBUFRSTATUS_UNUSED indicates that the buffer
/// information structure has no valid data.
///
/// @note
/// All numberical values of 'crbufrstatus_t' must fit within 8 bits
/// (i.e. they all must be greater-than or equal-to zero and less-than or equal-to 255).
///
/// @note
///    NUMERICAL VALUES ARE SUBJECT TO CHANGE.
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE.
typedef enum
{
   eCRBUFRSTATUS_ERROR  = 0,      ///< Buffer Status is Error 
   eCRBUFRSTATUS_NULL,            ///< NULL POINTER value (probably passed as parameter)
   eCRBUFRSTATUS_RXBUSY,          ///< Buffer Status Busy for Reception (in use)
   eCRBUFRSTATUS_RXMSGERROR,      ///< Buffer Status Receive Message Error
   eCRBUFRSTATUS_RXMSGRCVD,       ///< Buffer Status Receive Message Received (no error) 
   eCRBUFRSTATUS_RXREADY,         ///< Buffer Status Ready for Reception
   eCRBUFRSTATUS_RXTIMEOUT,       ///< Buffer Status Reception Timed-out
   eCRBUFRSTATUS_TXBUSY,          ///< Buffer Status Busy for Transmission (in use)
   eCRBUFRSTATUS_TXMSGSENT,       ///< Buffer Status Transmit Message has been Sent
   eCRBUFRSTATUS_TXREADY,         ///< Buffer Status Transmit Message Ready to be Sent
   eCRBUFRSTATUS_UNUSED,          ///< Buffer is unused -- contains no data
   eCRBUFRSTATUS_TESTDEFAULT      ///< This value is used by test code to force switch case Default
} crbufrstatus_t;


/* ***************************************************************************
*  PUBLIC PROTOTYPES
*/
void              CrBufr_Init( void);
uint32_t          CrBufr_BufrInfo_GetDeviceId( const crbufrinfo_t* crBufrInfoPtr);
uint8_t*          CrBufr_BufrInfo_GetMsgPtr( const crbufrinfo_t* crBufrInfoPtr);
crrxflags_t       CrBufr_BufrInfo_GetRxMsgFlags( const crbufrinfo_t* crBufrInfoPtr);
uint8_t           CrBufr_BufrInfo_GetSize( const crbufrinfo_t* crBufrInfoPtr);
crbufrstatus_t    CrBufr_BufrInfo_GetStatus( const crbufrinfo_t* crBufrInfoPtr);
exchangestatus_t  CrBufr_BufrInfo_GetStatusExchng( const crbufrinfo_t* crBufrInfoPtr);
uint32_t          CrBufr_BufrInfo_GetTickValue( const crbufrinfo_t* crBufrInfoPtr);
crtxflags_t       CrBufr_BufrInfo_GetTxMsgFlags( const crbufrinfo_t* crBufrInfoPtr);
void              CrBufr_BufrInfo_SetDeviceId( crbufrinfo_t* crBufrInfoPtr, 
                                       const uint32_t newDeviceId);
void              CrBufr_BufrInfo_SetStatus( crbufrinfo_t* crBufrInfoPtr,
                                            const crbufrstatus_t newBufrStatus);
void              CrBufr_BufrInfo_SetStatusExchng( crbufrinfo_t* crBufrInfoPtr,
                                                   const exchangestatus_t newStatusExchg);
void              CrBufr_BufrInfo_SetTickValue( crbufrinfo_t* crBufrInfoPtr,
                                                const uint32_t newTickValue);
void              CrBufr_BufrInfo_SetUnused( crbufrinfo_t* crBufrInfoPtr);
crbufrstatus_t    CrBufr_BufrInfo_UnusedIfNotBusy( crbufrinfo_t* crBufrInfoPtr);
crbufrstatus_t    CrBufr_LoadRxBufrInfo( crbufrinfo_t* rxBufrInfoPtr, 
                                         uint8_t* rxBufrPtr,
                                         const uint8_t rxBufrSize,
                                         const crrxflags_t rxBufrFlags);
crbufrstatus_t    CrBufr_LoadTxBufrInfo( crbufrinfo_t* txBufrInfoPtr,
                                         uint8_t* txMsgPtr,
                                         const uint8_t txMsgLength,
                                         const crtxflags_t txMsgFlags,
                                         const uint32_t    deviceIdValue);
void              CrBufr_Rx_AssignRcvdSequenceNum( crbufrinfo_t* rxBufrInfoPtr);
uint16_t          CrBufr_Rx_CountWithStatus( const crbufrstatus_t statusValue);
crbufrinfo_t*     CrBufr_Rx_FindMatchingBufr( const uint8_t* rxBufrPtr);
crbufrinfo_t*     CrBufr_Rx_FindNextRxReady( void);
crbufrinfo_t*     CrBufr_Rx_FindNextRxRcvd( const uint32_t matchDeviceId);
crbufrinfo_t*     CrBufr_Rx_FindUnused( void);
uint16_t          CrBufr_Tx_CountWithStatus( const crbufrstatus_t statusValue);
crbufrinfo_t*     CrBufr_Tx_FindMatchingBufr( const uint8_t* txBufrPtr);
crbufrinfo_t*     CrBufr_Tx_FindNextTxReady( const uint32_t matchDeviceId);
crbufrinfo_t*     CrBufr_Tx_FindNextTxSent( const uint32_t matchDeviceId);
crbufrinfo_t*     CrBufr_Tx_FindUnused( void);


#endif /* ifndef CRBUFR_H */

/* ************** END OF FILE   CRBUFR_H *********************************** */

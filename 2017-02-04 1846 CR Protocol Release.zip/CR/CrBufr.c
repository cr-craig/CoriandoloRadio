#define CRBUFR_C

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This module supports Coriandolo Radio Buffer Information Structures
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2015-06-16
*  @date       last modified by Craig Goldman 2016-11-26
*
*
*  @copyright  Copyright (c) 2015, 2016 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*
*  @details
*  This file contains functions and procedures used to manage buffers for
*  Coriandolo Radio Protocol.
*
*  @warning
*  *** THIS FILE SHOULD NOT BE MODIFIED. ***
*
*  @warning
*  Any modification to this file may cause the Coriandolo Radio Protocol to
*  operate improperly.
*/

/* ***************************************************************************
*  INCLUDE FILES
*/
#include <stdint.h>
#include <stdbool.h>
#include "CrBufr.h"
#include "CrDeviceId.h"


/** ***************************************************************************
*  @page CrBufrDoc  CrBufr Documentation
*  DOCUMENTATION
*
*  BUFFER -
*  A "Buffer" is an array of bytes which may hold a message.
*
*  BUFFER INFORMATION STRUCTURE -
*  A structure that contains a pointer to a buffer, status and other variables 
*  used to manage the buffers.
*
*  This code manages multiple buffers by creating an information structure,
*  'crbufrinfo_t' for every potential buffer.
*  (For infomation on 'crbufrinfo_t' refer to "CrBufr.h").
*
*  The information structures of potential buffers are organized as two arrays
*  -- one for receive buffers and one for transmit buffers.  The code "adds" / 
*  "removes" buffers to / from the array of information structures.
*
*  The Buffer Information structure is considered UNUSED if the pointer to the
*  buffer within the structure is equal to the NULL POINTER. 
*  If the structure is UNUSED, none of the fields in the buffer structure contain 
*  any valid information.
*  By specification, if the pointer to the buffer is NOT NULL, then the structure
*  is considered IN-USE and the the STATUS field of the structure must contain
*  a valid value.
*  Code must check the buffer pointer of the structure to determine if it is 
*  IN-USE before accessing any of the other structure fields.
*
*  SEQUENCE NUMBER -
*  A "Sequence Number" is a numerical value which is used to determine which
*  of the messages in the Buffer Information Structures is "older".
*  The Sequence Numbers are generated using a "Sequence Counter" and a call to
*  internal function "CrBufr_SequenceNum_Next".
*
*  SEQUENCE COUNTER -
*  The value of the counter is incremented every time it is used.  The function
*  to increment the counter "skips" values of 0x0000 and 0xFFFF; these values
*  are reserved to indicate error conditions.  The sequence numbers will
*  roll-over every 65534 uses; however, this value should be large enough
*  so no two information structures should have the same sequence numbers.
*
*  The function to incrment the sequence counter is called immediately BEFORE
*  the value is saved in the information structure; therefore the value of the
*  static variable represents the last value assigned.
*
*
*  AGE -
*  The "Age" of message content can be determined by the sequence number which
*  is associated with the message.  The Age value is relative and should only
*  be used to determine which message had a sequence number assigned earlier.
*  The Age can be calculated by subtracting the assigned sequence number from
*  the current value of the sequence counter.
*  Age is calculated by the internal function "CrBufr_SequenceNum_CalcAge"
*
*  DEVICE ID (Device Identifier) -
*  See "CrDeviceId.h"
*
*  DEVICE ID MATCH -
*  See "CrDeviceId.h"
*/

/* ***************************************************************************
*  CONFIGURATION CONSTANTS FOR NUMBER OF RECEIVE AND TRANSMIT BUFFERS
*
*  These numbers were chosen based upon experience with the protocol by
*  64 Seconds and CoAutomation Inc.; the larger number of transmit buffers 
*  allows a BASE to store transmit messages for multiple SENSORS; it also allows
*  a SENSOR to pre-build many transmit messages and thus speeds-up transmission 
*  of bulk data from a SENSOR to a BASE.
*  Neither a BASE nor a SENSOR is required to use all of the available slots;
*  many applications will choose to use only a portion of the slots that are
*  available.
*
*  Receive and Transmit Buffer numbers start with '0' so the MAX INDEX is one 
*  less than the count of buffers.
*
*  The programmer is advised to be careful when changing these values.
*  Unexpected consequences may occur.
*/

/// Configure "Slots" to handle up to 9 receive buffers.
/// The number of receive buffers allows processing an Announcement (or an
/// Announcement response) followed by receiving 8 additional messages.
#define CONFIG_RECEIVE_BUFFERS_MAXINDX      8u

/// Configure "Slots" to handle up to 31 transmit buffers.  This allows a BASE
/// device to store "outgoing" messages for several different SENSORS.  Also 
/// allows SENSORs to queue up lots of messages to send.
#define CONFIG_TRANSMIT_BUFFERS_MAXINDX    30u


/* ***************************************************************************
*  PRIVATE VARIABLES
*/
static crbufrinfo_t  s_rxBufrInfo[ CONFIG_RECEIVE_BUFFERS_MAXINDX + 1u];
static crbufrinfo_t  s_txBufrInfo[ CONFIG_TRANSMIT_BUFFERS_MAXINDX + 1u];

static crsequencnum_t  s_rxSequenceCntr; 
static crsequencnum_t  s_txSequenceCntr; 


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE PROCEDURES
*/
static                    void  CrBufr_BufrInfoArray_RemoveAll( crbufrinfo_t bufrInfoArray[],
                                                                const uint16_t maxArrayIndx);
static __INLINE crbufrstatus_t  CrBufr_BufrInfoStruct_GetStatus( const crbufrinfo_t* crBufrInfoPtr);
static                    void  CrBufr_BufrInfoStruct_InitAsUnused( crbufrinfo_t* crBufrInfoPtr);
static                    void  CrBufr_BufrInfoStruct_InitDefault( crbufrinfo_t* crBufrInfoPtr);
static __INLINE           bool  CrBufr_BufrInfoStruct_IsUnused( const crbufrinfo_t* crBufrInfoPtr);
static                    void  CrBufr_BufrInfoStruct_NewRx( crbufrinfo_t* rxBufrInfoPtr, 
                                                             uint8_t* rxBufrPtr, 
                                                             const uint8_t rxBufrSize,
                                                             const uint8_t rxBufrFlagsByte);
static                    void  CrBufr_BufrInfoStruct_NewTx( crbufrinfo_t* txBufrInfoPtr,
                                                             uint8_t* txMsgPtr,
                                                             const uint8_t txMsgLength,
                                                             const uint8_t txMsgFlagsByte,
                                                             const uint32_t deviceIdValue,
                                                             const uint16_t sequenceNum);
static           crbufrinfo_t*  CrBufr_Choose_Older( crbufrinfo_t* crBufrInfoPtr1,
                                                     crbufrinfo_t* crBufrInfoPtr2,
                                                     const crsequencnum_t sequenceCntr);
static           uint16_t       CrBufr_Count_WithStatus( const crbufrinfo_t bufrInfoArray[], 
                                                         const uint16_t maxArrayIndx,
                                                         const crbufrstatus_t statusValue);
static           crbufrinfo_t*  CrBufr_Find_FirstWithStatus( crbufrinfo_t bufrInfoArray[],
                                                             const uint16_t maxArrayIndx,   
                                                             const crbufrstatus_t statusValue);
static           crbufrinfo_t*  CrBufr_Find_OldestWithStatus( crbufrinfo_t bufrInfoArray[],   
                                                              const uint16_t maxArrayindx,
                                                              const crsequencnum_t sequenceCntr,
                                                              const crbufrstatus_t statusValue,
                                                              const uint32_t matchDeviceId);
static           crbufrinfo_t*  CrBufr_Find_MatchingBufrPtr( crbufrinfo_t bufrInfoArray[],
                                                             const uint16_t maxArrayindx,
                                                             const uint8_t* bufrPtr);
static __INLINE  uint32_t       CrBufr_SequenceNum_CalcAge( const crbufrinfo_t* crBufrInfoPtr, 
                                                            const crsequencnum_t sequenceCntr);
static __INLINE  crsequencnum_t CrBufr_SequenceNum_Next( const crsequencnum_t sequenceNum);



/* ***************************************************************************/
/** **************************************************************************
*  MODULE INITIALIZATION PROCEDURE
*
*  -- All modules must have a "..._Init" procedure to initialize static 
*  variables to known values.
*  @returns   void
*/
void CrBufr_Init( void)
{
   // Initialize static variables to "safe" values
   s_rxSequenceCntr = CrBufr_SequenceNum_Next( 0u);
   s_txSequenceCntr = CrBufr_SequenceNum_Next( 0u);
   // Remove all content from ALL Receive and Transmit Information Structures
   CrBufr_BufrInfoArray_RemoveAll( s_rxBufrInfo, CONFIG_RECEIVE_BUFFERS_MAXINDX);
   CrBufr_BufrInfoArray_RemoveAll( s_txBufrInfo, CONFIG_TRANSMIT_BUFFERS_MAXINDX);
   return;
}


/* ***************************************************************************/
/* ***************************************************************************
*  PUBLIC PROCEDURES -- in alphabetical order
*/

/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION GET DEVICE IDENTIFIER
*
*  Returns the "Device Identifier" value associated with the passed pointer to  
*  a Buffer Information Structure.
*  @returns    32-bit unsigned integer containing a Device Identenfier
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  If the passed parameter is a NULL POINTER, the function returns 0, else it  
*  returns the 'deviceId' field of the Buffer Information Structure pointed to  
*  by the parameter.
*/
uint32_t  CrBufr_BufrInfo_GetDeviceId( const crbufrinfo_t* crBufrInfoPtr)
{
   uint32_t  deviceId;
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      deviceId = crBufrInfoPtr->deviceID;
   }
   else
   {
      // Return an error value
      deviceId = CONST_DEVICEID_INVALID;
   }
   // done
   return deviceId;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION GET MESSAGE POINTER
*
*  Returns a pointer to the message associated with the passed pointer to  
*  a Buffer Information Structure.
*  @returns    a pointer to message bytes
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  If the passed parameter is a NULL POINTER, the function returns Returns a NULL
*  POINTER otherwise the function returns a pointer to the message bytes.
*/
uint8_t*  CrBufr_BufrInfo_GetMsgPtr( const crbufrinfo_t* crBufrInfoPtr)
{
   uint8_t*  msgPtr;
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      msgPtr = crBufrInfoPtr->bufrPtr;
   }
   else
   {
      // Return a NULL POINTER
      msgPtr = CONST_NULLPTR;
   }
   return msgPtr;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION GET RX MESSAGE FLAGS
*
*  Returns the Message Flags associated with the passed pointer to  
*  a Buffer Information Structure.
*  @returns    a value of the enumerated type 'crrxflags_t'   
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  If the passed parameter is a NULL POINTER, the function returns eCRRXFLAGS_ERROR, 
*  else it returns the message flags byte of the Buffer Information Structure 
*  coerced to type 'crrxflags_t'.
*
*  @warning
*  This function does NOT validate that the "status" of the Buffer Information
*  Structure is eCRBUFRSTATUS_RXREADY, eCRBUFRSTATUS_RXMSGRCVD, eCRBUFRSTATUS_RXBUSY
*  or eCRBUFRSTATUS_RXTIMEOUT, so the contents of the 'msgFlagsByte' may not be
*  valid.  This should be done by higher level code.
*/
crrxflags_t  CrBufr_BufrInfo_GetRxMsgFlags( const crbufrinfo_t* crBufrInfoPtr)
{
   crrxflags_t  rxFlags;
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      rxFlags = (crrxflags_t)(crBufrInfoPtr->msgFlagsByte);
   }
   else
   {
      // Returns an error code
      rxFlags = eCRRXFLAGS_ERROR;
   }
   return rxFlags;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION GET SIZE
*
*  Returns the value of the "Buffer Size" field associated with the passed   
*  pointer to a Buffer Information Structure.
*  @returns    an unsigned 8-bit integer value the size of the receive buffer or
*              the number of bytes in a transmit message
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  If the passed parameter is a NULL POINTER, the function returns 0, else it  
*  the value of the "Buffer Size" field.  This field is set during the "load"
*  of Receive or Transmit Buffer Information.
*
*  @note
*  The value returned is the "Buffer Size" field of the Buffer Information 
*  Structure.  This is different than the value found in the "length byte"
*  of a message.
*/
uint8_t  CrBufr_BufrInfo_GetSize( const crbufrinfo_t* crBufrInfoPtr)
{
   uint8_t  size;
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      size = crBufrInfoPtr->bufrSize;
   }
   else
   {
      size = (uint8_t)0u;
   }
   return size;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION GET STATUS
*
*  Returns the value of the "status" field associated with the passed pointer
*  to a Buffer Information Structure.
*  @returns    an enumerated value that represents the status of the message in
*              the Buffer Information Structure.
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  If the passed parameter is a NULL POINTER, the function returns eCRBUFRSTATUS_NULL,
*  else it returns the status value of the Buffer Information Structure.
*/
crbufrstatus_t  CrBufr_BufrInfo_GetStatus( const crbufrinfo_t* crBufrInfoPtr)
{
   crbufrstatus_t  status;
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      status = CrBufr_BufrInfoStruct_GetStatus( crBufrInfoPtr);
   }
   else
   {
      status = eCRBUFRSTATUS_NULL;
   }
   return status;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION GET STATUS EXCHANGE
*
*  Returns the value of the "exchange status" field associated with the passed 
*  pointer to a Buffer Information Structure.
*  @returns    an enumerated value that represents the exchange status of the 
*              message in the Buffer Information Structure.
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  If the passed parameter is a NULL POINTER, the function returns eEXCHANGE_ERROR,
*  else it returns the exchange status value of the Buffer Information Structure
*/
exchangestatus_t  CrBufr_BufrInfo_GetStatusExchng( const crbufrinfo_t* crBufrInfoPtr)
{
   exchangestatus_t statusExchange;
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      statusExchange = (exchangestatus_t)(crBufrInfoPtr->exchangeStatusByte);
   }
   else
   {
      statusExchange = eEXCHANGE_ERROR;
   }
   return statusExchange;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION GET TICK VALUE
*
*  Returns the "Tick Value" field associated with the passed pointer to a 
*  Buffer Information Structure.
*  @returns    32-bit unsigned integer representing the "Tick Value"
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  If the passed parameter is a NULL POINTER, the function returns 0, else it  
*  returns the 'tickValue' field of the Buffer Information Structure.
*
*  @note
*  If the "Tick Counter" is active, the "Tick Value" field contains the value of 
*  the counter coincident with the beginning of message reception or transmission.
*  It may be used to measure time differences between messages or to synchronize 
*  "clocks" between a BASE and a SENSOR device.
*
*  If the "Tick Counter is not enabled, the value of the "Tick Value" field is 
*  not valid.
*/
uint32_t  CrBufr_BufrInfo_GetTickValue( const crbufrinfo_t* crBufrInfoPtr)
{
   uint32_t  ticks;
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      ticks = crBufrInfoPtr->tickValue;
   }
   else
   {
      // Return an error value
      ticks = CONST_TICKSVALUE_INVALID;
   }
   // done
   return ticks;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION GET TX MESSAGE FLAGS
*
*  Returns the Message Flags associated with the passed pointer to  
*  a Buffer Information Structure.
*  @returns    a value of the enumerated type 'crtxflags_t'   
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  If the passed parameter is a NULL POINTER, the function returns eCRTXFLAGS_ERROR, 
*  else it returns the message flags byte of the Buffer Information Structure 
*  coerced to type 'crtxflags_t'.
*
*  @warning
*  This function does NOT validate that the "status" of the Buffer Information
*  Structure is eCRBUFRSTATUS_TXREADY, eCRBUFRSTATUS_TXMSGSENT or
*  eCRBUFRSTATUS_TXBUSY, so the contents of the 'msgFlagsByte' may not be
*  valid.  This should be done by higher level code.
*/
crtxflags_t  CrBufr_BufrInfo_GetTxMsgFlags( const crbufrinfo_t* crBufrInfoPtr)
{
   crtxflags_t  txFlags;
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      txFlags = (crtxflags_t)(crBufrInfoPtr->msgFlagsByte);
   }
   else
   {
      // Returns an error code
      txFlags = eCRTXFLAGS_ERROR;
   }
   return txFlags;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION SET DEVICE IDENTIFIER
*
*  Sets the "Device Identifier" field of the structure pointed to by 'crBufrInfoPtr'.
*  @returns    void
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*  @param[in]  newDeviceId - 32-bit value containing a Device Identifier
*
*  @details
*  If 'crBufrInfoPtr' is a NULL POINTER, no action is performed.
*
*  @warning
*  This procedure does not check the value of the new "Device Identifier".
*  This should be done by higher-level code.  An incorrect value for the
*  Device Identifier may cause unexpected code failures.
*/
void  CrBufr_BufrInfo_SetDeviceId( crbufrinfo_t* crBufrInfoPtr, 
                                   const uint32_t newDeviceId)
{
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      crBufrInfoPtr->deviceID = newDeviceId;
   }
   // done
   return;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION SET STATUS
*
*  Sets the "Status Byte" field (converted from enumerated type to 'uint8_t') 
*  of the structure pointed to by 'crBufrInfoPtr'.
*  @returns    void
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*  @param[in]  newBufrStatus - value of the enumerated type for a new Buffer Status
*
*  @details
*  If 'crBufrInfoPtr' is a NULL POINTER, no action is performed.
*
*  @warning
*  This procedure does not check the value of 'newBufrStatus'.  This should be
*  checked by higher-level code.  An invalid or incorrect value of 'newBufrStatus'
*  may cause unexpected code failures.
*/
void  CrBufr_BufrInfo_SetStatus( crbufrinfo_t* crBufrInfoPtr,
                                 const crbufrstatus_t newBufrStatus)
{
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      crBufrInfoPtr->statusByte = (uint8_t)newBufrStatus;
   }
   // done
   return;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFOMRATION SET STATUS EXCHANGE
*
*  Sets the "Exchange Status Byte" field (converted from enumerated type to 
*  'uint8_t') of the structure pointed to by 'crBufrInfoPtr'.
*  @returns    void
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*  @param[in]  newStatusExchg - value of the enumerated type for a new Exchange Status
*
*  @details
*  If 'crBufrInfoPtr' is a NULL POINTER, no action is performed.
*
*  @warning
*  This code does not check the value of 'newStatusExchg'.  This should be 
*  checked by higher-level code.  An invalid or incorrect value of 'newStatusExchg'
*  may cause unexpected code failures.
*
*/
void  CrBufr_BufrInfo_SetStatusExchng( crbufrinfo_t* crBufrInfoPtr,
                                       const exchangestatus_t newStatusExchg)
{
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      crBufrInfoPtr->exchangeStatusByte = (uint8_t)newStatusExchg;
   }
   // done
   return;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION SET TICK VALUE
*
*  Sets the "Tick Value" field of the structure pointed to by 'crBufrInfoPtr'.
*  @returns    void
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*  @param[in]  newTickValue - 32-bit 'ticks' value
*
*  @details
*  If 'crBufrInfoPtr' is a NULL POINTER, no action is performed.
*
*  @note
*  If a "Tick Counter" is active, the "Tick Value" field will be set by CR code
*  to the value of the ticks counter coincident with the beginning of message 
*  reception or transmission.  This value may be used to measure time differences 
*  between messages or to synchronize "clocks" between a BASE and a SENSOR device.
*/
void  CrBufr_BufrInfo_SetTickValue( crbufrinfo_t* crBufrInfoPtr, 
                                    const uint32_t newTickValue)
{
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      crBufrInfoPtr->tickValue = newTickValue;
   }
   // done
   return;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION SET UNUSED
*
*  Sets the fields of the selected "Buffer Information Structure" appropriately
*  for UNUSED.
*  @returns    void
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  If the passed parameter is a NULL POINTER, this function performs no action.
*  Sets the "Buffer Information Structure" to UNUSED by setting 'bufrPtr' to
*  Null Pointer.
*
*  @note
*  This code also forces other fields of the Buffer Information Structure to
*  default values.  This may change at a later time.
*/
void  CrBufr_BufrInfo_SetUnused( crbufrinfo_t* crBufrInfoPtr)
{
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      CrBufr_BufrInfoStruct_InitAsUnused( crBufrInfoPtr);
      // Initialize the other fields to default values
      CrBufr_BufrInfoStruct_InitDefault( crBufrInfoPtr);
   }
   return;
}


/** ***************************************************************************
*  CR BUFFER BUFFER INFORMATION SET UNUSED IF NOT BUSY
*
*  Sets the fields of the selected "Buffer Information Structure" appropriately
*  for UNUSED if-and-only-if the buffer status is not BUSY
*  @returns    value of enumerated type 'crbufrstatus_t'
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  If the passed parameter is a NULL POINTER, this function performs no action
*  and returns a value of eCRBUFRSTATUS_NULL
*  Checks the buffer status for eCRBUFRSTATUS_RXBUSY or eCRBUFRSTATUS_TXBUSY.
*  If the status is not equal to either of these values, the code sets the 
*  "Buffer Information Structure" to UNUSED.
*
*  @note
*  The code disables interrupts while performing the check of status and setting
*  the structure to UNUSED.  This handles situation where a radio interrupt
*  occurs while processing this procedure.  Interrupts are disabled for the
*  shortest time possible.
*
*  @note
*  This code also forces other fields of the Buffer Information Structure to
*  default values.  This may change at a later time.
*/
crbufrstatus_t  CrBufr_BufrInfo_UnusedIfNotBusy( crbufrinfo_t* crBufrInfoPtr)
{
   uint32_t  primaskValue;
   crbufrstatus_t  bufrInfoStatus;
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      // *** CRITICAL SECTION BEGIN ***
      // Save PRIMASK register and set to disable interrupts
      //   (see note above)
      primaskValue = (uint32_t)__get_PRIMASK();
      (void)__set_PRIMASK( 1u);
      // get buffer info status, if not busy set structure to UNUSED
      bufrInfoStatus = (crbufrstatus_t)crBufrInfoPtr->statusByte;
      if( (bufrInfoStatus != eCRBUFRSTATUS_RXBUSY) &&
          (bufrInfoStatus != eCRBUFRSTATUS_TXBUSY)  )
      {
         CrBufr_BufrInfoStruct_InitAsUnused( crBufrInfoPtr);
      }
      // Restore PRIMASK register       
     (void)__set_PRIMASK( primaskValue);
      // *** CRITICAL SECTION END ***
      // ***
      // finish clearing structure, if not busy
      if( (bufrInfoStatus != eCRBUFRSTATUS_RXBUSY) &&
          (bufrInfoStatus != eCRBUFRSTATUS_TXBUSY)  )
      {
         // Initialize the structure to default values
         CrBufr_BufrInfoStruct_InitDefault( crBufrInfoPtr);
         // Set 'bufrInfoStatus' to UNUSED.
         bufrInfoStatus = eCRBUFRSTATUS_UNUSED;
      }
   }
   else
   {
      // Set 'bufrInfoStatus' to eCRBUFRSTATUS_NULL
      bufrInfoStatus = eCRBUFRSTATUS_NULL;
   }
   // done
   return bufrInfoStatus;
}


/** ***************************************************************************
*  CR BUFFER LOAD RECEIVE BUFFER INFORMATION
*
*  Adds a receive buffer to the specifc Buffer Information Structure passed by
*  pointer.
*  @returns    an enumerated value that represents the status of the message in
*              the Buffer Information Structure after execution of the function.
*  @param[in]  rxBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*  @param[in]  rxBufrPtr - pointer to buffer to store receive message bytes
*  @param[in]  rxBufrSize - size (in bytes) of buffer to store receive message
*  @param[in]  rxBufrFlags - value of enumerated type for receive buffer flags
*
*  @details
*  The Buffer Information structure pointed to by 'rxBufrInfoPtr' is over-written 
*  with new values for "buffer pointer" and "buffer size"; the buffer information 
*  "status" is changed to RX READY and the "exchange status" is set to an error 
*  value.
*
*  If either 'rxBufrInfoPtr' or 'rxBufrPtr' is a NULL POINTER, no fields of the
*  structure are modified and the function returns eCRBUFRSTATUS_ERROR.
*
*  If 'rxBufrSize' is not greater-than or equal-to the minimum number of bytes
*  for a receive buffer, no variables are modified and the function returns 
*  eCRBUFRSTATUS_ERROR.
*
*  @note
*  The Buffer Unformation structure is NOT checked for "Unused" prior to being 
*  "loaded".  This should be done by higher-level code.
*
*  @warning
*  This code does not verify that 'rxBufrPtr' has not already been loaded into
*  some other Buffer Information Structure.  Unexpected results may occur if
*  'rxBufrPtr' is "loaded" multiple times.  Higher-level code should be
*  constructed so that 'rxBufrPtr' is loaded no more than once without
*  first removing.
*/
crbufrstatus_t  CrBufr_LoadRxBufrInfo( crbufrinfo_t* rxBufrInfoPtr, 
                                       uint8_t* rxBufrPtr,
                                       const uint8_t  rxBufrSize,
                                       const crrxflags_t rxBufrFlags)
{
   crbufrstatus_t  status;
   if( (rxBufrInfoPtr != CONST_NULLPTR) && 
       (rxBufrPtr != CONST_NULLPTR) &&
       (rxBufrSize >= CONST_RXBUFFER_SIZE_MIN) )
   {
      CrBufr_BufrInfoStruct_NewRx( rxBufrInfoPtr, rxBufrPtr, rxBufrSize, (uint8_t)rxBufrFlags);
      // Set the return value to the status of the buffer
      status = (crbufrstatus_t)(rxBufrInfoPtr->statusByte);
   }
   else
   {
      // One of the passed pointers is NULL or 'rxBufrSize' is too small
      status = eCRBUFRSTATUS_ERROR;
   }
   // done
   return status;
}


/** ***************************************************************************
*  CR BUFFER LOAD TRANSMIT BUFFER INFORMATION
*
*  Adds a transmit buffer (contianing a message) to the specifc Buffer 
*  Information Structure passed by pointer.
*  @returns    an enumerated value that represents the status of the message in
*              the Buffer Information Structure after execution of the function.
*  @param[in]  txBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*  @param[in]  txMsgPtr - pointer to bytes of transmit message
*  @param[in]  txMsgLength - size (in bytes) of transmit message
*  @param[in]  txMsgFlags - value of enumerated type of transmit message flags
*  @param[in]  deviceIdValue - 32-bit Device Identifier value
*
*  @details
*  The Buffer Information structure pointed to is over-written with new values;
*  the buffer information "status" is changed to TX READY and the "exchange 
*  status" is set to an error value.  A "transmit sequence number" is generated 
*  and saved in the structure.
*
*  If either 'txBufrInfoPtr' or 'txBufrPtr' is a NULL POINTER, no fields of the
*  structure are modified and the function returns eCRBUFRSTATUS_ERROR.
*  
*  @note
*  The Buffer Unformation structure is NOT checked for "Unused" prior to being 
*  "loaded".  This should be done by higher-level code.
*
*  @warning
*  This code does not verify that 'txMsgPtr' has not already been loaded into
*  some other Buffer Information Structure.  Unexpected results may occur if
*  'txMsgPtr' is "loaded" multiple times.  Higher-level code should be
*  constructed so that 'txMsgPtr' is loaded no more than once without removing.
*/
crbufrstatus_t  CrBufr_LoadTxBufrInfo( crbufrinfo_t* txBufrInfoPtr, 
                                       uint8_t* txMsgPtr,
                                       const uint8_t txMsgLength,
                                       const crtxflags_t txMsgFlags,
                                       const uint32_t    deviceIdValue)
{
   crbufrstatus_t  status;
   if( (txBufrInfoPtr != CONST_NULLPTR) && (txMsgPtr != CONST_NULLPTR) )
   {
      
      // Except for the pointers, the passed data is not checked
      // Update the transmit sequence number before using value.
      s_txSequenceCntr = CrBufr_SequenceNum_Next( s_txSequenceCntr);
      CrBufr_BufrInfoStruct_NewTx( txBufrInfoPtr,
                                   txMsgPtr,
                                   txMsgLength,
                                   (uint8_t)txMsgFlags,
                                   deviceIdValue,
                                   s_txSequenceCntr);
      // Set the return value to SUCCESS
      status = eCRBUFRSTATUS_TXREADY;
   }
   else
   {
      // One of the passed pointers is NULL
      status = eCRBUFRSTATUS_ERROR;
   }
   // done
   return status;
}


/** ***************************************************************************
*  CR BUFFER Rx ASSIGN RECEIVED SEQUENCE NUMBER
*
*  Assigns an new sequence number to the structure pointed to by 'rxBufrInfoPtr'.
*  @returns    void
*  @param[in]  rxBufrInfoPtr - pointer to a specific Receive Buffer Information Structure
*
*  @details
*  If the passed parameter is a NULL POINTER, this function performs no action,
*  else a new receive sequence number is generated and assigned to the Buffer
*  Information Stucture.
*
*  @note
*  The receive sequence number is used to "find" the oldest receive buffer in
*  the array of Receive Buffer Information Structures.
*
*  @warning
*  This procedure does NOT check the "status" of the Buffer Information Structure
*  to ensure that it contains a correctly received message.  This should be done
*  by higher-level code.
*/
void  CrBufr_Rx_AssignRcvdSequenceNum( crbufrinfo_t* rxBufrInfoPtr)
{
   if( rxBufrInfoPtr != CONST_NULLPTR)
   {
      // Generate the next receive sequence number before assigning it to the 
      //    structure
      s_rxSequenceCntr = CrBufr_SequenceNum_Next( s_rxSequenceCntr);
      rxBufrInfoPtr->sequenceNum = s_rxSequenceCntr;
   }
   // done
   return;
}


/** ***************************************************************************
*  CR BUFFER Rx COUNT WITH STATUS
*
*  Returns the number of receive buffer information slots with the passed
*  status value
*  @returns    an unsigned 16-bit value
*  @param[in]  statusValue - value of enumerated type 'crbufrstatus_t'
*/
uint16_t  CrBufr_Rx_CountWithStatus( const crbufrstatus_t statusValue)
{
   uint16_t count;
   count = CrBufr_Count_WithStatus( s_rxBufrInfo, CONFIG_RECEIVE_BUFFERS_MAXINDX,
                                                  statusValue); 
   // done
   return count;
}


/** ***************************************************************************
*  CR BUFFER Rx FIND MATCHING BUFFER
*
*  Returns a pointer to the Receive Buffer Information structure that is found
*  by searching the entire Receive Buffer Information array for a 'bufrPtr'
*  that is equal to 'rxBufrPr'.
*  @returns    a pointer to an entry in the Receive Buffer Information array.
*  @param[in]  rxBufrPtr - pointer to a specific receive message buffer.
*
*  @details
*  This function will return a NULL POINTER if no "matching" rx buffer pointer
*  is found.  This function will a return a NULL POINTER if the passed parameter
*  is a NULL POINTER.
*
*  Given a pointer to a receive buffer or a receive message, this function will
*  return a pointer to the Buffer Information structure that contains a matching
*  pointer to the receive buffer.  This allows code to "get" or modify fields 
*  associated with the receive buffer. 
*
*  @note
*  This code matches the passed receive message buffer by comparing pointer
*  values.  It does NOT compare the bytes in the receive buffer.
*
*  @warning
*  The search ceases when a matching value is found for 'rxBufrPtr'.  Higher-
*  level code should be constructured to "load" 'rxBufrPtr' no more than once
*  without removing.
*/
crbufrinfo_t*  CrBufr_Rx_FindMatchingBufr( const uint8_t* rxBufrPtr)
{
   crbufrinfo_t*   crBufrInfoPtr;
   if( rxBufrPtr != CONST_NULLPTR)
   {
      crBufrInfoPtr = CrBufr_Find_MatchingBufrPtr( s_rxBufrInfo, 
                                                   CONFIG_RECEIVE_BUFFERS_MAXINDX, 
                                                   rxBufrPtr);
   }
   else
   {
      crBufrInfoPtr = CONST_NULLPTR;
   }
   return crBufrInfoPtr;
}


/** ***************************************************************************
*  CR BUFFER Rx FIND NEXT RX READY
*
*  Returns a pointer to the Receive Buffer Information structure that is the
*  first found that has a status equal-to eCRBUFRSTATUS_RXREADY.
*  @returns    a pointer to an entry in the Receive Buffer Information array.
*
*  @details
*  This function will return a NULL POINTER if no entry in the Receive Buffer
*  Information array is found to have a status of eCRBUFRSTATUS_RXREADY.
*
*  This function is used to find the "next" receive buffer that is READY to 
*  take a receive message.
*
*  @note
*  The Rx Buffer Information array is "searched" in order of increasing index 
*  in the array.
*/
crbufrinfo_t*  CrBufr_Rx_FindNextRxReady( void)
{
   crbufrinfo_t*   crBufrInfoPtr;
   crBufrInfoPtr = CrBufr_Find_FirstWithStatus( s_rxBufrInfo, 
                                                CONFIG_RECEIVE_BUFFERS_MAXINDX,
                                                eCRBUFRSTATUS_RXREADY);
   return crBufrInfoPtr;
}


/** ***************************************************************************
*  CR BUFFER Rx FIND NEXT RX RECEIVED
*
*  Returns a pointer to the Receive Buffer Information structure that is the
*  OLDEST buffer that has a received message with a matching Device Identifier. 
*  @returns    a pointer to an entry in the Receive Buffer Information array.
*  @param[in]  matchDeviceId - 32-bit value of the Device Identifier to match during the search.
*
*  @details
*  This function will return a NULL POINTER if no entry in the Receive Buffer
*  Information array is found to have a status of eCRBUFRSTATUS_RXMSGRCVD and
*  a matching Device Identifier.
*
*  This function is used to find the "oldest" receive buffer that has a receive
*  message.  The "oldest" receive buffer is determined by comparing the receive
*  sequence numbers.  The search can filter for a message with a specific 
*  Device Identifier.  If a buffer with a received message from ANY device is
*  desired, this function should be called with a 'matchDeviceId' equal-to
*  CONST_DEVICEID_ALWAYS_MATCH.
*
*  @note
*  See comments for "CrDeviceID_IsMatch" for "matching" rules.
*/
crbufrinfo_t*   CrBufr_Rx_FindNextRxRcvd( const uint32_t matchDeviceId)
{
   crbufrinfo_t*   crBufrInfoPtr;
   crBufrInfoPtr = CrBufr_Find_OldestWithStatus( s_rxBufrInfo,   
                                                 CONFIG_RECEIVE_BUFFERS_MAXINDX,
                                                 s_rxSequenceCntr,
                                                 eCRBUFRSTATUS_RXMSGRCVD,
                                                 matchDeviceId);
   return crBufrInfoPtr;
}


/** ***************************************************************************
*  CR BUFFER Rx FIND UNUSED
*
*  Returns a pointer to a Receive Buffer Information structure that is UNUSED.
*  @returns    a pointer to an entry in the Receive Buffer Information array.
*
*  @details
*  This function will return a NULL POINTER if no entry in the Receive Buffer
*  Information array is UNUSED.
*
*  @note
*  The Rx Buffer Information array is "searched" in order of increasing index 
*  in the array.
*/
crbufrinfo_t*  CrBufr_Rx_FindUnused( void)
{
   crbufrinfo_t*   crBufrInfoPtr;
   crBufrInfoPtr = CrBufr_Find_FirstWithStatus( s_rxBufrInfo, 
                                                CONFIG_RECEIVE_BUFFERS_MAXINDX,
                                                eCRBUFRSTATUS_UNUSED);
   return crBufrInfoPtr;
}


/** ***************************************************************************
*  CR BUFFER Tx COUNT WITH STATUS
*
*  Returns the number of transmit buffer information slots with the passed
*  status value
*  @returns    an unsigned 16-bit value
*  @param[in]  statusValue - value of enumerated type 'crbufrstatus_t'
*/
uint16_t  CrBufr_Tx_CountWithStatus( const crbufrstatus_t statusValue)
{
   uint16_t count;
   count = CrBufr_Count_WithStatus( s_txBufrInfo, CONFIG_TRANSMIT_BUFFERS_MAXINDX, 
                                                  statusValue); 
   // done
   return count;
}


/** ***************************************************************************
*  CR BUFFER Tx FIND MATCHING BUFFER
*
*  Returns a pointer to the Transmit Buffer Information structure that is found
*  by searching the entire Transmit Buffer Information array for a 'bufrPtr'
*  that is equal to 'txBufrPr'.
*  @returns    a pointer to an entry in the Receive Buffer Information array.
*  @param[in]  txBufrPtr - pointer to a specific transmit message buffer.
*
*  @details
*  This function will return a NULL POINTER if no "matching" tx buffer pointer
*  is found.   The function will return a NULL POINTER if the passed parameter
*  is a NULL POINTER.
*
*  Given a pointer to a transmit buffer (a transmit message), this function will
*  return a pointer to the Buffer Information structure that contains a matching
*  pointer to the transmit buffer.  This allows code to "get" or modify fields 
*  associated with the transmit buffer.
*
*  @note
*  This code matches the passed transmit message buffer by comparing pointer
*  values.  It does NOT compare the bytes in the message.
*
*  @warning
*  The search ceases when a matching value is found for 'txBufrPtr'.  Higher-
*  level code should be constructured to "load" 'txBufrPtr' no more than once
*  without removing.
*/
crbufrinfo_t*  CrBufr_Tx_FindMatchingBufr( const uint8_t* txBufrPtr)
{
   crbufrinfo_t*   crBufrInfoPtr;
   if( txBufrPtr != CONST_NULLPTR)
   {
      crBufrInfoPtr = CrBufr_Find_MatchingBufrPtr( s_txBufrInfo, 
                                                   CONFIG_TRANSMIT_BUFFERS_MAXINDX, 
                                                   txBufrPtr);
   }
   else
   {
      crBufrInfoPtr = CONST_NULLPTR;
   }
   return crBufrInfoPtr;
}


/** ***************************************************************************
*  CR BUFFER Tx FIND NEXT TX READY
*
*  Returns a pointer to the Transmit Buffer Information structure that is the
*  OLDEST buffer that has a message READY to transmit. 
*  @returns    a pointer to an entry in the Transmit Buffer Information array.
*  @param[in]  matchDeviceId - 32-bit value of the Device Identifier to match during the search.
*
*  @details
*  This function will return a NULL POINTER if no entry in the Transmit Buffer
*  Information array is found to have a status of eCRBUFRSTATUS_TXREADY and
*  a matching Device Identifier.
*
*  This function is used to find the "oldest" transmit message that is READY to
*  transmit.  The "oldest" transmit message is determined by comparing the 
*  transmit sequence numbers.  The search can filter for a message with a 
*  specific Device Identifier.  If a buffer with a transmit message from ANY 
*  device is desired, this function should be called with a 'matchDeviceId' 
*  equal-to CONST_DEVICEID_ALWAYS_MATCH.
*
*  @note
*  See comments for "CrDeviceID_IsMatch" for "matching" rules.
*/
crbufrinfo_t*  CrBufr_Tx_FindNextTxReady( const uint32_t matchDeviceId)
{
   crbufrinfo_t*   crBufrInfoPtr;
   crBufrInfoPtr = CrBufr_Find_OldestWithStatus( s_txBufrInfo,   
                                                 CONFIG_TRANSMIT_BUFFERS_MAXINDX,
                                                 s_txSequenceCntr,
                                                 eCRBUFRSTATUS_TXREADY,
                                                 matchDeviceId);
   return crBufrInfoPtr;
}


/** ***************************************************************************
*  CR BUFFER Tx SENT FIND NEXT TX SENT
*
*  Returns a pointer to the Transmit Buffer Information structure that is the
*  OLDEST buffer with a "matching Device Identifier" that has a message which 
*  has been sent. 
*  @returns    a pointer to an entry in the Transmit Buffer Information array.
*  @param[in]  matchDeviceId - 32-bit value of the Device Identifier to match during the search.
*
*  @details
*  This function will return a NULL POINTER if no entry in the Transmit Buffer
*  Information array is found to have a status of eCRBUFRSTATUS_TXMSGSENT and
*  a matching Device Identifier.
*
*  This function is used to find the "oldest" transmit message that has been 
*  sent.  The "oldest" transmit message is determined by comparing the 
*  transmit sequence numbers.  The search can filter for a message with a 
*  specific Device Identifier.  If a buffer with a transmit message from ANY 
*  device is desired, this function should be called with a 'matchDeviceId' 
*  equal-to CONST_DEVICEID_ALWAYS_MATCH.
*
*  @note
*  See comments for "CrDeviceID_IsMatch" for "matching" rules.
*/
crbufrinfo_t*  CrBufr_Tx_FindNextTxSent( const uint32_t matchDeviceId)
{
   crbufrinfo_t*   crBufrInfoPtr;
   crBufrInfoPtr = CrBufr_Find_OldestWithStatus( s_txBufrInfo,   
                                                 CONFIG_TRANSMIT_BUFFERS_MAXINDX,
                                                 s_txSequenceCntr,
                                                 eCRBUFRSTATUS_TXMSGSENT,
                                                 matchDeviceId);
   return crBufrInfoPtr;
}


/** ***************************************************************************
*  CR BUFFER Tx FIND UNUSED
*
*  Returns a pointer to a Transmit Buffer Information structure that is UNUSED.
*  @returns    a pointer to an entry in the Transmit Buffer Information array.
*
*  @details
*  This function will return a NULL POINTER if no entry in the Transmit Buffer
*  Information array is UNUSED.
*
*  @note
*  The Tx Buffer Information array is "searched" in order of increasing index 
*  in the array.
*/
crbufrinfo_t*  CrBufr_Tx_FindUnused( void)
{
   crbufrinfo_t*   crBufrInfoPtr;
   crBufrInfoPtr = CrBufr_Find_FirstWithStatus( s_txBufrInfo, 
                                                CONFIG_TRANSMIT_BUFFERS_MAXINDX,
                                                eCRBUFRSTATUS_UNUSED);
   return crBufrInfoPtr;
}



/* ***************************************************************************/
/* ***************************************************************************
*  PRIVATE PROCEDURES -- in alphabetical order
*/

/** ***************************************************************************
*  CR BUFFER BUFFER INFO ARRAY REMOVE ALL
*
*  Sets all elements of the 'bufferInfoArray' to UNUSED.
*  @returns    void
*  @param[in]  bufrInfoArray - pointer to an array of Buffer Information structures
*  @param[in]  maxArrayIndx - the number of structures in the array
*
*  @details
*  This code interates through each structure in the Buffer Information Array
*  and sets the structure to UNUSED.
*
*  @note
*  This code does NOT check 'bufrInfoArray' for NULL POINTER.
*  @note
*  This code does NOT check 'maxArrayIndx' for valid range.
*/
static void  CrBufr_BufrInfoArray_RemoveAll( crbufrinfo_t bufrInfoArray[],
                                             const uint16_t maxArrayIndx)
{
   uint16_t indx;
   for( indx = 0u; indx <= maxArrayIndx; indx +=1u)
   {
      CrBufr_BufrInfoStruct_InitAsUnused( &(bufrInfoArray[ indx]));
      // Initialize the other fields to default values
      CrBufr_BufrInfoStruct_InitDefault( &(bufrInfoArray[ indx]));
   }
   // done
   return;
}


/** ***************************************************************************
*  CR BUFFER INFO STRUCTURE GET STATUS
*
*  This function returns the status of the buffer "pointed to" by 'crBufrInfoPtr'.
*  @returns    an enumerated value that represents the status of the message in
*              the Buffer Information Structure.
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  If the Buffer Information Structure is UNUSED, the status eCRBUFRSTATUS_UNUSED 
*  is returned; otherwise the value in the 'statusByte' field is converted to the
*  enumerated type and returned.
*
*  @note
*  This function DOES NOT check for 'crBufrInfoPtr' equal-to NULL POINTER.  
*/
static __INLINE crbufrstatus_t  CrBufr_BufrInfoStruct_GetStatus( const crbufrinfo_t* crBufrInfoPtr)
{
   crbufrstatus_t  bufrStatus;
   bool  isUnused;
   isUnused = CrBufr_BufrInfoStruct_IsUnused( crBufrInfoPtr);
   if( isUnused == true)
   {
      bufrStatus = eCRBUFRSTATUS_UNUSED;
   }
   else
   {
      bufrStatus = (crbufrstatus_t)crBufrInfoPtr->statusByte;
   }
   return bufrStatus;
}


/** ***************************************************************************
*  CR BUFFER INFO STRUCTURE INITIALIZE AS UNUSED
*
*  Sets the fields of the selected "Buffer Information Structure" appropriately
*  for UNUSED.
*  @returns    void
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  A Buffer Information Structure is deemed UNUSED if the 'bufrPtr' field is
*  equal to NULL POINTER.  To make "UNUSED" the information structure, the 
*  'bufrPtr' MUST be set to CONST_NULLPTR.  The status byte is also set.
*
*  @note
*  This procedure does not check 'crBufrInfoPtr' for NULL POINTER value.  This
*  should be done with higher-level code.
*/
static void  CrBufr_BufrInfoStruct_InitAsUnused( crbufrinfo_t* crBufrInfoPtr)
{
   crBufrInfoPtr->bufrPtr = CONST_NULLPTR;
   crBufrInfoPtr->statusByte = (uint8_t)eCRBUFRSTATUS_UNUSED;
   return;
}


/** ***************************************************************************
*  CR BUFFER INFO STRUCTURE INITIALIZE DEFAULT
*
*  Sets the fields of the selected "Buffer Information Structure" to default
*  values.
*  @returns    void
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  Sets the fields to default values.
*
*  @note
*  This procedure does not modify the field 'bufrPtr' or 'statusByte'
*/
static  void  CrBufr_BufrInfoStruct_InitDefault( crbufrinfo_t* crBufrInfoPtr)
{
   crBufrInfoPtr->tickValue = CONST_TICKSVALUE_INVALID;
   crBufrInfoPtr->sequenceNum = (crsequencnum_t)0u;
   crBufrInfoPtr->reserved16 = (uint16_t)0u;
   crBufrInfoPtr->exchangeStatusByte = (uint8_t)eEXCHANGE_ERROR;
   crBufrInfoPtr->msgFlagsByte = (uint8_t)0u;
   crBufrInfoPtr->bufrSize = (uint8_t)0u;
   crBufrInfoPtr->deviceID = CONST_DEVICEID_INVALID;
   // done
   return;
}


/** ***************************************************************************
*  CR BUFFER INFO STRUCTURE IS UNUSED
*
*  This function detemines if the buffer "pointed to" by 'crBufrInfoPtr' is
*  UNUSED.
*  @returns    boolean 'true' if the parameter points to an UNUSED Buffer 
*              Information Structure
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*
*  @details
*  The function accesses the 'bufrPtr' field of 'crBufrInfoPtr'.
*  If the pointer is NULL, 'crBufrInfoPtr' is considered UNUSED and the function
*  returns TRUE; OTHERWISE the location is considered NOT UNUSED and the 
*  function returns FALSE.
*
*  NOTE: 'crBufrInfoPtr' must be checked for NULL POINTER by higher-level code.  
*/
static __INLINE bool  CrBufr_BufrInfoStruct_IsUnused( const crbufrinfo_t* crBufrInfoPtr)
{
   bool  isUnused;
   if( crBufrInfoPtr->bufrPtr == CONST_NULLPTR)
   {
      isUnused = true;
   }
   else
   {
      isUnused = false;
   }
   return isUnused;
}


/** ***************************************************************************
*  CR BUFFER INFO STRUCTURE NEW RX
*
*  This procedure loads the Rx Buffer Info structure.
*  @returns    void
*  @param[in]  rxBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*  @param[in]  rxBufrPtr - pointer to buffer to store receive message bytes
*  @param[in]  rxBufrSize - size (in bytes) of buffer to store receive message
*  @param[in]  rxBufrFlagsByte - byte value of receive buffer flags
*
*  @details
*  The status byte of the structure is set to a converted version of
*  eCRBUFRSTATUS_RXREADY.
*
*  @note
*  'rxBufrInfoPtr' must be checked for NULL POINTER by higher-level code.
*  The field 'bufrPtr' is intentionally set after other parameters are
*  loaded and the "status byte" is set to ready.
*/
static void  CrBufr_BufrInfoStruct_NewRx( crbufrinfo_t* rxBufrInfoPtr, 
                                          uint8_t* rxBufrPtr, 
                                          const uint8_t rxBufrSize,
                                          const uint8_t rxBufrFlagsByte)
{
   // Load the Rx Buffer Info structure
   rxBufrInfoPtr->bufrSize = rxBufrSize;
   rxBufrInfoPtr->msgFlagsByte = rxBufrFlagsByte;   
   rxBufrInfoPtr->statusByte = (uint8_t)eCRBUFRSTATUS_RXREADY;
   rxBufrInfoPtr->exchangeStatusByte = (uint8_t)eEXCHANGE_ERROR;
   rxBufrInfoPtr->bufrPtr = rxBufrPtr;
   // The 'tickValue', 'sequenceNum' and 'deviceId' are not set here
   // ('statusByte' of eCRBUFRSTATUS_RXREADY means these fields are invalid)
   // done
   return;
}


/** ***************************************************************************
*  CR BUFFER INFO STRUCTURE NEW TX
*
*  This procedure loads the Tx Buffer Info structure.
*  @returns    void
*  @param[in]  txBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*  @param[in]  txMsgPtr - pointer to bytes of transmit message
*  @param[in]  txMsgLength - length (in bytes) of transmit message
*  @param[in]  txMsgFlagsByte - byte value of transmit message flags
*  @param[in]  deviceIdValue - 32-bit value of Device Identifier
*  @param[in]  sequenceNum - 16-bit value of sequence number
*
*  @note
*  'txBufrInfoPtr' must be checked for NULL POINTER by higher-level code.
*  The field 'bufrPtr' is intentionally set last.
*/
static void  CrBufr_BufrInfoStruct_NewTx( crbufrinfo_t* txBufrInfoPtr,
                                          uint8_t* txMsgPtr,
                                          const uint8_t txMsgLength,
                                          const uint8_t txMsgFlagsByte,
                                          const uint32_t deviceIdValue,
                                          const uint16_t sequenceNum)
{
   // 'bufrSize' is set to 'txLength'
   txBufrInfoPtr->bufrSize = txMsgLength;
   txBufrInfoPtr->deviceID = deviceIdValue;
   txBufrInfoPtr->msgFlagsByte = txMsgFlagsByte;
   txBufrInfoPtr->sequenceNum = s_txSequenceCntr;
   txBufrInfoPtr->statusByte = (uint8_t)eCRBUFRSTATUS_TXREADY;
   txBufrInfoPtr->exchangeStatusByte = (uint8_t)eEXCHANGE_ERROR;
   txBufrInfoPtr->bufrPtr = txMsgPtr;
   // The 'tickValue' is not set here
   // done
   return;
}


/** ***************************************************************************
*  CR BUFFER CHOOSE OLDER
*
*  Returns the "older" of two messages buffers "pointed to" by 'crBufrInfoPtr1'
*  and 'crBufrInfoPtr2'.
*  @returns   pointer to a "CR Buffer Information Structure"
*  @param[in] crBufrInfoPtr1 - pointer to first "Cr Buffer Information Structure"
*  @param[in] crBufrInfoPtr2 - pointer to second "Cr Buffer Information Structure"
*  @param[in] sequenceCntr - value of the appropriate sequence counter
*
*  @details
*  The "age" of the messages are determined by the "sequence numbers" associated 
*  with the messages and the current "sequence counter" value.
*
*  @note
*  The value of the two sequences numbers shold never be equal.  This code 
*  handles this by declaring the first sequence number "older"
*/
static  crbufrinfo_t*  CrBufr_Choose_Older( crbufrinfo_t* crBufrInfoPtr1,
                                            crbufrinfo_t* crBufrInfoPtr2,
                                            const crsequencnum_t sequenceCntr)
{
   crbufrinfo_t*  olderBufrInfoPtr;
   uint32_t  ageMsg1;
   uint32_t  ageMsg2;
   if( crBufrInfoPtr1 == CONST_NULLPTR)
   {
      // 'crBufrInfoPtr1' is NULL; the other pointer must be older
      olderBufrInfoPtr = crBufrInfoPtr2;
   }
   else
   {
      ageMsg1 = CrBufr_SequenceNum_CalcAge( crBufrInfoPtr1, sequenceCntr);
      ageMsg2 = CrBufr_SequenceNum_CalcAge( crBufrInfoPtr2, sequenceCntr);
      if( ageMsg1 >= ageMsg2)
      {
         olderBufrInfoPtr = crBufrInfoPtr1;
      }
      else
      {
         olderBufrInfoPtr = crBufrInfoPtr2;
      }
   }
   return olderBufrInfoPtr;
}


/** ***************************************************************************
*  CR BUFFER COUNT WITH STATUS
*
*  Returns the number of buffer information slots having status equal-to 
*  'statusValue'
*  @returns    an unsigned 16-bit value
*  @param[in]  bufrInfoArray - pointer to an array of Buffer Information structures
*  @param[in]  maxArrayindx - number of structures in the array
*  @param[in]  statusValue - value of enumerated type 'crbufrstatus_t'
*
*  Index through 'bufrInfoArray' fetching the status of each entry; if the status
*  matches 'statusValue', the 'count' is incremented.
*/
static uint16_t CrBufr_Count_WithStatus( const crbufrinfo_t bufrInfoArray[], 
                                         const uint16_t maxArrayIndx,
                                         const crbufrstatus_t statusValue)
{
   uint16_t  count;
   uint16_t  indx;
   crbufrstatus_t  bufrStatus;
   count = 0u;
   // "Index" through the entire array from the first ('0') to the last
   //   ('maxArrayIndx')
   for( indx = 0u; indx <= maxArrayIndx; indx +=1u)
   {
      bufrStatus = CrBufr_BufrInfoStruct_GetStatus( &bufrInfoArray[ indx]);
      if( bufrStatus == statusValue)
      {
         count += 1u;
      }
   }
   // done
   return count;
}


/** ***************************************************************************
*  CR BUFFER FIND FIRST WITH STATUS
*
*  Given a array of Buffer Information structures, returns a pointer to the 
*  Buffer Information structure with the lowest index that has a 'statusByte' 
*  field equivalent to 'statusValue'
*  @returns    pointer to a "CR Buffer Information Structure"
*  @param[in]  bufrInfoArray - pointer to an array of Buffer Information structures
*  @param[in]  maxArrayIndx - the number of structures in the array
*  @param[in]  statusValue - value of enumerated type 'crbufrstatus_t'
*
*  @detail
*  If no Buffer Information Structure has a 'statusByte' that matches
*  'statusValue', a NULL POINTER is returned.
*
*  @note
*  This does NOT return information structures in the order that they were 
*  "added" to 'bufrInfoArray'.
*  @note
*  This code does NOT check 'bufrInfoArray' for NULL POINTER.
*  @note
*  This code does NOT check 'maxArrayIndx' for valid range.
*/
static crbufrinfo_t*  CrBufr_Find_FirstWithStatus( crbufrinfo_t bufrInfoArray[],
                                                   const uint16_t maxArrayIndx,   
                                                   const crbufrstatus_t statusValue)
{
   crbufrinfo_t*   crBufrInfoPtr;
   crbufrstatus_t  bufrStatus;
   uint16_t  indx;
   // Initialize the return pointer
   crBufrInfoPtr = CONST_NULLPTR;
   // "Index" through the entire array from the first ('0') to the last ('maxArrayIndx')
   //      while the return pointer remains NULL
   for( indx = 0u; (indx <= maxArrayIndx) && (crBufrInfoPtr == CONST_NULLPTR); indx += 1u)
   {
      bufrStatus = CrBufr_BufrInfoStruct_GetStatus( &bufrInfoArray[ indx]);
      if( bufrStatus == statusValue)
      {
         // Status Matches
         // Set the return pointer
         crBufrInfoPtr = &bufrInfoArray[ indx];
      }
   }
   // done
   return crBufrInfoPtr;
}


/** ***************************************************************************
*  CR BUFFER FIND OLDEST WITH STATUS
*
*  Given a array of Buffer Information structures, returns a pointer to the 
*  Buffer Information structure with the OLDEST buffer (as determined by the 
*  "age of the sequence number") that has a 'statusByte' field equivalent to 
*  'status' AND a 'deviceID' field that matches 'matchDeviceId'
*  @returns    pointer to a "CR Buffer Information Structure"
*  @param[in]  bufrInfoArray - pointer to an array of Buffer Information structures
*  @param[in]  maxArrayindx - number of structures in the array
*  @param[in]  sequenceCntr - value of the appropriate sequence counter (needed to determine 'oldest')
*  @param[in]  statusValue - value of enumerated type 'crbufrstatus_t'
*  @param[in]  matchDeviceId - 32-bit value of Device Identifier
*
*  @details
*  If a match of the 'deviceID' field is not needed, the function should be called
*  with a 'matchDeviceId' of CONST_SENSORID_ALWAYS_MATCH
*
*  @note
*  This code does NOT check 'bufrInfoArray' for NULL POINTER.
*  @note
*  This code does NOT check 'maxArrayIndx' for valid range.
*/
static crbufrinfo_t*  CrBufr_Find_OldestWithStatus( crbufrinfo_t  bufrInfoArray[],
                                                    const uint16_t  maxArrayindx,
                                                    const crsequencnum_t  sequenceCntr,
                                                    const crbufrstatus_t statusValue,
                                                    const uint32_t  matchDeviceId)
{
   crbufrinfo_t*   crBufrInfoPtr;
   crbufrinfo_t*   oldestInfoPtr;
   crbufrstatus_t  bufrStatus;
   uint16_t  indx;
   bool  deviceIdIsMatch;
   oldestInfoPtr = CONST_NULLPTR;
   for( indx = 0; indx <= maxArrayindx; indx += 1u)
   {
      crBufrInfoPtr = &bufrInfoArray[ indx];
      bufrStatus = CrBufr_BufrInfoStruct_GetStatus( crBufrInfoPtr);
      if( bufrStatus == statusValue)
      {
         deviceIdIsMatch = CrDeviceID_IsMatch( crBufrInfoPtr->deviceID, matchDeviceId);
         if( deviceIdIsMatch == true)
         {         
            // Status and Device Identifier Matches
            // "Choose" the older of the two buffers
            oldestInfoPtr = CrBufr_Choose_Older( oldestInfoPtr, crBufrInfoPtr,  sequenceCntr);
         }
         // end of "Status and Device Identifier Matches"
      }
      // bottom of 'for' loop
   }
   // done
   return oldestInfoPtr;
}


/** ***************************************************************************
*  CR BUFFER FIND MATCHING BUFFER POINTER
*
*  Given a array of Buffer Information structures, returns a pointer to the 
*  Buffer Information structure that contains a 'bufrPtr' field that is equal
*  to the passed parameter 'bufrPtr'.
*  The function returns CONST_NULLPTR, if 'bufrPtr' is equal to CONST_NULLPTR
*  @returns    pointer to a "CR Buffer Information Structure"
*  @param[in]  bufrInfoArray - pointer to an array of Buffer Information structures
*  @param[in]  maxArrayindx - number of structures in the array
*  @param[in]  bufrPtr - pointer to bytes of a receive buffer or transmit message
*
*  @detail
*  If no Buffer Information Structure has a 'bufPtr' field that matches
*  the 'bufrPtr' parameter, a NULL POINTER is returned.
*
*  @note
*  The array is "searched" in order of increasing index in the array.
*  @note
*  This code assumes that only one entry in 'bufrInfoArray' can have a 'bufrPtr' 
*  field that matches.
*  @note
*  The code will fail if 'bufrInfoArray' is equal-to NULL POINTER.
*  @note
*  The "match" is not valid if 'bufrPtr' is equal-to NULL POINTER.
*  @note
*  This code does NOT check 'maxArrayIndx' for valid range.
*/  
static crbufrinfo_t*  CrBufr_Find_MatchingBufrPtr( crbufrinfo_t   bufrInfoArray[],
                                                   const uint16_t maxArrayindx,
                                                   const uint8_t* bufrPtr)
{
   uint16_t indx;
   crbufrinfo_t*  matchBufrInfoPtr;
   matchBufrInfoPtr = CONST_NULLPTR;
   for( indx=0u; (indx<=maxArrayindx) && (matchBufrInfoPtr == CONST_NULLPTR); indx+=1u)
   {
      if( bufrInfoArray[ indx].bufrPtr == bufrPtr)
      {
         // Match is found
         // Set pointer for return
         matchBufrInfoPtr = &bufrInfoArray[ indx];
      }
      // end of 'for' loop
   }
   // done
   return matchBufrInfoPtr;
}


/** ***************************************************************************
*  CR BUFFER SEQUENCE AGE CALCULATE
*
*  Given a pointer to a Buffer Information structure, and the current value of 
*  the corresponding "sequence counter", this function calculates the "age".
*  @returns    an unsigned 32-bit value representing the "age"
*  @param[in]  crBufrInfoPtr - pointer to a "CR Buffer Information Structure"
*  @param[in]  sequenceCntr - one of the sequence counters (a value of type 'crsequencnum_t')
*
*  @details
*  The age of the Buffer Information Structuer is the the modulo 16-bit difference
*  between the "sequence number" field and the "sequence counter".
*
*  @note
*  This function does not check either 'sequenceCntr' nor the 'sequenceNum'
*  in the structure pointed to by 'crBufrInfoPtr' for a valid numerical value.
*  This should be done by higher-level code.
*
*  @warning
*  This code may need to be modified if the type definition of 'crsequencnum_t'
*  is modified.
*/
static __INLINE uint32_t  CrBufr_SequenceNum_CalcAge( const crbufrinfo_t* crBufrInfoPtr, 
                                                      const crsequencnum_t sequenceCntr)
{
   uint16_t  age;
   age = ( (uint16_t)sequenceCntr - crBufrInfoPtr->sequenceNum);
   return (uint32_t)age;
}


/** ***************************************************************************
*  CR BUFFER SEQUENCE NUMBER NEXT
*
*  Returns the next value of the sequence number
*  @returns    a value of type 'sequenceNum' for the "next" sequence number
*  @param[in]  sequenceNum - value of type 'sequenceNum'
*
*  @details
*  Increments the passed value.  If the value is greater-than or equal-to 
*  65534 it sets it to 1.  Thus the value ranges from 1 to 65534, inclusive.
*
*  @note
*  Sequence Number values of 0 and 65535 are reserved.
*/
static __INLINE crsequencnum_t  CrBufr_SequenceNum_Next( const crsequencnum_t sequenceNum)
{
   crsequencnum_t  nextSequenceNum;
   if( sequenceNum < (crsequencnum_t)0xFFFFFFFEuL)
   {
      nextSequenceNum = sequenceNum + 1u;
   }
   else
   {
      nextSequenceNum = 1u;
   }
   return nextSequenceNum;
}



#if 0
/* ***************************************************************************/
/* ***************************************************************************
*  USEFUL CODE - CURRENTLY NOT USED - INCLUDED HERE FOR POSSIBLE FUTURE USE
*
*  CODE SHOULD BE TESTED BEFORE USED.
*/

/* ***************************************************************************
*  CR BUFFER FIND OLDEST
*
*  Given a array of Buffer Information structures, returns a pointer to the 
*  Buffer Information structure with the OLDEST buffer (as determined by the 
*  "age of the sequence number").
*  The buffer must not be UNUSED.
*
*  NOTE: at this time, this function should only be used for Tx Info Structure
*        Array, because the sequence number is valid only for Rx Info Structures
*        with status eCRBUFRSTATUS_RXMSGRCVD (not all Rx Info Structures)
*/
static crbufrinfo_t*  CrBufr_Find_OldestInUse( crbufrinfo_t bufrInfoArray[],   
                                               const uint16_t maxArrayindx,
                                               const crsequencnum_t sequenceCntr)
{
   crbufrinfo_t*   crBufrInfoPtr;
   crbufrinfo_t*   oldestInfoPtr;
   uint16_t  indx;
   bool  isUnused;
   oldestInfoPtr = CONST_NULLPTR;
   for( indx = 0u; indx <= maxArrayindx; indx += 1u)
   {
      crBufrInfoPtr = &bufrInfoArray[ indx];
      isUnused = CrBufr_BufrInfoStruct_IsUnused( crBufrInfoPtr);
      if( isUnused == false)
      {
         oldestInfoPtr = (crbufrinfo_t*)CrBufr_Choose_Older( oldestInfoPtr, 
                                                             crBufrInfoPtr,  
                                                             sequenceCntr);
      }
      // bottom of 'for' loop
   }
   // done
   return oldestInfoPtr;
}
#endif


// END OF CORIANDOLO RADIO BUFFER CODE
/* ************** END OF FILE   CRBUFR_C *********************************** */

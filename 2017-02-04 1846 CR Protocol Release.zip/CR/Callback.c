#define CALLBACK_C

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This module supports procedure "callbacks".
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2014-12-19
*  @date       last modified by Craig Goldman 2016-11-19
*
*
*  @copyright  Copyright (c) 2014, 2015, 2016 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*
*  @details
*  This module (".c" and ".h" files have been created to support procedure
*  "call-backs".  A "call-back" is a procedure with a single paramter and no
*  return value that is "called" by an interrupt service routine in response
*  to an event.
*
*  This file defines the "Callback_Null" procedure, which always does nothing.
*/

/* ***************************************************************************
*  INCLUDE FILES
*/
#include "Callback.h"


/* ***************************************************************************/
/** **************************************************************************
*  MODULE INITIALIZATION PROCEDURE
*
*  -- All modules must have a "..._Init" procedure to initialize static 
*  variables to known values.
*  @returns   void
*/
void Callback_Init( void)
{
   // There are no static variables to initialize
   return;
}


/* ***************************************************************************/
/* ***************************************************************************
*  PUBLIC PROCEDURES
*/

/** ***************************************************************************
*  CALLBACK NULL
*
*  This is a special procedure that does nothing.  It can be used as a default
*  call-back.
*  @returns   void
*  @param[in] argPtr - not used; parameter exists so this procedure is compatible
*             with function type 'callback_t'
*/
void Callback_Null( void* argPtr)
{
   // Do nothing
   // 'argPtr' is not checked or accessed
   return;
}


/* ************** END OF FILE   CALLBACK_C ********************************* */

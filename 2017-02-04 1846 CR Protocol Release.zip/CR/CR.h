#ifndef CR_H
#define CR_H

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This is the public include file for CR.c
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2015-03-22
*  @date       last modified by Craig Goldman 2016-11-09
*
*  @copyright  Copyright (c) 2015, 2016 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*  @details
*  This file is the public include file for CR.c.
*  This file declares public prototypes for using the radio to communicate 
*  between SENSOR and BASE devices with the Coriandolo Radio Prototcol.
*
*  @brief
*  CR = Coriandolo Radio

*  @warning
*  *** THIS FILE SHOULD NOT BE MODIFIED. ***
*
*  @warning
*  Any modification to this file may cause the Coriandolo Radio Protocol to
*  operate improperly.
*/



/* ***************************************************************************
*  INCLUDE FILE
*/
#include <stdint.h>
#include <stdbool.h>
#include "CR_PublicTypes.h"


/** ***************************************************************************
*  PUBLIC CONSTANTS
*/
#define CONST_DEVICEID_SIZEINMESSAGE       ( 3u) ///< number of bytes for Device ID
#define CONST_TICKSVALUE_INVALID           (0uL) ///< error value for 'ticks'


/** ***************************************************************************
*  PUBLIC TYPE
*/
/// @enum addmsgmode_t
/// @brief
/// "Add Message Mode" is an enumerated type that describes how a new message
/// should be "added" to the message buffers.
/// @note
///    NUMERICAL VALUES ARE SUBJECT TO CHANGE.
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE.
typedef enum
{
   eADDMSGMODE_ERROR,        ///< Error value
   eADDMSGMODE_IF_NOTFULL,   ///< Add message if space is available
   eADDMSGMODE_FORCE         ///< Add message even if older message must be 
                             ///  removed to make space
} addmsgmode_t;


/* ***************************************************************************
*  PUBLIC PROTOTYPES
*/
void          CR_Init( void);

// Operation functions and procedures
void          CR_Announce( uint8_t* announcementMsgPtr);
void          CR_Disable( void);
crstatus_t    CR_Enable( const deviceinfo_t* deviceInfoPtr, 
                         const crcntrinfo_t* crCntrInfoPtr); 
void          CR_Listen( void);
crstatus_t    CR_Status_Get( void);
void          CR_Stop( void);

// Buffer/Message Management functions and procedures
bool          CR_AddRxBufr( uint8_t* rxBufr, const uint8_t rxBufrSize);
bool          CR_AddTxMsg( uint8_t* txMsg, const crtxflags_t txFlags, 
                                           const addmsgmode_t mode);
uint16_t      CR_GetCount_RxReady( void);
uint16_t      CR_GetCount_TxUnused( void);
uint8_t*      CR_GetRxMsg( uint32_t matchDeviceId, uint32_t* tickValuePtr);
uint8_t*      CR_GetTxMsg( uint32_t matchDeviceId, 
                           uint32_t* tickValuePtr, 
                           exchangestatus_t* exchangeStatusPtr);
void          CR_GetTxMsgInfo( const uint8_t* txMsgPtr,
                               uint32_t* tickValuePtr, 
                               exchangestatus_t* exchangeStatusPtr);
bool          CR_RemoveRxBufr( const uint8_t* rxBufrPtr);
bool          CR_RemoveTxMsg( const uint8_t* txMsgPtr);

// Test procedure
bool          CR_Test_InsertRxMsg( uint8_t* msgPtr);
void          CR_Test_TxConstantCarrier( const uint32_t freqMHz);


#endif /* ifndef CR_H */

/* ************** END OF FILE   CR_H *************************************** */

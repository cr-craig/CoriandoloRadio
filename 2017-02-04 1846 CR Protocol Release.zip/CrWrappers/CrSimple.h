#ifndef CRSIMPLE_H
#define CRSIMPLE_H

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This is the public include file for CrSimple.c
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2016-01-30
*  @date       last modified by Craig Goldman 2016-12-03
*
*  @copyright  Copyright (c) 2016 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*  @details
*  This file is the public include file for CrSimple.c.
*  It declares public prototypes for using the radio to communicate 
*  between SENSOR and BASE devices with the Coriandolo radio prototcol.
*
*  @brief
*  CR = Coriandolo Radio
*
*  @note
*  THIS FILE MAY BE MODIFIED TO SUIT THE APPLICATION PROGRAM
*/

/* ***************************************************************************
*  INCLUDE FILES
*/
#include <stdint.h>
#include <stdbool.h>
#include "../CR/CR.h"  

/* ***************************************************************************
*  PUBLIC PROTOTYPES
*/
void     CrSimple_Init( void);
bool     CrSimple_AnnounceNow( void);
void     CrSimple_Disable( void);
bool     CrSimple_EnableAsBase( uint8_t* rxMemPtr, 
                                const uint32_t totalRxBytes, 
                                const uint8_t rxMaxBytes);
bool     CrSimple_EnableAsSensor( const uint32_t myDeviceId, 
                                  uint8_t* rxMemPtr, 
                                  const uint32_t totalRxBytes, 
                                  const uint8_t rxMaxBytes);
bool     CrSimple_Listen_Start( void);
bool     CrSimple_Listen_Stop( void);
bool     CrSimple_Msg_CopyRcvd( uint8_t* msgPtr, const uint32_t deviceId, const uint8_t maxBytes);
uint8_t* CrSimple_Msg_GetSent( const uint32_t deviceId, bool* msgWasExchangedPtr);
bool     CrSimple_Msg_SetReadyToSend( uint8_t* msgPtr, const addmsgmode_t addMode);
bool     CrSimple_Msg_TxRemove( const uint8_t* msgPtr);


#endif /* ifndef CRSIMPLE_H */
/* ************** END OF FILE   CRSIMPLE_H ********************************* */

#define NRF51_RADIOHW_C      ///< file tag

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This module configures and operates the nRF51 radio hardware.
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2016-04-24
*  @date       last modified by Craig Goldman 2017-09-16
*
*
*  @copyright  Copyright (c) 2015, 2016, 2017 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*
*  @details
*  This module provides the interface between Coriandolo Radio and the radio
*  hardware.  This module also provides private procedures to set nR51 radio 
*  hardware registers.
*
*  @details
*  This module has been structured (hopefully) to allow support for other
*  radio devices.  The future will determine how well this has worked.  The
*  public API may need to change in the future to support this additional 
*  hardware.
*/

/* ***************************************************************************
*  INCLUDE FILES
*/
#include <stdint.h>
#include "RadioHw.h"


/// Use contents of this file only if Hardware is nRF51
#ifdef NRF51

/** ***************************************************************************
*  @page CrRadioPktAddrDoc  CrRadio Packet Address Documentation
*  DOCUMENTATION - RADIO PACKET ADDRESSES
*
*  This code supports use of only two Radio Addresses -- a Receive Address and 
*  a Transmit Address.  These are the identifiers used by the radio hardware to
*  facilitate communications.  The transmit radio hardware, sends the transmit
*  address at the beginning of a radio packet.  The receive radio hardware 
*  listens for a specific radio address to occur at the beginning of packet
*  reception and continues receiving the remainder of the packet is the address
*  matches.
*
*  This code does not support radio hardware that has the capability to transmit
*  a "broadcast" - a radio address that will be received by all radio hardware.
*  This code also does not support reception of all radio packets without regard
*  to the value of the address - sometimes called "promiscuous" reception.
*
*  Radio address are passed to this module as 64-bit values.
*  This code has been designed to use THREE bytes for the radio packet addresses,
*  all other bytes are not used and will be discarded.  To allow for easy
*  expansion from THREE bytes to FOUR or FIVE bytes, the code uses bytes
*  2, 3 and 4 of the 64-bit value with byte 0 being the least-significant byte.
*
*  @verbatim
*  Example:
*      Consider the 64-bit hex value ......    0xABCDEFGHIJKLMNOP 
*      The Coriandolo code uses these 24-bits          ^----^ 
*      (each letter represents 4 bits, 'P' represents the least significant 4 bits
*
*      If expansion to 4 bytes is desired, nybbles M and N would be added
*      If expansion to 5 bytes is desired, nybbles M, N, O and P would be added
*  @endverbatim
*
*  @note
*  This describes the use of Radio Packet Addresses.  "Addresses" are different
*  from the Device Identifiers used by the Coriandolo Radio Protocol. 
*/


/* ***************************************************************************
*  PRIVATE CONSTANTS
*/
static const uint8_t dummyPayload[4] = {0x00u, 0x00u, 0x00u, 0x00u};


/* ***************************************************************************
*  PRIVATE VARIABLES
*/
static callback_t  s_pktBeginFuncPtr;
static callback_t  s_pktEndFuncPtr;
static radiostatus_t  s_radioStatusNow;


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE PROCEDURES
*/
static __INLINE void  NRF51_Radio_CRC_Config( void);
static __INLINE void  NRF51_Radio_Events_Clear( void);
static __INLINE bool  NRF51_Radio_Frequency_SetMHz( const uint32_t freqMHz);
static __INLINE void  NRF51_Radio_Interrupts_Disable( void);
static __INLINE void  NRF51_Radio_Interrupts_Enable( uint32_t irqPriority);
static __INLINE void  NRF51_Radio_Mode_Config( void);
static __INLINE void  NRF51_Radio_Packet_Config( void);
static __INLINE void  NRF51_Radio_PayloadMaxLength_Set( const uint8_t maxLength);
static __INLINE void  NRF51_Radio_PowerDisable( void);
static __INLINE void  NRF51_Radio_PowerEnable( void);
static __INLINE void  NRF51_Radio_RxAddress_Set( const radioaddr_t rxAddr);
static __INLINE bool  NRF51_Radio_RxPacket_IsOK( void);
static __INLINE void  NRF51_Radio_RxStart( uint8_t* rxPayloadPtr);
static __INLINE void  NRF51_Radio_Stop( void);
static __INLINE bool  NRF51_Radio_StopWait( void);
static __INLINE void  NRF51_Radio_TestMode_ConstantCarrier( void);
static __INLINE void  NRF51_Radio_TestMode_Disable( void);
static __INLINE void  NRF51_Radio_TxAddress_Set( const radioaddr_t txAddr);
static __INLINE void  NRF51_Radio_TxStart( const uint8_t* txPayloadPtr);


/* ***************************************************************************/
/** **************************************************************************
*  MODULE INITIALIZATION PROCEDURE
*
*  -- All modules must have a "..._InitStatics" procedure to initialize static 
*  variables to known values.
*  @returns   void
*/
void RadioHw_InitStatics( void)
{
   // Set variables for callback procedures to "Callback_Null"
   s_pktBeginFuncPtr = Callback_Null;
   s_pktEndFuncPtr   = Callback_Null;
   return;
}


/* ***************************************************************************/
/* ***************************************************************************
*  PUBLIC PROCEDURES -- in alphabetical order
*/

/** ***************************************************************************
*  RADIO HARDWARE ADDRESS RX SET
*
*  Sets the receive radio address.  
*  @returns    void
*  @param[in]  addrRx - radio address value for reception
*
*  This procedure sets the "address" value that is sought by the radio hardware 
*  at the beginning of the radio packet during reception to determine if the
*  remainder of the packet should be received or if the radio should continue
*  to "listen".  The payload of the radio packet may contain other identifiers, 
*  which are not used by the radio hardware.
*/
void  RadioHw_AddressRx_Set( const radioaddr_t addrRx)
{
   NRF51_Radio_RxAddress_Set( addrRx);
   return;
}


/** ***************************************************************************
*  RADIO HARDWARE ADDRESS TX SET
*
*  Sets the transmit radio address.  
*  @returns    void
*  @param[in]  addrTx - radio address value for transmission
*
*  This procedure sets the "address" value placed by the radio hardware at the 
*  beginning of the radio packet during transmission.  The payload of the radio 
*  packet may contain other identifiers, which are not used by the radio hardware.
*/
void  RadioHw_AddressTx_Set( const radioaddr_t addrTx)
{
   NRF51_Radio_TxAddress_Set( addrTx);
   return;
}


/** ***************************************************************************
*  RADIO HARDWARE CALLBACKS SET
*
*  Sets the callback procedure for the "Packet Begin" and "Packet End" Events.
*  @returns    void
*  @param[in]  pktBeginCallback - procedure to be called when a packet "begin"
*                                 event is detected.
*  @param[in]  pktEndCallback   - procedure to be called when a packet "end"
*                                 event is detected.
*
*  @note
*  This code must be called after "RadioHw_Config"
*  @note
*  Callback parameters MUST be checked by higher-level code
*  @warning
*  Do not use a value of NULL POINTER for either parameter.
*  Use "Callback_Null" if no action is desired.
*  
*/
void  RadioHw_Callbacks_Set( callback_t pktBeginCallback, 
                             callback_t pktEndCallback)
{
   if( pktBeginCallback != (void*)0)
   {
      s_pktBeginFuncPtr = pktBeginCallback;
   }
   if( s_pktEndFuncPtr != (void*)0)
   {
      s_pktEndFuncPtr = pktEndCallback;
   }
   if( (s_pktBeginFuncPtr != Callback_Null) || 
       (s_pktEndFuncPtr   != Callback_Null)   )
   {
      // At least one of the function pointers is not "Null Callback",
      //    Clear all radio events and enable interrupts;
      NRF51_Radio_Events_Clear();
      NRF51_Radio_Interrupts_Enable( (uint32_t)0 /*HIGH PRIORITY*/);
   }
   else
   {
      // Both function pointers are "Null Callbacks"
      // Callbacks are not active, so disable interrupts
       NRF51_Radio_Interrupts_Disable();
   }
   return;
}


/** ***************************************************************************
*  RADIO HARDWARE CONFIGURE
*
*  This procedure configures the radio hardware for operation.  When done the
*  radio hardware should be enabled, but in a state of "standby" - neither
*  receiving nor transmitting.
*  @returns    void
*  @param[in]  deviceOption - value of enumerated type 'crdevopt_t'
*/
void  RadioHw_Config( const crdevopt_t deviceOption)
{
   // Enable the power to the radio module
   NRF51_Radio_PowerEnable();
   // Disable all radio interrupts at the CPU before 
   //   activating radio module hardware
   NRF51_Radio_Interrupts_Disable();
   // Configure radio registers for protocol.
   NRF51_Radio_Mode_Config();
   NRF51_Radio_Packet_Config();
   NRF51_Radio_CRC_Config();
   // Disable radio Test mode
   NRF51_Radio_TestMode_Disable();      
   // Set an initial value for the frequency
   NRF51_Radio_Frequency_SetMHz( 2400uL);
	 // 'deviceOption' is not used in this code
	 (void)(deviceOption);
   // done
   return;
}


/** ***************************************************************************
*  RADIO HARDWARE FORCE IDLE
*
*  Forces the radio hardware to "Idle".
*  Idle is defined as the radio state that is powered on but not receiving 
*  nor transmitting.
*  @returns    a boolean value - 'true' if radio hardware is "idle"; 
*              otherwise false.
*
*  @note
*  This function waits for hardware state to become "idle".  A return value of
*  'false' indicates an error has occurred.
*/

bool  RadioHw_ForceIdle( void)
{
   bool  isIdle;
   NRF51_Radio_Stop();
   isIdle = NRF51_Radio_StopWait();
   return isIdle;
}


/** ***************************************************************************
*  RADIO HARDWARE FREQUENCY SET
*
*  Sets the Radio Frequency in MHz.
*  @returns    a boolean value - 'true' if frequency is valid and has been  
*                                changed; otherwise false
*
*  @details
*  A return value of 'false' indicates that the passed frequency value is invalid.
*/
bool  RadioHw_FrequencySet( uint32_t frequencyMHz)
{
   bool  frequencyHasSet;
   frequencyHasSet = NRF51_Radio_Frequency_SetMHz( frequencyMHz);
   return frequencyHasSet;
}


/** ***************************************************************************
*  RADIO HARDWARE RECEIVED PACKET IS OK
*
*  Checks the validity of the last received radio packet.
*  @returns    a boolean value - 'true' if received packet is "ok";  
*              otherwise false
*/
bool  RadioHw_RxPacket_IsOK( void)
{
   bool  isOK;
   isOK = NRF51_Radio_RxPacket_IsOK();
   return isOK;
}


/** ***************************************************************************
*  RADIO HARDWARE RECEIVE START
*
*  Starts the Radio Hardware receiving (listening) for a radio packet; the 
*  hardware will limit the number of receive bytes to the value passed in 
*  'rxBufrLen'.
*  @returns     void
*  @param[in]   rxBufrPtr - pointer to bytes that contain payload of a received
*                           radio packet; other parts of the packet are stored
*                           elsewhere or are discarded during reception.
*  @param[in]   rxBufrLen - number of bytes in receive buffer.
*                           This parameter is NOT checked.
*
*  @warning
*  'rxBufrPtr' is NOT checked for a valid pointer.  The code and the hardware
*  will not operate properly without a pointer to a read-write memory area of
*  size 'rxBufrLen'.
*
*  @note
*  This procedure begins radio reception. It is likely the procedure may return 
*  before reception of packet is complete.
*/
void  RadioHw_RxStart( uint8_t* rxBufrPtr, const uint8_t rxBufrLen)
{
   NRF51_Radio_PayloadMaxLength_Set( rxBufrLen - 1u);
   NRF51_Radio_Events_Clear();
   // Clear the receive Byte Count in the first byte
   *rxBufrPtr = (uint8_t)0u;
   // Start the reception
   NRF51_Radio_RxStart( rxBufrPtr);
}


/** ***************************************************************************
*  RADIO HARDWARE SHUTDOWN
*
*  Stops the radio hardware (forces to "idle") and places hardware in lowest 
*  power state.  Radio Interrupts are disabled to prevent this operation from
*  being "side-tracked".
*  @returns   void
*
*  A call must be made to "RadioHw_Config" to restart the radio hardware.
*/
void  RadioHw_Shutdown( void)
{
   NRF51_Radio_Interrupts_Disable();
   NRF51_Radio_Stop();
   NRF51_Radio_TestMode_Disable();
   (void)NRF51_Radio_StopWait();
   NRF51_Radio_PowerDisable();
   return;
}

/** ***************************************************************************
*  RADIO HARDWARE TRANSMIT START
*
*  Starts the Radio Hardware transmitting the radio packet with the bytes in
*  the payload.
*  @returns     void
*  @param[in]   txPayloadPtr - pointer to bytes of a payload for a radio packet
*                              other parts of the packet are added before or
*                              during transmission.  'txPayloadPtr is NOT checked 
*                              for NULL POINTER.  
*  @param[in]   txPayloadLen - number of bytes in payload.
*                              This parameter is NOT checked
*
*  @note
*  This procedure starts a radio transmission.  The procedure may return before
*  transmission of packet is complete.
*/
void  RadioHw_TxStart( uint8_t* txPayloadPtr, const uint8_t txPayloadLen)
{
   NRF51_Radio_PayloadMaxLength_Set( txPayloadLen);
   NRF51_Radio_Events_Clear();
   // Start the transmission
   NRF51_Radio_TxStart( txPayloadPtr);
   return;
}
   

/** ***************************************************************************
*  RADIO HARDWARE TRANSMIT START CONSTANT CARRIER
*
*  Starts a continuous transmission of the carrier signal.
*  @returns     void
*
*  This procedure is used for testing.  It disables interrupts, set the radio
*  hardware to test mode for "constant carrier", then starts the radio 
*  transmission.  The radio should transmit a carrier signal at the preset
*  frequency until the radio is "stopped" or "shutdown".
*
*  @note
*  The call to this procedure must be preceeded by a call to "RadioHw_Config"
*  to initialize the registers followed by a call to "RadioHw_FrequencySet" to 
*  set the frequency.
*
*  @note
*  This operation should be terminated by a call to "RadioHw_Shutdown".
*
*  @note
*  Shortly after call to "NRF51_Radio_TxStart", EVENT_READY, EVENT_ADDRESS, 
*  EVENT_PAYLOAD and EVENT_END will set.  Radio State will indicate "TxIdle"

*/
void  RadioHw_TxStartConstantCarrier( void)
{
   // Disable Radio interrupts
   NRF51_Radio_Interrupts_Disable();
   // Set test mode to Constant Carrier
   NRF51_Radio_TestMode_ConstantCarrier();
   NRF51_Radio_Events_Clear();
   // Start transmission - because of "test mode", 'dummyPayload' is never sent
   NRF51_Radio_TxStart( dummyPayload);
   // Radio continues transmitting constant carrier until stopped
   // NOTE: All radio interrupts remain disabled
   return;
}


/** ***************************************************************************
*  RADIO HARDWARE WAIT FOR IDLE
*
*  Waits for radio hardware to return to the idle state.
*  @returns    a boolean value - 'true' if radio hardware is "idle"; 
*              otherwise false
*
*  This function repeatedly checks for the radio to become "idle"; the function
*  will be return 'true' when that occurs; the function may "timeout" before
*  the radio hardware becomes idle, in which case the function returns 'false'
*
*  @note
*  This function takes no action to cause the radio hardware to change state.
*  Presumably, higher-level code has initiated an action that will cause the
*  radio hardware to eventually complete activity and become "idle".
*/
bool  RadioHw_WaitForIdle( void)
{
   bool  radioIsIdle;
   radioIsIdle = NRF51_Radio_StopWait();
   return radioIsIdle;
}



/* ************************************************************************ */
/** ***************************************************************************
*  RADIO INTERRUPT HANDLER
*
*  The Radio Interrupt Handler is invoke by hardware in response to certain
*  radio events that are enabled to generate interrupts.
*
*  @verbatim
*  IMPORTANT NOTE: Radio interrupts are "level" sensitive.  The Event register
*                  must be cleared or the interrupt will be re-triggered.
*
*  IMPORTANT NOTE: "RadioHw.c" enables interrupts on RADIO EVENT END not RADIO 
*                  EVENT DISABLED.  This is done so an interrupt will not occur 
*                  when the radio is forced off with "NRF51_Radio_Stop"
*  @endverbatim
*/
void RADIO_IRQHandler(void)
{
   if( (NRF_RADIO->EVENTS_ADDRESS != 0uL) &&
            ((NRF_RADIO->INTENSET & RADIO_INTENSET_ADDRESS_Msk) != 0uL) )
   {
      // RADIO ADDRESS EVENT
      s_radioStatusNow = (radiostatus_t)(NRF_RADIO->STATE & RADIO_STATE_STATE_Msk);
      // Execute callback for event "Packet Begin"
      //   pass pointer to radio status
      (*s_pktBeginFuncPtr)( (void *)&s_radioStatusNow);
      // Disable event that triggered interrupt
      NRF_RADIO->EVENTS_ADDRESS = 0u;
   }
   else if( (NRF_RADIO->EVENTS_END != 0uL) &&
            ((NRF_RADIO->INTENSET & RADIO_INTENSET_END_Msk) != 0uL) )
   {
      // RADIO END EVENT
      s_radioStatusNow = (radiostatus_t)(NRF_RADIO->STATE & RADIO_STATE_STATE_Msk);
      // Execute callback for event "Packet Begin"
      //   pass pointer to radio status
      (*s_pktEndFuncPtr)( (void *)&s_radioStatusNow);
      // Disable event that triggered interrupt
      NRF_RADIO->EVENTS_END = 0u;
   }
   else
   {
      // Radio interrupt occured that is not handled
      // This should never occur
      // Disable all radio interrupts, then re-enable only the desired radio interrupts
      NRF51_Radio_Interrupts_Disable();
      NRF51_Radio_Interrupts_Enable( (uint32_t)0 /*HIGH PRIORITY*/);
   }
   return;
}



/* ***************************************************************************/
/* ***************************************************************************
*  PRIVATE PROCEDURES -- in alphabetical order
*/

/** ***************************************************************************
*  NRF51 RADIO CRC CONFIGURE
*
*  Sets the nRF51 hardware registers for generating and checking CRC values
*  appended to the radio packet.
*  @returns     void
*/
static __INLINE void  NRF51_Radio_CRC_Config( void)
{
   // Set CRC bytes to two and equation to be equivalent to CCITT-16
   NRF_RADIO->CRCCNF  = (RADIO_CRCCNF_LEN_Two << RADIO_CRCCNF_LEN_Pos);
   // CRC poly: x^16+x^12^x^5+1; this is CCITT compatible   
   NRF_RADIO->CRCPOLY = 0x11021UL; 
   // Initial value of CRC
   NRF_RADIO->CRCINIT = 0xFFFFUL;
   return;
}


/** ***************************************************************************
*  NRF51 RADIO EVENTS CLEAR
*
*  Clears the hardware event registers used by the radio code
*  @returns     void
*/
static __INLINE void  NRF51_Radio_Events_Clear( void)
{
   NRF_RADIO->EVENTS_READY    = 0uL;
   NRF_RADIO->EVENTS_ADDRESS  = 0uL;
   NRF_RADIO->EVENTS_PAYLOAD  = 0uL;
   NRF_RADIO->EVENTS_END      = 0uL;
   NRF_RADIO->EVENTS_DISABLED = 0uL;
   return;
}


/* ***************************************************************************
*  NRF51 RADIO FREQUENCY SET
*
*  Sets the radio frequency for receive and transmit.
*  @returns     boolean 'true' if frequency has been changed
*  @param[in]   freqMHz - frequency value in units of 1 MHz
*
*  @details
*  The nRF51 radio hardware accepts frequency settings in MHz from 2400MHz to 
*  2500Mhz, (including 2400MHz and 2500MHz) in units of 1MHz.
*  Thus the 'freqOffset' is a number from 0 to 100, inclusive.
*  The function returns 'true' if the new frequency is valid and has 
*  been set; otherwise the function returns false.
*
*  @note
*  This function should be called ONLY when the radio state is DISABLED but 
*  this is not enforced by the function
*/
static __INLINE bool  NRF51_Radio_Frequency_SetMHz( const uint32_t freqMHz)
{
   uint32_t  freqOffset;
   bool      freqIsChanged;
   if( (freqMHz >= 2400u) && (freqMHz <= 2500u) )
   {
      freqOffset = (freqMHz - 2400u);
      freqOffset &= RADIO_FREQUENCY_FREQUENCY_Msk;
      NRF_RADIO->FREQUENCY = freqOffset;
      freqIsChanged = true;
   }
   else
   {
      freqIsChanged = false;
   }
   return freqIsChanged;      
}


/** ***************************************************************************
*  NRF51 RADIO INTERRUPTS DISABLE
*
*  Disable Interrupts from the Radio Module to the CPU
*  Also clears all the bits that enable radio events as interrupts.
*  @returns     void
*/
static __INLINE void  NRF51_Radio_Interrupts_Disable( void)
{
   NVIC_DisableIRQ( RADIO_IRQn);
   NRF_RADIO->INTENCLR = 0xFFFFFFFFuL;
   return;
}


/** ***************************************************************************
*  NRF51 RADIO INTERRUPTS ENABLE
*
*  Enable Interrupts from the Radio Module to the CPU.
*  This code enables interrupts only for ADDRESS Event and END Event.
*  The priority is fixed.
*  @returns     void
*/
static __INLINE void  NRF51_Radio_Interrupts_Enable( uint32_t irqPriority)
{
   NRF_RADIO->INTENSET = ((RADIO_INTENSET_ADDRESS_Enabled  << RADIO_INTENSET_ADDRESS_Pos) |
                          (RADIO_INTENSET_END_Enabled << RADIO_INTENSET_END_Pos) );
   NVIC_ClearPendingIRQ( RADIO_IRQn);
   NVIC_SetPriority( RADIO_IRQn, (uint32_t)irqPriority);
   NVIC_EnableIRQ( RADIO_IRQn);
   return;
}


/** ***************************************************************************
*  NRF51 RADIO MODE CONFIGURE
*
*  Initializes radio hardware registers for Coriandolo Radio protocol.
*  @returns     void
*
*  @details
*  Sets the transmission mode and power used by the protocol.
*  Also sets hardware "overrides" for BLE radio
*
*  @details
*  The transmit and receive modulation mode is BLE 1MBIT
*  The transmit power is set to 4, which is +4dBM
*  Enable "short" to automatically transition from READY to START
*  Enable "short" to automatically transition from END to DISABLE
*/
static __INLINE void  NRF51_Radio_Mode_Config( void)
{
   NRF_RADIO->MODE = RADIO_MODE_MODE_Ble_1Mbit;
   NRF_RADIO->TXPOWER = 4uL;
   NRF_RADIO->SHORTS = 
            ((RADIO_SHORTS_READY_START_Enabled << RADIO_SHORTS_READY_START_Pos) |
             (RADIO_SHORTS_END_DISABLE_Enabled << RADIO_SHORTS_END_DISABLE_Pos)  ); 
   if ((NRF_FICR->OVERRIDEEN & 0x8) == 0)
      {
      NRF_RADIO->OVERRIDE0 = NRF_FICR->BLE_1MBIT[0];
      NRF_RADIO->OVERRIDE1 = NRF_FICR->BLE_1MBIT[1];
      NRF_RADIO->OVERRIDE2 = NRF_FICR->BLE_1MBIT[2];
      NRF_RADIO->OVERRIDE3 = NRF_FICR->BLE_1MBIT[3];
      NRF_RADIO->OVERRIDE4 = 
            ((RADIO_OVERRIDE4_ENABLE_Enabled << RADIO_OVERRIDE4_ENABLE_Pos) | 
             (NRF_FICR->BLE_1MBIT[4] & RADIO_OVERRIDE4_OVERRIDE4_Msk) );
      }
   return;
}


/** ***************************************************************************
*  NRF51 RADIO PACKET CONFIGURE
*
*  Configures radio hardware for Coriandolo Packets.
*  @returns     void
*
*  @details
*  S0 field is set to zero bytes (disabled).
*  S1 field is set to zero bits (disabled).
*  Length field is 8 bits.
*  Base Radio Address is 2 bytes.
*  (Prefix Radio Address is anc additional byte.)
*  Data Whitening is Enabled.
*  Sets initial value of MAXLEN to zero;
*  it will be updated by a call to "NRF51_Radio_PayloadMaxLength_Set"
*/
static __INLINE void  NRF51_Radio_Packet_Config( void)
{
   // Packet configuration
   //lint !e845 "The right argument to operator '|' is certain to be 0"
   NRF_RADIO->PCNF0 = ((   0uL     << RADIO_PCNF0_S1LEN_Pos) |
                       (   0uL     << RADIO_PCNF0_S0LEN_Pos) |
                       (   8uL     << RADIO_PCNF0_LFLEN_Pos)  ); 
   //lint !e845 "The right argument to operator '|' is certain to be 0"
   NRF_RADIO->PCNF1 = (( RADIO_PCNF1_WHITEEN_Enabled        << RADIO_PCNF1_WHITEEN_Pos) |
                       ( RADIO_PCNF1_ENDIAN_Little          << RADIO_PCNF1_ENDIAN_Pos)  |
                       (   2uL                              << RADIO_PCNF1_BALEN_Pos)   |
                       (   0uL                              << RADIO_PCNF1_STATLEN_Pos) |
                       (   0uL                              << RADIO_PCNF1_MAXLEN_Pos)   );
   return;
}


/** ***************************************************************************
*  NRF51 RADIO PAYLOAD MAX LENGTH SET
*
*  Sets the maximum length of the packet payload (transmit or receive).
*  @returns     void
*
*  @details
*  The payload does not include the S0, S1 LEN or CRC fields
*  Techincally, the value should be limited to 254 bytes, but this code does
*  not check for this.
*
*  The max length is set in Radio register PCNF1
*/
static __INLINE void  NRF51_Radio_PayloadMaxLength_Set( const uint8_t maxLength)
{ 
   // Clear the field of the register to zero, then OR'in the new data
   NRF_RADIO->PCNF1 &= ~(RADIO_PCNF1_MAXLEN_Msk);
   NRF_RADIO->PCNF1 |= ((uint32_t)maxLength << RADIO_PCNF1_MAXLEN_Pos);
   return;
}


/** ***************************************************************************
*  NRF51 RADIO POWER DISABLE
*
*  Sets the radio hardware into lowest-power mode (not operating).
*  @returns     void
*/
static __INLINE void  NRF51_Radio_PowerDisable( void)
{
   // Clear all radio interrupt enables, power-down the module
   NRF_RADIO->INTENCLR = 0xFFFFFFFFuL;
   NRF_RADIO->POWER = (RADIO_POWER_POWER_Disabled << RADIO_POWER_POWER_Pos);
   return;
}   


/** ***************************************************************************
*  NRF51 RADIO POWER ENABLE
*
*  Enables the radio hardware.
*  @returns     void
*/
static __INLINE void  NRF51_Radio_PowerEnable( void)
{
   NRF_RADIO->POWER = (RADIO_POWER_POWER_Enabled << RADIO_POWER_POWER_Pos);
   return;
}   


/** ***************************************************************************
*  NRF51 RADIO RECEIVE ADDRESS SET
*
*  Sets the Receive Address.
*  @returns     void
*
*  @details
*  This code uses nRF51 Logical Address 0 for the receive address.
*  Logical Address 0 contains 2, 3, or 4 most significant bytes of
*  BASE Register 0 and Prefix Register 0 - byte AP0.
*
*  This function sets the BASE Address Register 0 to the most significant 
*  24 bits of 'rxAddr'; the prefix register is set to the least signifcant 
*  8 bits of 'rxAddr'.
*
*  @note
*  The number of bytes in the BASE register used by the radio hardware is
*  set in "NRF51_Radio_Packet_Config".  It is possible that not all of the 
*  bits set in the Base Address register will be used.
*  Prefix Register 0 will be all zeros except for byte AP0.
*
*  @note
*  Some additional information about Radio Packet addreses can be found at the
*  top of this file.
*/
static __INLINE void  NRF51_Radio_RxAddress_Set( const radioaddr_t rxAddr)
{
   uint32_t  baseValue;
   uint32_t  prefixValue;
	 uint32_t  logicalAddress;
   baseValue = ((uint32_t)rxAddr) & 0xFFFFFF00uL;
   prefixValue = ((uint32_t)rxAddr) & 0x000000FFuL;
   NRF_RADIO->PREFIX0 = ( prefixValue << RADIO_PREFIX0_AP0_Pos);
   NRF_RADIO->BASE0   = baseValue;
   // Set radio hardware to only use logical address 0 to receive.
	 logicalAddress = 0uL;
   NRF_RADIO->RXADDRESSES = (1uL << logicalAddress);
   return;
}


/** ***************************************************************************
*  NRF51 RADIO RECEIVE PACKET IS OK
*
*  The reecive packet is checked for packet integrity.
*  @returns     boolean 'true' if receive packed is OK
*
*  @details
*  Checks CRC status bit for last received radio packet.
*/
static __INLINE bool  NRF51_Radio_RxPacket_IsOK( void)
{
   bool  isOK;
   isOK = ((NRF_RADIO->CRCSTATUS & RADIO_CRCSTATUS_CRCSTATUS_Msk) == RADIO_CRCSTATUS_CRCSTATUS_CRCOk);
   return isOK;
}


/** ***************************************************************************
*  NRF51 RADIO RECEIVE START
*
*  Set's the pointer to the bytes that will receive the radio data; "starts"
*  the receiver.
*  @returns     void
*  @param[in]   rxPayloadPtr - pointer to buffer for received payload bytes
*                              (and length byte)
*
*  @note
*  The NRF51 radio hardware expects a pointer to the 'length' byte that 
*  immediately preceeds the received data bytes.
*  This 'length' byte will be set with the number of payload bytes received by
*  the radio hardware.
*/
static __INLINE void  NRF51_Radio_RxStart( uint8_t* rxPayloadPtr)
{
   NRF_RADIO->PACKETPTR = (uint32_t)rxPayloadPtr;
   NRF_RADIO->TASKS_RXEN = 1u;
   return;
}


/** ***************************************************************************
*  NRF51 RADIO STOP
*
*  "Stops" radio reception or transmission.
*  @returns     void
*
*  @details
*  This procedure invokes a RADIO DISABLE TASK, which causes radio transmit or
*  receive to "stop".  Once, the disabled TASK is invoked, the Radio "Stop" 
*  should take less-than 10 microseconds to complete (from NRF51 Data Sheet).
*/
static __INLINE void  NRF51_Radio_Stop( void)
{
   NRF_RADIO->EVENTS_DISABLED = 0uL;
   NRF_RADIO->TASKS_DISABLE   = 1uL;
   // This procedure does not wait for "Stop" to complete
   return;
}   


/** ***************************************************************************
*  NRF51 RADIO STOP WAIT
*
*  Waits until the radio stops.
*  @returns     boolean 'true' if radio stop has completed; a value of 'false'
*               indicates that the wait for stop timed-out.
*
*  @details
*  This procedure remains in a loop until the Radio STATE is DISABLED.
*  The "wait" is limited to 9,000 loops which should allow a radio transmit
*  or receive to complete.  (A "Radio Stop" completes in less time.)
*
*  @note
*  The maximum time in this function is about 10 milliseonds at 16MHz. 
*/
static __INLINE bool  NRF51_Radio_StopWait( void)
{
   int  cnt;
   bool isStopped;
   isStopped = false;
   for( cnt=9000; (cnt>0) && (isStopped == false); cnt-=1)
   {
      if( NRF_RADIO->STATE == RADIO_STATE_STATE_Disabled)
      {
         isStopped = true;
      }
   }
   return isStopped;
}   


/** ***************************************************************************
*  NRF51 RADIO TEST MODE CONSTANT CARRIER
*
*  Sets the radio test mode to "Constant Carrier"
*  @returns     void
*/
static __INLINE void  NRF51_Radio_TestMode_ConstantCarrier( void)
{
   NRF_RADIO->TEST = ((RADIO_TEST_CONST_CARRIER_Enabled << RADIO_TEST_CONST_CARRIER_Pos) |
                      (RADIO_TEST_PLL_LOCK_Enabled << RADIO_TEST_PLL_LOCK_Pos)  );
   NRF_RADIO->SHORTS = (RADIO_SHORTS_READY_START_Enabled << RADIO_SHORTS_READY_START_Pos);
   return;
}


/** ***************************************************************************
*  NRF51 RADIO TEST MODE DISABLE
*
*  Disables all radio test modes
*  @returns     void
*/
static __INLINE void  NRF51_Radio_TestMode_Disable( void)
{
   NRF_RADIO->TEST = 0uL;
   return;
}


/** ***************************************************************************
*  NRF51 RADIO TRANSMIT ADDRESS SET
*
*  Sets the Transmit Address.
*  @returns     void
*
*  @details
*  This code uses nRF51 Logical Address 4 for the transmit address.
*  Logical Address 4 contains 2, 3, or 4 most significant bytes of
*  BASE Register 1 and Prefix Register 1 - byte AP4.
*
*  This function sets the BASE Address Register 1 to the most significant 
*  24 bits of 'txAddr'; the prefix register is set to the least signifcant 
*  8 bits of 'txAddr'.
*
*  @note
*  The number of bytes in the BASE register used by the radio hardware is
*  set in "NRF51_Radio_Packet_Config".  It is possible that not all of the 
*  bits set in the Base Address register will be used.
*  Prefix Register 1 will be all zeros except for byte AP4
*
*  @note
*  Some additional information about Radio Packet addreses can be found at the
*  top of this file.
*/
static __INLINE void  NRF51_Radio_TxAddress_Set( const radioaddr_t txAddr)
{
   uint32_t  baseValue;
   uint32_t  prefixValue;
	 const uint32_t  logicalAddress = 4uL;
   // Set registers for logical address
   baseValue = ((uint32_t)txAddr) & 0xFFFFFF00uL;
   prefixValue = ((uint32_t)txAddr) & 0x000000FFuL;
   NRF_RADIO->PREFIX1 = (prefixValue << RADIO_PREFIX1_AP4_Pos);
   NRF_RADIO->BASE1   = baseValue;
   // Set radio hardware to use the logical address to transmit.
   NRF_RADIO->TXADDRESS = logicalAddress;
   return;
}


/** ***************************************************************************
*  NRF51 RADIO TRANSMIT START
*
*  Set's the pointer to the bytes of the radio payload to be transmitted;
*  "starts" the transmitter.
*  @returns     void
*  @param[in]   txPayloadPtr - pointer to buffer for received payload bytes
*                              (and length byte)
*
*  @note
*  The NRF51 radio hardware expects a pointer to the 'length' byte that
*  immediately preceeds the payload data bytes.
*  This 'length' byte must contain the number of data bytes that will be 
*  transmitted after the length byte.
*
*  @note
*  This code assumes that the 'length' has already been checked for a legal
*  value.
*/
static __INLINE void  NRF51_Radio_TxStart( const uint8_t* txPayloadPtr)
{
   NRF_RADIO->PACKETPTR = (uint32_t)txPayloadPtr;
   NRF_RADIO->TASKS_TXEN = 1u;
   return;
}

#endif /* #ifdef NRF51 */


/* ************** END OF FILE   NRF51_RADIOHW_C **************************** */

#define SPEEDTEST_CR_C       ///< file tag

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This files contains code that may be used to perform a speed
*              test of Coriandolo Radio protocol
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2016-07-09
*  @date       last modified by Craig Goldman 2017-09-16
*
*
*  @copyright  Copyright (c) 2016, 2017 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*
*  @details
*  This file contains code for both a SENSOR and BASE to simulate transmission
*  of sensor data from SENSOR to BASE.  The time required to measure byte 
*  transmission can be measured.
*  This code uses the Coriandolo Radio (CR) protocol.
*
*  @brief
*  CR = Coriandolo Radio
*
*  @note
*  This file has several CONFIG parameters which may be changed to vary the
*  operating conditions of the radio transfer.  If a reader wishes to change
*  the parameters and publish his/her own results, she/he should include the
*  values of all of the CONFIG parameters in the notes, so others may properly
*  comment and discuss the results.
*
*  @note
*  Readers are welcome to change the code, but changes also should be noted if 
*  test results are published.
*
*/

/* ****************************************************************************
*  SPECIAL DEFINITIONS FOR PC-LINT
*/
// Added to ensure PC-Lint knows correct compiler
#ifndef __CC_ARM
#define __CC_ARM
#endif


/* ***************************************************************************
*  INCLUDE FILES
*/
#include "../CR/CR_PublicTypes.h"
#include "nrf.h"
#include "../CR/CR.h"
#include "../CR/CrDeviceId.h"



/** ***************************************************************************
*  @page CrSpeedTestDoc  CR Speed Test Code Documentation
*  DOCUMENTATION
*
*  @note
*  Info in this documentation assumes Configuration Constants have not been 
*  changed.
*
*  @details
*  As configured, the SENSOR will send a 4-byte announcement, receive a 4-byte
*  default acknowledgement, then follow with eight transmit messages of 254
*  bytes (250 data bytes) each of which will be followed by a 4-byte default 
*  acknowlegement as a response.
*
*  The messages are embedded in a radio packet that adds a preamble, a 3-byte
*  radio address and a 2-byte CRC.  This means the 4-byte messages become 10 bytes.
*  The large 254-byte message becomes 260 radio packet bytes.
*  The radio transmits/receives at 1Mbit per second, so transmission time is
*  80 microseconds and 2080 microseconds, respectively.
*  The minimum time between to turn off the transmitter (or receiver) and turn
*  on the receiver (or transmitter) in the nRF51 is about 150 microseconds.
*
*  A SENSOR is able to transmit with a single Announcement and Exchange eight 
*  messages with 250 data bytes (a total of 2000 data bytes).
*
*  @verbatim
*  If the code is VERY fast, the time required would be...
*     Announcement:          10 bytes * 8 bits/byte  =>   80 microseconds
*                             0 data bytes
*     Tx-Rx delay:                                       150 microseconds
*     Announement response:  10 bytes * 8 bits/byte  =>   80 microseconds
*                             0 data bytes
*     Rx-Tx delay:                                       150 microseconds
*     Tx Data Msg 1:        260 bytes * 8 bits/byte  => 2080 microseconds
*                           250 data bytes
*     Tx-Rx delay:                                       150 microseconds
*     Default acknowledge:   10 bytes * 8 bits/byte  =>   80 microseconds
*     Rx-Tx delay:                                       150 microseconds
*     Tx Data Msg 2:        260 bytes * 8 bits/byte  => 2080 microseconds
*                           250 data bytes
*     Tx-Rx delay:                                       150 microseconds
*     Default acknowledge:   10 bytes * 8 bits/byte  =>   80 microseconds
*     Rx-Tx delay:                                       150 microseconds
*     Tx Data Msg 3:        260 bytes * 8 bits/byte  => 2080 microseconds
*                           250 data bytes
*     Tx-Rx delay:                                       150 microseconds
*     Default acknowledge:   10 bytes * 8 bits/byte  =>   80 microseconds
*     Rx-Tx delay:                                       150 microseconds
*     Tx Data Msg 4:        260 bytes * 8 bits/byte  => 2080 microseconds
*                           250 data bytes
*     Tx-Rx delay:                                       150 microseconds
*     Default acknowledge:   10 bytes * 8 bits/byte  =>   80 microseconds
*     Rx-Tx delay:                                       150 microseconds
*     Tx Data Msg 5:        260 bytes * 8 bits/byte  => 2080 microseconds
*                           250 data bytes
*     Tx-Rx delay:                                       150 microseconds
*     Default acknowledge:   10 bytes * 8 bits/byte  =>   80 microseconds
*     Rx-Tx delay:                                       150 microseconds
*     Tx Data Msg 6:        260 bytes * 8 bits/byte  => 2080 microseconds
*                           250 data bytes
*     Tx-Rx delay:                                       150 microseconds
*     Default acknowledge:   10 bytes * 8 bits/byte  =>   80 microseconds
*     Rx-Tx delay:                                       150 microseconds
*     Tx Data Msg 7:        260 bytes * 8 bits/byte  => 2080 microseconds
*                           250 data bytes
*     Tx-Rx delay:                                       150 microseconds
*     Default acknowledge:   10 bytes * 8 bits/byte  =>   80 microseconds
*     Rx-Tx delay:                                       150 microseconds
*     Tx Data Msg 8:        260 bytes * 8 bits/byte  => 2080 microseconds
*                           250 data bytes
*     Tx-Rx delay:                                       150 microseconds
*     Default acknowledge:   10 bytes * 8 bits/byte  =>   80 microseconds
*     Rx-Tx delay:                                       150 microseconds
*     ===================================================================
*                                                      20140 microseconds
*  @endverbatim
*
*  @details
*  Total message data bytes of 2000 bytes in 8 messages in 20140 microseconds 
*  would be a throughput of 99,305 bytes per second.
*
*  The CR protocol allows for "fast" Announcements when transmitting data,
*  so assuming the SENSOR sent a new Announcement every 25 milliseconds, it
*  would have a throughput of 80,000 data bytes per second.
*  THIS IS ROUGHLY THE THEORECTICAL LIMIT FOR THROUGHPUT.
*  ACTUAL THROUGHPUT WILL BE LESS.
*
*
*  CODE SUMMARY
*
*  The SENSOR code transmits 256 messages  If a response from the BASE is not
*  received by the SENSOR, the packet is re-transmitted.  When a response to
*  the message is received, the count of messages transmitted and exchanged is
*  incremented.  The code simulates the process time it would take to fill the 
*  transmit buffer with a new message.
*
*  The BASE code receives the messages and increments a counter for every 
*  non-announcement message.  The BASE code does not load any transmit 
*  messages so the CR code automatically will transmit a default acknowledge
*  message after every received message
*
*  TEST RESULTS
*
*  Using this code I have measured 1574 milliseconds to transfer 256 messages
*  containg 250 payload bytes.  This is a transfer of 64,000 CR data bytes;  
*  a throughput of 40,660 bytes per second or 325,286 bits per second.
*
*  Test results will vary with distance, antenna orientation and the number
*  and strength of other radio transmitters in the vicinity.
*
*  @verbatim
*  This throughput value includes all overhead
*    - 32 announcements with no data and 32 default base responses
*    - 256 default base responses after each sensor message with data
*    - 1024 bytes of CR buffer header info (256 buffers with 4 bytes per buffer)
*    - 1536 bytes of radio packet overhead (256 packets with 6-bytes per radio packet).
*  So, the throughput value represents true message data throughput.
*  @endverbatim  
*
*  When comparing radio protocols, the reader should not count protocol bytes
*  that are not "message bytes" or extra bytes that are part of the radio packet
*  overhead such as preamble, radio address or CRC.
*
*
*  HOW TO USE THIS FILE TO TEST FOR CORIANDOLO RADIO PERFORMANCE
*
*  Please make sure this file -- "SpeedTest_CR.c" -- is included in the project
*  and is the only file with "main( void)" included in the build.
*
*  Code can be used as is (except selection for BASE and SENSOR) to test
*  transmission of 64,000 bytes (256 messages with 250 payload bytes each).
*  @verbatim
*  * Select code as BASE; compile and download to BASE device; start code execution
*  * Select code as SENSOR; compile and download to SENSOR device
*  * Remain connected to the SENSOR; activate the debugger.
*  * Search in code for comment <---- Set breakpoint here to get value
*  * Start code execution
*  * value of 'ticksSinceTestStart' is execution time of complete test in microseconds
*  * Take 64000/'ticksSinceTestStart' * 1000000 to get bytes per second
*
*  * You may also measure the pulse width of the LED using an oscilliscope
*  @endverbatim
*
*  
*
*  
*/

/*  **************************************************************************/
/** ***************************************************************************
*  SELECT BASE OR SENSOR CONFIGURATION
*
*  @note
*  Programmer should uncomment EXACTLY ONE of the following definitions.
*  A "test" will generate a compile-time error if both SENSOR and BASE code are
*  defined.
*/
// #define CONFIG_BASE_CODE
#define CONFIG_SENSOR_CODE

#if defined(CONFIG_SENSOR_CODE) && defined(CONFIG_BASE_CODE)
    ERROR. PROGRAMMER MUST DEFINE EITHER CONFIG_SENSOR_CODE OR CONFIG_BASE_CODE, NOT BOTH
#endif


/*  **************************************************************************/
/** ***************************************************************************
*  CONFIGURATION CONSTANTS
*
*  @note
*  CR limits the number of receive buffers and transmit messages that can be
*  "ready" in the system.  These constants can be found in "CrBufr.c".
*  This is open-source code, but the programmer is advised to be careful when
*  changing these constants.
*
*  @warning
*  If changing CONFIG_RX_BUFR_SIZE, it should be set to a value larger than
*  CONFIG_TX_MSG_MAXSIZE.
*
*  @warning
*  CONFIG_TX_MSG_MAXSIZE must be a even number.
*/
#if defined(CONFIG_SENSOR_CODE)
#define CONFIG_NUM_RX_BUFRS    ( 9)  ///< number of receive buffers; should be >0
#define CONFIG_NUM_TX_MSGS     ( 8)  ///< number of transmit message buffers;
                                     ///  CR limits the number of messages that
                                     ///  can be transmitted in a single exchange

#elif defined(CONFIG_BASE_CODE)
#define CONFIG_NUM_RX_BUFRS    ( 9)  ///< number of receive buffers; should be as large as legal
                                     ///  CR limits the number of messages that
                                     ///  can be received in a single exchange
#define CONFIG_NUM_TX_MSGS     ( 1)  ///< number of transmit message buffers;
                                     ///  BASE transmit messages not used in this speed test
                                     ///  The BASE is expected to transmit the Default Ackowledgement

#else
    ERROR. PROGRAMMER MUST DEFINE EITHER CONFIG_SENSOR_CODE OR CONFIG_BASE_CODE
#endif


#define CONFIG_RX_BUFR_SIZE   (254)  ///< maximum bytes that can be received
                                     ///  this includes "size" byte and "Device Id"
#define CONFIG_TX_MSG_MAXSIZE (254)  ///< maximum bytes in tx message;
                                     ///  this includes "size" byte and "Device Id"

#if CONFIG_RX_BUFR_SIZE > 254
   ERROR. CONFIG_RX_BUFR_SIZE MUST BE 254 BYTES OR SMALLER.
#endif

#if CONFIG_TX_MSG_MAXSIZE > 254
   ERROR. CONFIG_TX_MSG_MAXSIZE MUST BE 254 BYTES OR SMALLER.
#endif



/** ***************************************************************************
*  TEST CONSTANTS
*/
#define CONST_PIN_OUTPUT_LED            ( 15u)  ///< Port Pin number for LED


/* ***************************************************************************
*  PRIVATE CONSTANT VARS FOR CORIANDOLO RADIO INITIALIZATION
*/
#define CONST_SPEEDTEST_CR_CONNECTION   (0xFFF0u) ///< Connection value for "Speed Test"

#ifdef CONFIG_BASE_CODE
/// CR Device Information
const static deviceinfo_t  myDeviceInfo = 
{
   0uL,                 ///< revision number of structure
   eCRTYPE_BASE,        ///< BASE device
   0x00FFFFFCuL,        ///< Device Identifier
   eCRDEVICEOPT_NONE,   ///< no device options 
   CONST_SPEEDTEST_CR_CONNECTION  ///< Connection value (this should only be modified by advanced users)
};

/// CR Counter Information
/// @note
/// This counter info structure is used by the CR protocol for it's timeout and 
/// timestamps.  The "Speed Test" application may use a different counter to
/// measure "ticks"
const static crcntrinfo_t  myCrCntrInfo = 
{
   0uL,                 ///< revision number of structure
   eCRHWTIMER_RTC1,     ///< use RTC1 for hardware timer
   eCRTICKSCNTR_RTC1    ///< use RTC1 for "Ticks" (time stamp)
};
#endif

#ifdef CONFIG_SENSOR_CODE
/// CR Device Information
const static deviceinfo_t  myDeviceInfo = 
{
   0uL,                 ///< revision number of structure
   eCRTYPE_SENSOR,      ///< SENSOR device
   0x00440004uL,        ///< Device Identifier
   eCRDEVICEOPT_REMOVE_DEFAULT_ACKS,   ///< Automatically remove default ACKs from Rx Buffers
   CONST_SPEEDTEST_CR_CONNECTION       ///< Connection value (this should only be modified by advanced users)
};

/// CR Counter Information
/// @note
/// This counter info structure is used by the CR protocol for it's timeout and 
/// timestamps.  The "Speed Test" application may use a different counter to
/// measure "ticks"
const static crcntrinfo_t  myCrCntrInfo = 
{
   0uL,               ///< revision number of structure
   eCRHWTIMER_RTC1,   ///< use RTC1 for hardware timer
   eCRTICKSCNTR_RTC1  ///< use RTC1 for "Ticks" (time stamp)
};
#endif


/* ***************************************************************************
*  CONFIGURATION FOR ANNOUNCEMENT TIMING
*/
#define CONFIG_TICKS_BETWEEN_FAST_ANNOUNCEMENTS  (25000uL /*25 milliseconds*/)  ///< microseconds between announcements


/* ***************************************************************************
*  PRIVATE VARIABLES
*/
static uint8_t rxBufr[CONFIG_NUM_RX_BUFRS][CONFIG_RX_BUFR_SIZE];

#ifdef CONFIG_SENSOR_CODE
static uint8_t txMsgD[CONFIG_NUM_TX_MSGS ][CONFIG_TX_MSG_MAXSIZE];
#endif


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE PROCEDURES
*/
static void     RadioTest_Clock_Init( void);
static void     RadioTest_DelayAfterStart( uint32_t ticksStart, uint32_t ticksDelay);
static void     RadioTest_GPIO_Init( void);
static void     RadioTest_LED_DelayOff( uint32_t ticksStart, uint32_t ticksDelay);
static void     RadioTest_LED_Off( void);
static uint32_t RadioTest_LED_On( void);
static void     RadioTest_Timer_Init( void);
static uint32_t RadioTest_Timer_Read( void);
static uint32_t RadioTest_Timer_TicksAfterStart( uint32_t ticksStart);
static __INLINE uint32_t RadioTest_Timer_TicksDelta( const uint32_t ticksStart,
                                                     const uint32_t ticksStop, 
                                                     const uint32_t ticksMask);   

#ifdef CONFIG_SENSOR_CODE
static void     SpeedTest_TxMsg_Fill( uint8_t txMsg[], uint8_t txMsgSize, uint8_t msgCntr);
#endif

/*  **************************************************************************/
/** ***************************************************************************
*   MAIN TEST CODE (for base or sensor)
*   @returns     void
*
*   @details
*   This section contains Speed Test code for both BASE and SENSOR (only one
*   should be active.
*
*   @note
*   Extra variables have been added to the SENSOR code to measure performance.
*   The reader will need to use the Keil debugger to get the variable values.
*/
#ifdef CONFIG_BASE_CODE
int  main( void)
{
   int indx;
   int msgsReceived;
   uint8_t* rxMsgPtr;
   uint32_t ticksMsgReceived;
   uint32_t ticksSinceMsgRx;
   volatile uint32_t ticksForSpeedTest;
   volatile uint32_t ticksDelayStart;
   uint8_t  rxMsgLengthByte;
   // Initialize
   RadioTest_Clock_Init();
   RadioTest_GPIO_Init();
   RadioTest_Timer_Init();
   CR_Disable();
   // Enable the device as a BASE and using RTC1
   CR_Enable( &myDeviceInfo, &myCrCntrInfo);
   // "Add" receive buffer(s) to CR
   for( indx=0; indx<CONFIG_NUM_RX_BUFRS; indx+=1)
   {
      (void)CR_AddRxBufr( rxBufr[indx], CONFIG_RX_BUFR_SIZE);
   }
   // BASE use default Acknowledgements, no transmit messages
   // Flash LED for 2 seconds
   RadioTest_LED_On();
   ticksDelayStart = RadioTest_Timer_Read();
   RadioTest_LED_DelayOff( ticksDelayStart, 2000000uL/*two seconds*/);
   // Delay 1 second
   ticksDelayStart = RadioTest_Timer_Read();
   RadioTest_DelayAfterStart( ticksDelayStart, 1000000uL/*one seconds*/);
   // 
   // FOREVER LOOP
   while( 1)
   {
      // Top of Loop
      msgsReceived = 0;
      // Start BASE Listening
      CR_Listen();
      // Wait for first Received packet (with any Device Identifier)
      while( msgsReceived == 0)
      {
         rxMsgPtr = CR_GetRxMsg( CONST_DEVICEID_ALWAYS_MATCH, CONST_NULLPTR);
         if( rxMsgPtr != CONST_NULLPTR)
         {
            // Real message received (not default announcement) if first byte greater-than '3'
            rxMsgLengthByte = *rxMsgPtr;
            if( (uint16_t)rxMsgLengthByte > (uint16_t)3u)
            {
               // First message received
               // ... Turn on LED
               RadioTest_LED_On();
               msgsReceived = 1;
            }
            // Remove message, then "Add" receive buffer back into CR
            (void)CR_RemoveRxBufr( rxMsgPtr);
            (void)CR_AddRxBufr( rxMsgPtr, CONFIG_RX_BUFR_SIZE);
         }
      }
      // First message has been received
      // RE-Start BASE Listening - in case it stopped
      CR_Listen();
      // log "ticks" of received message; update 'msgsReceived'
      ticksMsgReceived = RadioTest_Timer_Read();
      // Continue receiving messages
      // Wait until 256 messages received OR 5 seconds from last messages received
      ticksSinceMsgRx = RadioTest_Timer_TicksAfterStart( ticksMsgReceived);
      while( (msgsReceived < 256) && (ticksSinceMsgRx < 5000000uL /*5 seconds*/))
      {
         rxMsgPtr = CR_GetRxMsg( CONST_DEVICEID_ALWAYS_MATCH, CONST_NULLPTR);
         if( rxMsgPtr != CONST_NULLPTR)
         {
            // Real message received (not default announcement) if first byte greater-than '3'
            rxMsgLengthByte = *rxMsgPtr;
            if( (uint16_t)rxMsgLengthByte > (uint16_t)3u)
            {
               // Non-announcement message was received, so count it
               msgsReceived += 1;
            }
            // log "ticks" of any kind of message
            ticksMsgReceived = RadioTest_Timer_Read();
            // Remove message, then "Add" receive buffer back into CR
            (void)CR_RemoveRxBufr( rxMsgPtr);
            (void)CR_AddRxBufr( rxMsgPtr, CONFIG_RX_BUFR_SIZE);
            // RE-Start BASE Listening - in case it stopped
            CR_Listen();
         }
         // Update ticks since last message received
         ticksSinceMsgRx = RadioTest_Timer_TicksAfterStart( ticksMsgReceived);
         // Bottom of loop to receive total of 256 messages
      }
      // EITHER 256 messages received OR too long a delay
      // Turn LED off now
      RadioTest_LED_DelayOff( 0uL, 0uL);
      // Delay 1/2 second
      ticksDelayStart = RadioTest_Timer_Read();
      RadioTest_DelayAfterStart( ticksDelayStart, 500000uL/*half second*/);
      // bottom of "forever" loop     
   }
   // CODE SHOULD NEVER REACH HERE
}
#endif

#ifdef CONFIG_SENSOR_CODE
int  main( void)
{
   int indx;
   int msgsSentAndExchanged;
   uint8_t  msgCntr;
   uint8_t  msgSize;
   uint8_t* rcvdMsgPtr;
   uint8_t* txMsgPtr;
   uint32_t ticksAnnounce;
   uint32_t ticksDelayStart;
   uint32_t ticksTestStart;
   volatile uint32_t ticksSinceTestStart;
   crstatus_t       protocolStatus;
   exchangestatus_t exchangeStatus;
   // Initialize
   RadioTest_Clock_Init();
   RadioTest_GPIO_Init();
   RadioTest_Timer_Init();
   CR_Disable();
   // Enable the device as a SENSOR and using RTC1
   CR_Enable( &myDeviceInfo, &myCrCntrInfo);
   // "Add" receive buffer(s) to CR
   for( indx=0; indx<CONFIG_NUM_RX_BUFRS; indx+=1)
   {
      (void)CR_AddRxBufr( rxBufr[indx], sizeof(rxBufr[indx]));
   }
   // Flash LED for 2 seconds
   ticksDelayStart = RadioTest_LED_On();
   RadioTest_LED_DelayOff( ticksDelayStart, 2000000uL/*two seconds*/);
   // Delay 1 second
   ticksDelayStart = RadioTest_Timer_Read();
   RadioTest_DelayAfterStart( ticksDelayStart, 1000000uL/*one seconds*/);
   // FOREVER LOOP
   while( 1)
   {
      // Top of Loop
      msgCntr = 0u;
      // SET 'ticksTestStart' FOR THE SPEED TEST
      ticksTestStart = RadioTest_Timer_Read();
      // Turn LED On to mark Start of test, ignore return value
      (void)RadioTest_LED_On();
      // Initialize transmit messages using 'msgCntr' to simulate data
      //  and add messages to the Buffers
      for( indx=0; indx<CONFIG_NUM_TX_MSGS; indx+=1)
      {
         msgSize = (uint8_t)CONFIG_TX_MSG_MAXSIZE - (uint8_t)1u;
         SpeedTest_TxMsg_Fill( txMsgD[indx], msgSize, msgCntr);
         (void)CR_AddTxMsg( txMsgD[indx], eCRTXFLAGS_NONE, eADDMSGMODE_IF_NOTFULL);
         msgCntr += 1u;
      }
      // Loop Counting until 256 messages (of 250 bytes) have been sent
      for( msgsSentAndExchanged = 0L; msgsSentAndExchanged < 256L; /*no update*/)
      {
         // Announce now
         ticksAnnounce = RadioTest_Timer_Read();
         CR_Announce( CONST_NULLPTR);
         // Wait until CR completes Announcement and exchanges
         protocolStatus = CR_Status_Get();
         while( (protocolStatus != eCR_STATUS_ERROR) && 
                (protocolStatus != eCR_STATUS_DISABLED) && 
                (protocolStatus != eCR_STATUS_IDLE) )
         {
            protocolStatus = CR_Status_Get();
         }
         // Process each transmitted message
         txMsgPtr = CR_GetTxMsg( myDeviceInfo.deviceID, CONST_NULLPTR, &exchangeStatus);
         for( indx=0; (indx<CONFIG_NUM_TX_MSGS) && (txMsgPtr != CONST_NULLPTR); indx+=1)
         {
            // For each message transmitted...
            // ...if exchanged...
            if( exchangeStatus == eEXCHANGE_RX_RCVD)
            {
               // increment messages sent
               msgsSentAndExchanged += 1;
               // To simulate new data, re-load data; increment 'msgCntr' used to fill data
               msgSize = (uint8_t)CONFIG_TX_MSG_MAXSIZE - (uint8_t)1u;
               SpeedTest_TxMsg_Fill( txMsgPtr, msgSize, msgCntr);
               msgCntr += 1u;
            }
            // ...remove message, then re-load message
            (void)CR_RemoveTxMsg( txMsgPtr);
            (void)CR_AddTxMsg( txMsgPtr, eCRTXFLAGS_NONE, eADDMSGMODE_IF_NOTFULL);
            // Get next transmitted message to process
            txMsgPtr = CR_GetTxMsg( myDeviceInfo.deviceID, CONST_NULLPTR, &exchangeStatus);
            // end of process transmitted message loop
         }
         // All transmit messages have been processed
         // "Get" and throwaway any received messages
         rcvdMsgPtr = CR_GetRxMsg( CONST_DEVICEID_ALWAYS_MATCH, CONST_NULLPTR);
         while( rcvdMsgPtr != CONST_NULLPTR)
         {
            (void)CR_RemoveRxBufr( rcvdMsgPtr);
            (void)CR_AddRxBufr( rcvdMsgPtr, CONFIG_RX_BUFR_SIZE);
            rcvdMsgPtr = CR_GetRxMsg( CONST_DEVICEID_ALWAYS_MATCH, CONST_NULLPTR);
         }
         // Announcements should occur periodically
         RadioTest_DelayAfterStart( ticksAnnounce, CONFIG_TICKS_BETWEEN_FAST_ANNOUNCEMENTS);
      }
      // 256 messages have been sent and 'acked'
      // Turn LED off now
      RadioTest_LED_DelayOff( 0uL, 0uL);
      //
      // ******
      // GET THE NUMBER OF TICKS SINCE THE SPEED TEST STARTED
      // Bytes per second is  64,000/'ticksSinceTestStart' * 1,000,000
      
      ticksSinceTestStart = RadioTest_Timer_TicksAfterStart( ticksTestStart);
      // (Test of 'ticksSinceTestStart' avoids compiler warning)
      if( ticksSinceTestStart == 0uL)   //<---- Set breakpoint here to get value
      {
         ticksSinceTestStart += 1uL;
      }
      // ******
      // Remove all transmit messages at end of test to remove any "messages ready to transmit"
      // WARNING: the code will fail if somehow transmit messages are "added" more than once
      for( indx=0; indx<CONFIG_NUM_TX_MSGS; indx+=1)
      {
         (void)CR_RemoveTxMsg( txMsgD[indx]);
      }
      // Wait full 10 seconds
      ticksDelayStart = RadioTest_Timer_Read();
      RadioTest_DelayAfterStart( ticksDelayStart, 10000000uL/*10 seconds*/);
      // bottom of "forever" loop     
   }
   // CODE SHOULD NEVER REACH HERE
}
#endif

/* ***************************************************************************/
/* ***************************************************************************
*  PRIVATE PROCEDURES -- in alphabetical order
*/

/** ***************************************************************************
*  RADIO TEST CLOCK INIT
*
*  Initializes and Starts the Crystals and Clocks on CR hardware module
*  @returns     void
*
*  @note
*  Radio hardware requires HFCLK to operate.
*  RTC1 uses LFCLK.
*/
#if defined(NRF51)
// Clock initialization for nRF51
static void RadioTest_Clock_Init( void)
{
   // Set for 16MHz crystal
   NRF_CLOCK->XTALFREQ = CLOCK_XTALFREQ_XTALFREQ_16MHz;
   // Start high-frequency crystal oscillator 
   NRF_CLOCK->EVENTS_HFCLKSTARTED  = 0uL;
   NRF_CLOCK->TASKS_HFCLKSTART = 1uL;
   // Start low-frequency crystal and use as source for LFCLK
   NRF_CLOCK->LFCLKSRC = CLOCK_LFCLKSRC_SRC_Xtal;
   NRF_CLOCK->EVENTS_LFCLKSTARTED = 0uL;
   NRF_CLOCK->TASKS_LFCLKSTART = 1uL;
   // Wait for HFCLK to start
   while( NRF_CLOCK->EVENTS_HFCLKSTARTED == 0uL);
   // Wait for LFCLK to start
   while( NRF_CLOCK->EVENTS_LFCLKSTARTED == 0uL);
   // Clocks started
   return;
}

#elif defined(NRF52840_XXAA)
// Clock initialization for nRF52840
static void RadioTest_Clock_Init( void)
{
   // Start high-frequency crystal oscillator 
   NRF_CLOCK->EVENTS_HFCLKSTARTED  = 0uL;
   NRF_CLOCK->TASKS_HFCLKSTART = 1uL;
   // Start low-frequency crystal and use as source for LFCLK
   NRF_CLOCK->LFCLKSRC = (CLOCK_LFCLKSRC_SRC_Xtal << CLOCK_LFCLKSRC_SRC_Pos) |
	                       (CLOCK_LFCLKSRC_BYPASS_Disabled << CLOCK_LFCLKSRC_BYPASS_Pos) |
	                       (CLOCK_LFCLKSRC_EXTERNAL_Disabled << CLOCK_LFCLKSRC_EXTERNAL_Pos);
   NRF_CLOCK->EVENTS_LFCLKSTARTED = 0uL;
   NRF_CLOCK->TASKS_LFCLKSTART = 1uL;
   // Wait for HFCLK to start
   while( NRF_CLOCK->EVENTS_HFCLKSTARTED == 0uL);
   // Wait for LFCLK to start
   while( NRF_CLOCK->EVENTS_LFCLKSTARTED == 0uL);
   // Clocks started
   return;
}

#else
// Unknown device
static void RadioTest_Clock_Init( void)
{
   // do nothing
	 return;
}
#endif


/** ***************************************************************************
*  RADIO TEST DELAY AFTER START
*
*  Code "loops" until delay in ticks has occurred
*  @returns     void
*  @param[in]   ticksStart - 32-bit value
*  @param[in]   ticksDelay - 32-bit value for number ot ticks from 'ticksStart'
*/
static void  RadioTest_DelayAfterStart( uint32_t ticksStart, uint32_t ticksDelay)
{
   uint32_t ticksAfterStart;
   ticksStart = RadioTest_Timer_Read();
   ticksAfterStart = RadioTest_Timer_TicksAfterStart( ticksStart);
   while( ticksAfterStart < ticksDelay)
   {
      ticksAfterStart = RadioTest_Timer_TicksAfterStart( ticksStart);
   }
   // done
   return;
}


/** ***************************************************************************
*  RADIO TEST GPIO INIT
*
*  Initializes the GPIO ports used by the Speed Test
*  @returns     void
*/
static void RadioTest_GPIO_Init( void)
{
   uint32_t pinInfo;
   // LED
   //   initial output value is low (for LED off)
   //   pin configured with input feedback disconnected, no input resistors
   //   pin configured as push-pull output
   RadioTest_LED_Off();
   // Create Pin Input info
   pinInfo = ( ((uint32_t)GPIO_PIN_CNF_INPUT_Disconnect << GPIO_PIN_CNF_INPUT_Pos) |
               ((uint32_t)GPIO_PIN_CNF_PULL_Disabled << GPIO_PIN_CNF_PULL_Pos)  |
               ((uint32_t)GPIO_PIN_CNF_SENSE_Disabled << GPIO_PIN_CNF_SENSE_Pos)
             );
   // Create Pin Output info
   pinInfo |=  ( ((uint32_t)GPIO_PIN_CNF_DIR_Output << GPIO_PIN_CNF_DIR_Pos) |
                 ((uint32_t)GPIO_PIN_CNF_DRIVE_S0S1 << GPIO_PIN_CNF_DRIVE_Pos)
               );
   // Set Pin Configuration
   NRF_GPIO->PIN_CNF[CONST_PIN_OUTPUT_LED] = pinInfo;
   // done
   return;
}


/** ***************************************************************************
*  RADIO TEST LED DELAY OFF
*
*  Turns on the LED for a specified number of clock 'ticks'.
*  Code "loops" until time to turn LED "off"
*  @returns     void
*  @param[in]   ticksStart - 32-bit value
*  @param[in]   ticksDelay - 32-bit value for time LED is on
*
*  @note
*  To turn off LED immediately, call "RadioTest_LED_DelayOff( 0uL, 0uL);"
*/
static void  RadioTest_LED_DelayOff( uint32_t ticksStart, uint32_t ticksDelay)
{
   uint32_t ticksAfterStart;
   ticksAfterStart = RadioTest_Timer_TicksAfterStart( ticksStart);
   while( ticksAfterStart < ticksDelay)
   {
      ticksAfterStart = RadioTest_Timer_TicksAfterStart( ticksStart);
   }
   // Turn off LED
   RadioTest_LED_Off();
   return;
}


/** ***************************************************************************
*  RADIO TEST LED OFF
*
*  Turns off the LED
*  @returns     void
*/
static void  RadioTest_LED_Off( void)
{
   NRF_GPIO->OUTCLR = (1uL << CONST_PIN_OUTPUT_LED);
   return;
}


/** ***************************************************************************
*  RADIO TEST LED ON
*
*  Turns on the LED and returns the start time in Ticks
*  @returns     uint32_t that represents the LED on time in ticks
*/
static uint32_t  RadioTest_LED_On( void)
{
   uint32_t  ticksStart;
   NRF_GPIO->OUTSET = (1uL << CONST_PIN_OUTPUT_LED);
   ticksStart = RadioTest_Timer_Read();
   // done
   return ticksStart;
}


/** ***************************************************************************
*  RADIO TEST TIMER INIT
*
*  Initializes and Starts the Timer used by the Speed Test
*  @returns     void
*
*  @details
*  Timer 0 is sourced from HFCLK (16 MHz) or HFCLK/16; the source is automatically
*  selected based upon the pre-scaler value.  The timer prescaler is set to 2^4
*  so there is 1 microsecond between 'ticks' (prescaler of 2^4); timer size set
*  to 32-bits.
*
*  @warning
*  On the nRF51 not all timers can be configured for 32-bits; be careful if
*  modifying code to use a different timer.
*/
static void RadioTest_Timer_Init( void)
{
   // Stop Timer, Clear and Configure
   NRF_TIMER0->TASKS_STOP = 1uL;
   NRF_TIMER0->TASKS_CLEAR = 1uL;
   NRF_TIMER0->MODE = (TIMER_MODE_MODE_Timer << TIMER_MODE_MODE_Pos);
   NRF_TIMER0->BITMODE = (TIMER_BITMODE_BITMODE_32Bit << TIMER_BITMODE_BITMODE_Pos);
   NRF_TIMER0->PRESCALER  = ((uint32_t)4u << TIMER_PRESCALER_PRESCALER_Pos);
   // Start Timer
   NRF_TIMER0->TASKS_START = 1uL;
   //done
   return;
}


/** ***************************************************************************
*  RADIO TEST TIMER READ
*
*  Returns the value of the timer
*  @returns     uint32_t value of timer
*
*  @details
*  In the nRF51 architecture, the timer values can not be read directly.  A 
*  capture of the value is forced and then the value of the capture register is
*  returned.  This function uses CC[0].
*/
static uint32_t RadioTest_Timer_Read( void)
{
   NRF_TIMER0->TASKS_CAPTURE[0] = 1uL;
   (void)__NOP;
   return NRF_TIMER0->CC[0];
}


/** ***************************************************************************
*  RADIO TEST TIMER TICKS AFTER START
*
*  Returns the number of ticks after the "ticks start" value
*  @returns     uint32_t result of calculation
*  @param[in]   ticksStart - starting "ticks" value used in calculations
*
*  @note
*  If this function is passed a 'ticksStart' value equal to zero, the return 
*  value is the current value of the timer.
*
*  @note
*  The function defines a constant variable for timer mask.  The current code
*  uses Timer0, which is 32-bits.  Other timers in the nRF51 may be implemented
*  with less bits.  The timer mask allows for easy use of these "smaller" 
*  timers.  
*/
static uint32_t RadioTest_Timer_TicksAfterStart( uint32_t ticksStart)
{
   uint32_t  result;
   uint32_t  ticksNow;
   const uint32_t cntrMask = 0xFFFFFFFFuL;
   ticksNow = RadioTest_Timer_Read();
   result = RadioTest_Timer_TicksDelta( ticksNow, ticksStart, cntrMask);
   // done
   return result;
}


/** ***************************************************************************
*  RADIO TEST TIMER TICKS DELTA
*
*  Returns the difference between two "ticks" values using a mask.  The mask
*  allows the timer to be less than 32-bits wide.
*  @returns     uint32_t result of calculation
*  @param[in]   ticksStop  - ending "ticks" value used in calculations
*  @param[in]   ticksStart - starting "ticks" value used in calculations
*  @param[in]   ticksMask  - bit mask of "ticks" counter
*/
static __INLINE uint32_t RadioTest_Timer_TicksDelta( const uint32_t ticksStop,
                                               const uint32_t ticksStart, 
                                               const uint32_t ticksMask)
{
   uint32_t result;
   result = ((ticksStop - ticksStart) & ticksMask);
   return result;
}


#ifdef CONFIG_SENSOR_CODE
/** ***************************************************************************
*   TRANSMIT MESSAGE FILL
*   @returns     void
*
*   @details
*   To make tracking messages easier, the data in each message is a repeated
*   pair of bytes.  The first byte is an 8-bit byte counter and the second
*   byte is an 8-bit message counter.
*   Each transmit message may contain up to 250 data bytes, so the byte counter
*   may range from 0 to 249.  (Assumes CONFIG_TX_MSG_MAXSIZE equals 254.)
*/
static void  SpeedTest_TxMsg_Fill( uint8_t txMsg[], uint8_t txMsgSize, uint8_t msgCntr)
{
   uint32_t byteCntr;
   // Initialize "size" byte
   txMsg[0] = txMsgSize;
   // "Put" device identifier into message starting a byte offset 1
   CrDeviceId_PutBytes( myDeviceInfo.deviceID, &txMsg[1]);
   for( byteCntr = 4u; byteCntr < (uint32_t)CONFIG_TX_MSG_MAXSIZE; byteCntr +=2u)
   {
      txMsg[byteCntr + 0u] = (uint8_t)byteCntr;
      txMsg[byteCntr + 1u] = msgCntr;
   }
   // done
   return;
}
#endif

/* ************** END OF FILE   SPEEDTEST_CR_C ***************************** */

#define CRSIMPLE_C      ///< file tag

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      CrSimple - an optional, "simple" API for the Coriandolo Radio 
*                         Protocol.
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2016-01-30
*  @date       last modified by Craig Goldman 2017-09-16
*
*  @copyright  Copyright (c) 2016, 2017 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyrigh
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*  @details
*  This file contains an Application Program Interface (API) for the Coriandolo
*  Radio Protocol that is easier to use the than the full API proviced in "CR.c".
*  This "simple" interface selects the most common operating options, 
*  automatically manages the radio receive buffers and assists with transmit 
*  message usage.  "CrSimple" is available for either SENSOR or BASE devices. It
*  is fully compatible with full Coriandolo devices, i.e. it is possible to mix
*  SENSOR and BASE devices using "CrSimple" with devices that do not.
*
*  @warning
*  Non-"CrSimple" devices must use a "Connection" value matching 
*  CONST_CRSIMPLE_CONNECTION to communicate with devices using "CrSimple".
*
*  @brief
*  CR = Coriandolo Radio
*
*  @note
*  THIS FILE MAY BE MODIFIED TO SUIT THE APPLICATION PROGRAM.
*
*/

/* ***************************************************************************
*  INCLUDE FILES
*
*  NOTE: "<string.h>" included for "memcpy"
*/
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "../CR/CR_PublicTypes.h"
#include "../CR/CR.h"
#include "CrSimple.h"

#if defined(NRF51) || defined(NRF52840_XXAA)
#include "nrf.h"
#endif


/* ***************************************************************************
*  PRIVATE CONSTANTS
*
*  @note
*  All BASE devices using the CrSimple Wrapper use a Default Device Identifier.
*
*  @note
*  CrSimple always uses a special CR "Connection" value.
*/
#define CONST_DEFAULT_BASE_DEVICEID    (0x00FFFFFEuL)    ///< Device Identifier used for all bases of CR Simple
#define CONST_CRSIMPLE_CONNECTION      (0xFFFEu)         ///< Connection value used for CR Simple Wrapper


/* ***************************************************************************
*  PRIVATE VARIABLES
*/
static uint8_t  s_rxMaxBytes;
static crtype_t s_enabledAsCrType;


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE PROCEDURES
*/
static crstatus_t  CrSimple_DoAnnouncement( void);
static bool        CrSimple_IsDeviceIdle( void);
static void        CrSimple_RxBufrs_Add( uint8_t* rxBytes, 
                                         const uint32_t bytesRemaining, 
                                         const uint8_t rxSize);
                                         

/* ***************************************************************************
*  SPECIAL PROTOTYPES FOR PRIVATE NRF5x CLOCK PROCEDURES
*/
static void  nRF5x_Clock_HFClk_StartXtal( void);
static void  nRF5x_Clock_HFClk_StopXtal( void);
static void  nRF5x_Clock_HFClk_WaitForStartUp( void);
static void  nRF5x_Clock_LFClk_StartXtal( void);


/*  **************************************************************************/
/** **************************************************************************
*  MODULE INITIALIZATION PROCEDURE
*
*  -- All modules must have a "..._InitStatics" procedure to initialize static 
*  variables to known values.
*  @returns   void
*/
void  CrSimple_InitStatics( void)
{
   // Initialize static variables to known values
   s_rxMaxBytes = (uint8_t)0u;
   s_enabledAsCrType = eCRTYPE_ERROR;
   return;
}


/* ***************************************************************************/
/* ***************************************************************************
*  PUBLIC PROCEDURES -- in alphabetical order
*/

/** ***************************************************************************
*  CORIANDOLO RADIO SIMPLE ANNOUNCE NOW
*
*  Starts a Coriandolo Radio Announcement using the Default Announcement message.
*  @returns   boolean 'true' if no error occurred.
*
*  @details
*  This function waits for the Announcement to complete.
*
*  For convenience, the SENSOR device enables the High-Frequency Crystal at the
*  beginning of Announcement.  On an nRF51, starting thus crystal takes about
*  400 microseconds; it is a bit faster on an nRF52.  (Of course, the time is
*  dependent upon the component chosen.)  If the high-frequency cyrstal is already
*  operating, only a minimal delay occurs.
*
*  @warning
*  This function disables the high-frequency crystal when the Announcement and
*  Announcement Exchanges (if any) are complete.  This reduces the power 
*  consumption of the SENSOR device.  If an application needs an accurate 
*  time-base, it may use the Low-frequency crystal.  The application programmer
*  also may remove the call to "nRF5x_Clock_HFClk_StopXtal".
*/
bool  CrSimple_AnnounceNow( void)
{
   bool  isNoError;
   crstatus_t  protocolStatus;
   protocolStatus = CR_Status_Get();
   if( protocolStatus == eCR_STATUS_IDLE)
   {
      // Start High-frequency crystal
      //   -- no error occurs if HF crystal is already started
      nRF5x_Clock_HFClk_StartXtal();
      nRF5x_Clock_HFClk_WaitForStartUp();
      // Do SENSOR Radio Announcement and get status
      protocolStatus = CrSimple_DoAnnouncement();
      // Announcement has completed.
      // Disable the High-frequency crystal to save power
      nRF5x_Clock_HFClk_StopXtal();
   }
   // Protocol status should be IDLE; anything else means an error occurred
   if( protocolStatus == eCR_STATUS_IDLE)
   {
      isNoError = true;
   }
   else
   {
      isNoError = false;
   }
   return isNoError;
}


/** ***************************************************************************
*  CORIANDOLO RADIO SIMPLE DISABLE
*
*  Disables operation of the Coriandolo Radio protocol.  
*  @returns   void
*
*  @details
*  Stops any radio activity and disables the radio hardware.
*  This will put CR into the lowest-possible power state.
*
*  @note
*  This code disables the High-Frequency Clock Crystal.
*  The CPU may continue to run with less accurate timing, but approximately the
*  same frequency, using the internal RC Oscillator.  Stopping the HF Crystal 
*  does not affect operation of the Low-Frequency crystal.
*/
void  CrSimple_Disable( void)
{
   CR_Disable();
   nRF5x_Clock_HFClk_StopXtal();
   // Initialize statics
   CrSimple_InitStatics();
   return;
}


/** ***************************************************************************
*  CORIANDOLO RADIO SIMPLE ENABLE AS BASE DEVICE
*
*  Enables the Coriandolo Radio Protcol to operate as a BASE device.
*  @returns    boolean 'true' if device is enabled properly.  (Device is Idle.)
*  @param[in]  rxMemPtr - pointer to memory for receiving messages
*  @param[in]  totalRxBytes - size of memory pointed to by 'rxMemPtr'
*  @param[in]  rxMaxBytes - maxumum allowed bytes in a single receive message
*
*  @details
*  The code partitions the passed memory area into one or more receive buffers 
*  and passes them to CR to be used for radio reception.
*
*  For best results, 'totalRxBytes' should be a multiple of 'rxMaxBytes'; it
*  should also be greater-than or equal-to twice 'rxMaxBytes'.
*
*  @note
*  This code enables the High-Frequency Clock Crystal.
*  @note
*  This code does NOT start radio "Listening".
*/
bool  CrSimple_EnableAsBase( uint8_t* rxMemPtr, const uint32_t totalRxBytes, const uint8_t rxMaxBytes)
{
   uint8_t*  rxBytes;
   bool      deviceIsEnabled;
   const deviceinfo_t  myDeviceInfo = 
      {
         CONST_DEVICEINFO_REVISION, 
         eCRTYPE_BASE, 
         CONST_DEFAULT_BASE_DEVICEID, 
         eCRDEVICEOPT_NONE, 
         CONST_CRSIMPLE_CONNECTION
      };
   const crcntrinfo_t  myCrCntrInfo = 
      {
         CONST_CNTRINFO_REVISION, 
         eCRHWTIMER_RTC1, 
         eCRTICKSCNTR_NONE
      };
   // Check parameters before starting CR
   if( (rxMemPtr != CONST_NULLPTR) && (totalRxBytes >= (uint32_t)rxMaxBytes) )
   {
      // Disable the device - in case it was already enabled
      CR_Disable();
      // "CrSimple" uses RTC1 as the hardware Timer - RTC1 clocks from LF clock
      // Start the LF Clock  -- no error occurs if LF clock is already started
       nRF5x_Clock_LFClk_StartXtal();
      // Start the HF Crystal and Enable CR.
      // -- no error occurs if HF clock is already started
      nRF5x_Clock_HFClk_StartXtal();
      // Enable CR 
      // - ignore return value of function, status will be checked later
      (void)CR_Enable( &myDeviceInfo, &myCrCntrInfo);
      // Save value of 'rxMaxBytes' and 's_enabledAsCrType' to be used by 
      //    other functions in "CrSimple"
      s_rxMaxBytes = rxMaxBytes;
      s_enabledAsCrType = eCRTYPE_BASE;
      // Partition receive buffers
      rxBytes = rxMemPtr;
      CrSimple_RxBufrs_Add( rxBytes, totalRxBytes, rxMaxBytes);
      // Wait for HF Crystal start to be completed
      nRF5x_Clock_HFClk_WaitForStartUp();
      // Check device status
      deviceIsEnabled = CrSimple_IsDeviceIdle();
   }
   else
   {
      // return failure
      deviceIsEnabled = false;
   }
   return deviceIsEnabled;
}


/** ***************************************************************************
*  CORIANDOLO RADIO SIMPLE ENABLE AS SENSOR DEVICE
*
*  Enables the Coriandolo Radio Protcol to operate as a SENSOR device.
*  @returns    boolean 'true' if device is enabled properly.  (Device is Idle.)
*  @param[in]  myDeviceId - 24-bit device identifier for CR Protocol
*  @param[in]  rxMemPtr   - pointer to memory for receiving messages
*  @param[in]  totalRxBytes - size of memory pointed to by 'rxMemPtr'
*  @param[in]  rxMaxBytes - maxumum allowed bytes in a single receive message
*
*  @details
*  The code partitions the passed memory area into one or more receive
*  buffers and passes them to CR to be used for radio reception.
*
*  For best results, 'totalRxBytes' should be a multiple of 'rxMaxBytes'; it
*  should also be greater-than or equal-to twice 'rxMaxBytes'
*
*  The 'deviceId' must be a unique number to 24-bits.  The 'deviceId' value
*  should be >= 0x00000001 and <= 0x00FFFFFFFD.  CrSimple reserves use of 
*  device identifier 0x00FFFFFE.
*
*  CrSimple always uses CR "Connection" of equal-to 0xFFFE
*/
bool  CrSimple_EnableAsSensor( const uint32_t myDeviceId, 
                               uint8_t* rxMemPtr, 
                               const uint32_t totalRxBytes, 
                               const uint8_t rxMaxBytes)
{
   uint8_t*   rxBytes;
   bool       deviceIsEnabled;
   const crcntrinfo_t  myCrCntrInfo = 
         {CONST_CNTRINFO_REVISION, eCRHWTIMER_RTC1, eCRTICKSCNTR_NONE};
   deviceinfo_t  myDeviceInfo;
   // Build 'myDeviceInfo'
   myDeviceInfo.revision = CONST_DEVICEINFO_REVISION;
   myDeviceInfo.deviceType = eCRTYPE_SENSOR;
   myDeviceInfo.deviceID = myDeviceId;
   myDeviceInfo.deviceOption = eCRDEVICEOPT_REMOVE_DEFAULT_ACKS;
   myDeviceInfo.connectionValue = CONST_CRSIMPLE_CONNECTION;        
   // Check parameters before starting CR
   //   At this time, system really should have at least 2 receive buffers for sensor
   if( (rxMemPtr != CONST_NULLPTR) && (totalRxBytes >= (2uL * (uint32_t)rxMaxBytes)) )
   {
      // Disable the device - in case it was already enabled
      CR_Disable();
      // "CrSimple" uses RTC1 as the hardware Timer - RTC1 clocks from LF clock
      // Start the LF Clock  -- no error occurs if LF clock is already started
      nRF5x_Clock_LFClk_StartXtal();
      // Enable CR 
      // - ignore return value of function, status will be checked later
      (void)CR_Enable( &myDeviceInfo, &myCrCntrInfo);
      // Save value of 'rxMaxBytes' and 's_enabledAsCrType' to be used by 
      //    other functions in "CrSimple"
      s_rxMaxBytes = rxMaxBytes;
      s_enabledAsCrType = eCRTYPE_SENSOR;
      // Partition receive buffers
      rxBytes = rxMemPtr;
      CrSimple_RxBufrs_Add( rxBytes, totalRxBytes, rxMaxBytes);
      // Check device status
      deviceIsEnabled = CrSimple_IsDeviceIdle();
   }
   else
   {
      // return failure
      deviceIsEnabled = false;
   }
   return deviceIsEnabled;
}


/** ***************************************************************************
*  CORIANDOLO RADIO SIMPLE LISTEN START
*
*  Starts a Coriadolo BASE device "listening" for messages from a SENSOR.
*  @returns   boolean 'true' if the "Listen" started correctly
*
*  @details
*  The listen and listen exchanges continue until "CrSimple_Disable" or 
*  "CrSimple_ListenStop" is called by the application.
*
*  @warning
*  Listen also "stops" if the BASE device has no available Rx buffers.  In this 
*  case, "listening" must be restarted by an EXPLICIT call to
*  "CrSimple_Listen_Start"
*/
bool  CrSimple_Listen_Start( void)
{ 
   bool  isNoError;
   crstatus_t  protocolStatus;
   CR_Listen();
   // Device continues radio "listen" even as code returns
   protocolStatus = CR_Status_Get();
   if( (protocolStatus == eCR_STATUS_BASELISTEN) ||
       (protocolStatus == eCR_STATUS_BASEEXCHANGE) )
   {
      isNoError = true;
   }
   else
   {
      isNoError = false;
   }
   return isNoError;
}


/** ***************************************************************************
*  CORIANDOLO RADIO SIMPLE LISTEN STOP
*
*  "Stops" a BASE device "Listen".
*  @returns   boolean 'true' if the protocol status is IDLE at end of function.
*
*  @details
*  Message receives in progress are allowed to complete.  This funcition returns 
*  true to indicate the device has stopped without error.
*/
bool  CrSimple_Listen_Stop( void)
{
   bool  isIdle;
   if( s_enabledAsCrType == eCRTYPE_BASE)
   {
      // BASE device
      CR_Stop();
      // CR_Stop will wait for radio protocol to stop
   }
   isIdle = CrSimple_IsDeviceIdle();
   return isIdle;
}


/** ***************************************************************************
*  CORIANDOLO RADIO SIMPLE MESSAGE COPY RECEIVED
*
*  Copies received message to 'rxMsg'
*  @returns     boolean 'true' if a received message was copied to 'msgPtr'.
*  @param[out]  msgPtr - pointer to memory for a received message
*  @param[in]   deviceId - device identifier to limit search of received messages
*  @param[in]   maxBytes - maximum number of bytes that will be copied
*
*  @details
*  The function copies a maximum of 'maxBytes'.  The received message is 
*  removed from CR and the message buffer is re-enabled to receive.  If no 
*  message has been received; writes a '0' to the first byte of 'rxMsg'.
*  If the passed parameter 'msgPtr' is a NULL POINTETR, no action is taken.
*
*  A SENSOR application should pass the value of the SENSOR device identifier.
*  A BASE application should pass the value of a specific desired SENSOR device
*  identifier or pass CONST_DEVICEID_ALWAYS_MATCH.
*
*  When the function returns, the first byte of message contains the number
*  of bytes in the message after the first byte.  A '0' indicates no message.
*/
bool  CrSimple_Msg_CopyRcvd( uint8_t* msgPtr, const uint32_t deviceId,
                                              const uint8_t maxBytes)
{
   uint8_t*  rcvdMsgPtr;
   uint32_t  msgSize;
   bool      msgWasRcvd;
   // Make sure destination message pointer is not NULL
   if( msgPtr != CONST_NULLPTR)
   {
      rcvdMsgPtr = CR_GetRxMsg( deviceId, CONST_NULLPTR);
      if( rcvdMsgPtr != CONST_NULLPTR)
      {
         // Message Received with matching Device Identifier
         // Number of received bytes is the value of the first byte + 1
         msgSize = ((uint32_t)*rcvdMsgPtr) + 1u;
         // Copy the bytes, but do not copy more than 'maxBytes'
         if( msgSize > maxBytes)
         {
            msgSize = maxBytes;
         }
         memcpy( msgPtr, rcvdMsgPtr, msgSize);
         // Remove the received buffer and set it back as a new empty
         //   use the saved value for maximum rxsize
         (void)CR_RemoveRxBufr( rcvdMsgPtr);
         (void)CR_AddRxBufr( rcvdMsgPtr, s_rxMaxBytes);
         // Set return value
         msgWasRcvd = true;
      }
      else
      {
         // no message received with matching identifier
         // Set first byte of 'msgPtr' to zero
         *msgPtr = (uint8_t)0u;
         // Set return value
         msgWasRcvd = false;
      }
   }
   else
   {
      // 'msgPtr' is Null Pointer
      msgWasRcvd = false;
   }
   return msgWasRcvd;
}


/** ***************************************************************************
*  CORIANDOLO RADIO SIMPLE MESSAGE GET SENT
*
*  This function returns a pointer to the oldest transmitted message.
*  @returns     pointer to a transmitted message
*  @param[in]   deviceId - device identifier to limit search of received messages
*  @param[in]   msgWasExchangedPtr - pointer to bool that is set to true if message was Exchanged
*
*  @details
*  The transmitted message is removed from CR.  If no transmitted message is 
*  found, the function returns a NULL POINTER.
*
*  If the function is passed a non-null pointer to a boolean, it will be set 
*  to 'true' or 'false' to indicate whether the message was Exchanged.
*
*  @note
*  This function returns a pointer to the oldest transmitted message with no 
*  regard for whether the sent message was "exchanged" or not. 
*
*  @note
*  If a message is "Set Ready To Send" with the "Auto-Retry" Flag (standard 
*  option for a SENSOR device), the message status will not indicate that the 
*  message was "sent" until it has been both "sent" and "exchanged".
*/
uint8_t* CrSimple_Msg_GetSent( const uint32_t deviceId, bool* msgWasExchangedPtr)
{
   uint8_t*  txMsgPtr;
   exchangestatus_t  exchangeStatus;
   txMsgPtr = CR_GetTxMsg( deviceId, CONST_NULLPTR, &exchangeStatus);
   if( txMsgPtr != CONST_NULLPTR)
   {
      // Found an "oldest" transmitted message
      // Remove it from CR
      (void)CR_RemoveTxMsg( txMsgPtr);
   }
   else
   {
      // No transmitted message found
      exchangeStatus = eEXCHANGE_NO_RX;
   }
   // Set 'msgWasExchnaged' if 'msgWasExchangedPtr' is not NULL POINTER
   if( msgWasExchangedPtr != CONST_NULLPTR)
   {
      // Set the value pointer to by 'msgWasExchangedPtr' to 'true' or 'false'
      if( exchangeStatus == eEXCHANGE_RX_RCVD)
      {
         *msgWasExchangedPtr = true;
      }
      else
      {
         *msgWasExchangedPtr = false;
      }
   }
   // return pointer to transmitted message or NULL pointer
   return txMsgPtr;
}


/** ***************************************************************************
*  CORIANDOLO RADIO SIMPLE MESSAGE SET READY TO SEND
*
*  This function accepts a pointer to message bytes and adds the pointer to CR so
*  the bytes will be transmitted.
*  @returns    boolean 'true' if the message was successfully accepted for transmit.
*  @param[in]  msgPtr - pointer to bytes of transmit message
*  @param[in]  addMode - enumerated type; if value is eADDMSGMODE_FORCE, message 
*              will be added even if another message must be removed.
*  
*  If 'mspPtr' is already in CR, this will be removed prior to accepting new 
*  message pointer. A message that has been "set ready to send" should not be  
*  modified without removing from CR.
*
*  The first byte of the message should be the number of bytes that follow
*  in the message.  The next 3 bytes are the Device Identifier of the SENSOR.
*
*  @note
*  This function uses eCRTXFLAGS_AUTORETRY for SENSOR devices; this means 
*  SENSOR Transmitted messages will be automatically re-tried if no exchange 
*  occurs after transmission.
*/
bool  CrSimple_Msg_SetReadyToSend( uint8_t* msgPtr, const addmsgmode_t addMode)
{
   bool  isSuccess;
   if( s_enabledAsCrType == eCRTYPE_SENSOR)
   {
      isSuccess = CR_AddTxMsg( msgPtr, eCRTXFLAGS_AUTORETRY, addMode);
   }
   else
   {
      isSuccess = CR_AddTxMsg( msgPtr, eCRTXFLAGS_NONE, addMode);
   }      
   return isSuccess;
}


/** ***************************************************************************
*  CORIANDOLO RADIO SIMPLE MESSAGE TRANSMIT REMOVE
*
*  Removes a message from CR without consideration of message status.
*  @returns   'true' if the message was found and removed from CR
*  @param[in]  msgPtr - pointer to bytes of transmit message (used as identifier)
*
*  CR has a limited number of "slots" available for transmit messages. Removing 
*  a transmit message from CR allows allows room for a new message to be added.
*
*  At this time, this function makes a direct call to CR code.
*/
bool  CrSimple_Msg_TxRemove( const uint8_t* msgPtr)
{
   bool  isSuccess;
   isSuccess = CR_RemoveTxMsg( msgPtr);
   return isSuccess;
}



/* ***************************************************************************/
/* ***************************************************************************
*  PRIVATE PROCEDURES -- in alphabetical order
*/

/* ***************************************************************************
*  CORIANDOLO RADIO SIMPLE DO ANNOUNCEMENT
*
*  Initiates radio communications for a SENSOR with a default Announcement.
*  The function waits until Announcement and Announcement Exchanges have 
*  completed, then returns status.
*/
static crstatus_t  CrSimple_DoAnnouncement( void)
{
   crstatus_t  protocolStatus;
   // Start Radio communications using default Announcement
   CR_Announce( CONST_NULLPTR);
   // Wait until CR completes Announcement and exchanges
   protocolStatus = CR_Status_Get();
   while( (protocolStatus != eCR_STATUS_ERROR) && 
          (protocolStatus != eCR_STATUS_DISABLED) && 
          (protocolStatus != eCR_STATUS_IDLE) )
   {
      protocolStatus = CR_Status_Get();
   }
   return protocolStatus;
}


/* ***************************************************************************
*  CR SIMPLE IS DEVICE IDLE
*
*  Returns 'true' if CR Protocol Status is IDLE; otherwise returns 'false'
*  This is an internal function which called shortly after the "Enable" to 
*  make sure no errors occurred during the "Enable".
*/
static bool  CrSimple_IsDeviceIdle( void)
{
   bool  deviceIsIdle;
   crstatus_t  protocolStatus;
   // Return 'true' if device status is IDLE
   protocolStatus = CR_Status_Get();
   if( protocolStatus == eCR_STATUS_IDLE)
   {
      deviceIsIdle = true;
   }
   else
   {
      deviceIsIdle = false;
   }
   return deviceIsIdle;
}


/* ***************************************************************************
*  CR SIMPLE RECEIVE BUFFERS ADD
*
*  Partitions the Receive Byte Space into individual receive buffers of size
*  'rxSize' and then adds them to the CR Receive Buffer Information.
*
*  This procedure assumes higher-level code has checked passed parameters for
*  valid values.
*/ 
static void  CrSimple_RxBufrs_Add( uint8_t* rxBytes, 
                                   const uint32_t bytesRemaining, 
                                   const uint8_t rxSize)
{
   uint32_t bytesLeft;
   bytesLeft = bytesRemaining;
   for( ; bytesLeft >= (uint32_t)rxSize; bytesLeft -= (uint32_t)rxSize)
   {
      // Add the Receive Buffer, ignore return value
      (void)CR_AddRxBufr( rxBytes, rxSize);
      // Update 'rxBytes' by the number of bytes
      rxBytes += rxSize;
      // Next...
   }
   return;
}


/* ***************************************************************************/
/* ***************************************************************************
*  SPECIAL PRIVATE PROCEDURES FOR CLOCKS (nRF5x hardware dependent)
*/

#if defined (NRF51)
static void  nRF5x_Clock_HFClk_StartXtal( void)
{
   // Start crystal code for CR1 module with nRF51
   // Set for 16MHz crystal
   NRF_CLOCK->XTALFREQ = CLOCK_XTALFREQ_XTALFREQ_16MHz;
   // Start high-frequency crystal oscillator 
   NRF_CLOCK->EVENTS_HFCLKSTARTED  = 0uL;
   NRF_CLOCK->TASKS_HFCLKSTART = 1uL;
   // Do not wait for start to complete
   return;
}

#elif defined (NRF52840_XXAA)
static void  nRF5x_Clock_HFClk_StartXtal( void)
{
   // Start crystal code for CR2 module with nRF52
   // Start high-frequency crystal oscillator 
   NRF_CLOCK->EVENTS_HFCLKSTARTED  = 0uL;
   NRF_CLOCK->TASKS_HFCLKSTART = 1uL;
   // Do not wait for start to complete
   return;
}

#else
   ERROR.  PART NOT SUPPORTED..
#endif


static void  nRF5x_Clock_HFClk_StopXtal( void)
{
   // Stop crystal code for both nRF51 and nRF52
   // Turn off HF Clock
   NRF_CLOCK->TASKS_HFCLKSTOP = 1uL;
   // Do not wait for stop to complete
   return;
}

static void  nRF5x_Clock_HFClk_WaitForStartUp( void)
{
   // Wait code for HF clock start for both nRF51 and nRF52
   while( NRF_CLOCK->EVENTS_HFCLKSTARTED == 0uL);
   return;
}


#if defined (NRF51)
static void  nRF5x_Clock_LFClk_StartXtal( void)
{
   // Start LF crystal code for CR1 module with nRF51
   // Start low-frequency crystal and use as source for LFCLK
   NRF_CLOCK->LFCLKSRC = CLOCK_LFCLKSRC_SRC_Xtal;
   NRF_CLOCK->EVENTS_LFCLKSTARTED = 0uL;
   NRF_CLOCK->TASKS_LFCLKSTART = 1uL;
   // Do not wait for start to complete
   return;
}

#elif defined (NRF52840_XXAA)
static void  nRF5x_Clock_LFClk_StartXtal( void)
{
   // Start LF clock code for CR2 module with nRF52
   //    -- CR2 module does not have a 32KHz crsytal
   // Start 32KHz clock synthesized from HF clock as source for LFCLK
   NRF_CLOCK->LFCLKSRC = CLOCK_LFCLKSRC_SRC_Synth;
   NRF_CLOCK->EVENTS_LFCLKSTARTED = 0uL;
   NRF_CLOCK->TASKS_LFCLKSTART = 1uL;
   // Do not wait for start to complete
   return;
}

#else
   ERROR.  PART NOT SUPPORTED..
#endif


/* ************** END OF FILE   CRSIMPLE_C ********************************* */

var searchData=
[
  ['bufrptr',['bufrPtr',['../structcrbufrinfo__t.html#aef26020497659e0a93ab47c0b3d01147',1,'crbufrinfo_t']]],
  ['bufrsize',['bufrSize',['../structcrbufrinfo__t.html#a87c0f556731f51074a4623c8bd524d65',1,'crbufrinfo_t']]]
];

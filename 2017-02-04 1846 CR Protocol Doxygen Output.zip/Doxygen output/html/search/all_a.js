var searchData=
[
  ['tickvalue',['tickValue',['../structcrbufrinfo__t.html#af8b27cda8ef5ed1f64dfb0e82328f73f',1,'crbufrinfo_t']]],
  ['txinfoptr',['txInfoPtr',['../structcrstateinfo__t.html#a8cd5dbe1527ecbef0d2134ea0948f395',1,'crstateinfo_t']]]
];

var searchData=
[
  ['deviceinfo_5ft',['deviceinfo_t',['../structdeviceinfo__t.html',1,'']]]
];

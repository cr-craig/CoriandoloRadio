var searchData=
[
  ['callback_5ft',['callback_t',['../_callback_8h.html#ad2699888ca5296a26aac48bc0f7b8fbe',1,'Callback.h']]],
  ['crsequencnum_5ft',['crsequencnum_t',['../_cr_bufr_8h.html#a655b880abe439bd9df7359800e71f35a',1,'CrBufr.h']]]
];

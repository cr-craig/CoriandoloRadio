var searchData=
[
  ['exchangecount',['exchangeCount',['../structcrstateinfo__t.html#a6a6774ed254dd701351ae9105c91be9b',1,'crstateinfo_t']]],
  ['exchangestatusbyte',['exchangeStatusByte',['../structcrbufrinfo__t.html#a225356307b2afe7e25d3e9666913c0db',1,'crbufrinfo_t']]]
];

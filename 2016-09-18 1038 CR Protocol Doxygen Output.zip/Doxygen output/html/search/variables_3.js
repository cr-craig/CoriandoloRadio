var searchData=
[
  ['deviceid',['deviceID',['../structdeviceinfo__t.html#afb5f12e594a48db6787ba1756ebf5a90',1,'deviceinfo_t::deviceID()'],['../structcrbufrinfo__t.html#afb5f12e594a48db6787ba1756ebf5a90',1,'crbufrinfo_t::deviceID()']]],
  ['deviceoption',['deviceOption',['../structdeviceinfo__t.html#aaf71fc51d737958e40ccf894d384f824',1,'deviceinfo_t']]],
  ['devicetype',['deviceType',['../structdeviceinfo__t.html#af25a4cc9b999415652315d4d8cce2c35',1,'deviceinfo_t']]]
];

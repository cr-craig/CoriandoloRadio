var searchData=
[
  ['announcementtries',['announcementTries',['../structcrstateinfo__t.html#a53d4d94504f590787d68b20265d94038',1,'crstateinfo_t']]]
];

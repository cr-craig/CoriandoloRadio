var searchData=
[
  ['radiolistenfor1stmsgtimeout',['radioListenFor1stMsgTimeout',['../_c_r_8c.html#a02b27170c1ec8e6c98c97dea03cc5eb2',1,'CR.c']]],
  ['radiolistenforaddresstimeout',['radioListenForAddressTimeout',['../_c_r_8c.html#a3e998350c8d481150e046b79f7726f02',1,'CR.c']]],
  ['radiomessagecompletetimeout',['radioMessageCompleteTimeout',['../_c_r_8c.html#a1ac84755cbbd99114f0fb3889c30322d',1,'CR.c']]],
  ['radiotxaddresstimeout',['radioTxAddressTimeout',['../_c_r_8c.html#a18a57fcc1afb1195679f39a9c03e3c8b',1,'CR.c']]],
  ['revision',['revision',['../structcrcntrinfo__t.html#a7593f6425fdea53d846cc5e89f3727db',1,'crcntrinfo_t::revision()'],['../structdeviceinfo__t.html#a7593f6425fdea53d846cc5e89f3727db',1,'deviceinfo_t::revision()']]],
  ['runflag',['runFlag',['../structcrstateinfo__t.html#ab6b09f07a6789cf658a2ae0bfbc7a687',1,'crstateinfo_t']]],
  ['rxinfoptr',['rxInfoPtr',['../structcrstateinfo__t.html#a46b90f87ce0a21a87b5b0bb8788666fb',1,'crstateinfo_t']]]
];

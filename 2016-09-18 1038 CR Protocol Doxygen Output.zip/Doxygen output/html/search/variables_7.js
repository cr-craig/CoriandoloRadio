var searchData=
[
  ['sequencenum',['sequenceNum',['../structcrbufrinfo__t.html#a546713d20a4f9a8bda20ae4f674de4d2',1,'crbufrinfo_t']]],
  ['spare16',['spare16',['../structcrbufrinfo__t.html#ac698aa54bcdf476209bdd3dbbb127245',1,'crbufrinfo_t']]],
  ['statusbyte',['statusByte',['../structcrbufrinfo__t.html#a1ee63517aff0f3a343822373898de637',1,'crbufrinfo_t']]]
];

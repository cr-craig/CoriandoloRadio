var searchData=
[
  ['radioaddr_5ft',['radioaddr_t',['../n_r_f51___radio_hw_8h.html#a5ac63f941d6d8a525eeca2be8c5575e5',1,'nRF51_RadioHw.h']]],
  ['rtcptr_5ft',['rtcptr_t',['../_c_r_8c.html#a42072177e59e4d217b0705192903f07b',1,'CR.c']]]
];

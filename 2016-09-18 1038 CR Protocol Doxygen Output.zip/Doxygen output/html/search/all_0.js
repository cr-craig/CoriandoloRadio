var searchData=
[
  ['addmsgmode_5ft',['addmsgmode_t',['../_c_r_8h.html#af2f9e2235abe5f3dd76b5c643b32c8c1',1,'CR.h']]],
  ['announcementtries',['announcementTries',['../structcrstateinfo__t.html#a53d4d94504f590787d68b20265d94038',1,'crstateinfo_t']]]
];

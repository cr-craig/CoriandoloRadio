var searchData=
[
  ['exchangecount',['exchangeCount',['../structcrstateinfo__t.html#a9582dd2d5fa7249a2ce2ba0e31947cdc',1,'crstateinfo_t']]],
  ['exchangestatusbyte',['exchangeStatusByte',['../structcrbufrinfo__t.html#a225356307b2afe7e25d3e9666913c0db',1,'crbufrinfo_t']]]
];

var searchData=
[
  ['connectionvalue',['connectionValue',['../structdeviceinfo__t.html#ae229002e70d5c3bf70fcc87441bb6578',1,'deviceinfo_t']]],
  ['crstate',['crState',['../structcrstateinfo__t.html#a6834972a8bce40a52add4caf8805dc36',1,'crstateinfo_t']]],
  ['crtickscntrselect',['crTicksCntrSelect',['../structcrcntrinfo__t.html#aafcc23c27a890da4662bac68e2e3244b',1,'crcntrinfo_t']]],
  ['crtimerselect',['crTimerSelect',['../structcrcntrinfo__t.html#a163494c54ee2869c92c492a95f9a4d81',1,'crcntrinfo_t']]]
];

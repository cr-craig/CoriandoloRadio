var searchData=
[
  ['exchangestatus_5ft',['exchangestatus_t',['../_c_r___public_types_8h.html#ac95787b9aa05cbb07d877017b0b4f6ee',1,'CR_PublicTypes.h']]]
];

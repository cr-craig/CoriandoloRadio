var searchData=
[
  ['radiostatus_5ft',['radiostatus_t',['../n_r_f51___radio_hw_8h.html#a0ec7d26e66bfd49bbacb3f188d347329',1,'nRF51_RadioHw.h']]]
];

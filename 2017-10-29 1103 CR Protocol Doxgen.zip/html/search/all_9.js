var searchData=
[
  ['sequencenum',['sequenceNum',['../structcrbufrinfo__t.html#a546713d20a4f9a8bda20ae4f674de4d2',1,'crbufrinfo_t']]],
  ['speedtest_5fcr_2ec',['SpeedTest_CR.c',['../_speed_test___c_r_8c.html',1,'']]],
  ['speedtest_5fcr_5fc',['SPEEDTEST_CR_C',['../_speed_test___c_r_8c.html#ac833d189de4f8bc06687497cdf498427',1,'SpeedTest_CR.c']]],
  ['statusbyte',['statusByte',['../structcrbufrinfo__t.html#a1ee63517aff0f3a343822373898de637',1,'crbufrinfo_t']]]
];

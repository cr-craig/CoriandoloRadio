var searchData=
[
  ['crbufrinfo_5ft',['crbufrinfo_t',['../structcrbufrinfo__t.html',1,'']]],
  ['crcntrinfo_5ft',['crcntrinfo_t',['../structcrcntrinfo__t.html',1,'']]],
  ['crstateinfo_5ft',['crstateinfo_t',['../structcrstateinfo__t.html',1,'']]]
];

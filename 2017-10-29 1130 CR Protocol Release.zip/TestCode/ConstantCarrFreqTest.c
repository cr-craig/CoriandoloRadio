#define CONSTANTCARRFREQTEST_C       ///< file tag

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This file contains code that runs a constant carrier frequency
*              test on several different frequencies
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 201t-10-12
*  @date       last modified by Craig Goldman 2017-10-12
*
*
*  @copyright  Copyright (c) 2017 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*
*  @details
*  ???? doxygen details needed
*
*  @brief
*  CR = Coriandolo Radio
*
*  @note
*  Readers are welcome to change the code as needed.
*
*/

/* ****************************************************************************
*  SPECIAL DEFINITIONS FOR PC-LINT
*/
// Added to ensure PC-Lint knows correct compiler
#ifndef __CC_ARM
#define __CC_ARM
#endif


/* ***************************************************************************
*  INCLUDE FILES
*/
#include "../CR/RadioHw.h"




/** ***************************************************************************
*  @page ConstantCarrierFreqTest  Constant Carier Frequency Test Code Documentation
*  DOCUMENTATION
*
*  @note
*  This is not really a Coriandolo Radio test.  It is a test of the Radio Module.
*
*  @details
*  This code forces the Radio Module to boardcast a constant carrier on a sequence
*  of frequencies.  Each frequency is held for 10 seconds, then the code switches
*  to a new frequency.
*
*  The table of frequencies is in the variable 's_s_freqTable'.  The reader is
*  welcome to change the frequency values to suit their needs.  The number of
*  frequencies may also be changed and the code should adapt automatically.
*  Frequency values in the table may be repeated.
*  
*/


/** ***************************************************************************
*  TEST CONSTANTS
*/
#define CONST_PIN_OUTPUT_LED            ( 15u)  ///< Port Pin number for LED

/* ***************************************************************************
*  CONSTANT STATIC VARIABLES USED FOR TEST
*/
static const uint32_t  s_freqTable[] = {2402uL,  ///< table of radio frequencies
                                        2422uL, 
                                        2446uL, 
                                        2472uL,
                                        2480uL};


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE PROCEDURES
*/
static void     RadioTest_Clock_Init( void);
static void     RadioTest_DelayAfterStart( uint32_t ticksStart, uint32_t ticksDelay);
static void     RadioTest_GPIO_Init( void);
static void     RadioTest_LED_Off( void);
static void     RadioTest_LED_On( void);
static void     RadioTest_Timer_Init( void);
static uint32_t RadioTest_Timer_Read( void);
static uint32_t RadioTest_Timer_TicksAfterStart( uint32_t ticksStart);
static __INLINE uint32_t RadioTest_Timer_TicksDelta( const uint32_t ticksStart,
                                                     const uint32_t ticksStop, 
                                                     const uint32_t ticksMask);   


/*  **************************************************************************/
/** ***************************************************************************
*   MAIN TEST CODE
*   @returns     void
*
*   @details
*   This code initialzes Radio Module hardware, flashes the LED for two secondz,
*   then begins transmitting a constant carrier.  After 10 seconds, the radio
*   is stopped, a new frequency is selected from the table and the radio begins
*   again to transmit a constant carrier.
*
*   This operation repeats endlessly.                                                     
*/
int  main( void)
{
   int32_t   freqIndx;
   uint32_t  freqMHz;
   uint32_t  ticksDelayStart;
   // Initialize hardware
   RadioTest_Clock_Init();
   RadioTest_GPIO_Init();
   RadioTest_Timer_Init();
   // Shutdown the radio hardware
   RadioHw_Shutdown();
   // Flash LED for 2 seconds
   RadioTest_LED_On();
   ticksDelayStart = RadioTest_Timer_Read();
   RadioTest_DelayAfterStart( ticksDelayStart, 2000000uL/*two seconds*/);
   RadioTest_LED_Off();
   // Configure the Radio Hardware - no device options
   RadioHw_Config( eCRDEVICEOPT_NONE);
   // 
   // FOREVER LOOP
   while( 1)
   {
      // Top of Loop
      for( freqIndx = 0; freqIndx < (sizeof(s_freqTable)/4); freqIndx +=1)
      {
         freqMHz = s_freqTable[ freqIndx];
         // Set frequency and start transmit of carrier signal
         RadioHw_FrequencySet( freqMHz);
         RadioHw_TxStartConstantCarrier();
         // Carrier signal continues to transmit
         ticksDelayStart = RadioTest_Timer_Read();
         RadioTest_DelayAfterStart( ticksDelayStart, 10000000uL/*ten seconds*/);
         // Set breakpoint here to keep the carrier transmitting indefinitely
         (void)__NOP;
         // Stop the radio
         RadioHw_ForceIdle();
         // Next frequency in table
      }
      // Continue - restartting from beginning of frequency table
      // bottom of "forever" loop     
   }
   // CODE SHOULD NEVER REACH HERE
}



/* ***************************************************************************/
/* ***************************************************************************
*  PRIVATE PROCEDURES -- in alphabetical order
*/

/** ***************************************************************************
*  RADIO TEST CLOCK INIT
*
*  Initializes and Starts the Crystals and Clocks on CR hardware module
*  @returns     void
*
*  @note
*  Radio hardware requires HFCLK to operate.
*  RTC1 uses LFCLK.
*/
#if defined(NRF51)
// Clock initialization for nRF51
static void RadioTest_Clock_Init( void)
{
   // Set for 16MHz crystal
   NRF_CLOCK->XTALFREQ = CLOCK_XTALFREQ_XTALFREQ_16MHz;
   // Start high-frequency crystal oscillator 
   NRF_CLOCK->EVENTS_HFCLKSTARTED  = 0uL;
   NRF_CLOCK->TASKS_HFCLKSTART = 1uL;
   // Start low-frequency crystal and use as source for LFCLK
   NRF_CLOCK->LFCLKSRC = CLOCK_LFCLKSRC_SRC_Xtal;
   NRF_CLOCK->EVENTS_LFCLKSTARTED = 0uL;
   NRF_CLOCK->TASKS_LFCLKSTART = 1uL;
   // Wait for HFCLK to start
   while( NRF_CLOCK->EVENTS_HFCLKSTARTED == 0uL);
   // Wait for LFCLK to start
   while( NRF_CLOCK->EVENTS_LFCLKSTARTED == 0uL);
   // Clocks started
   return;
}

#elif defined(NRF52840_XXAA)
// Clock initialization for nRF52840
static void RadioTest_Clock_Init( void)
{
   // Start high-frequency crystal oscillator 
   NRF_CLOCK->EVENTS_HFCLKSTARTED  = 0uL;
   NRF_CLOCK->TASKS_HFCLKSTART = 1uL;
   // Start low-frequency crystal and use as source for LFCLK
   NRF_CLOCK->LFCLKSRC = (CLOCK_LFCLKSRC_SRC_Xtal << CLOCK_LFCLKSRC_SRC_Pos) |
	                       (CLOCK_LFCLKSRC_BYPASS_Disabled << CLOCK_LFCLKSRC_BYPASS_Pos) |
	                       (CLOCK_LFCLKSRC_EXTERNAL_Disabled << CLOCK_LFCLKSRC_EXTERNAL_Pos);
   NRF_CLOCK->EVENTS_LFCLKSTARTED = 0uL;
   NRF_CLOCK->TASKS_LFCLKSTART = 1uL;
   // Wait for HFCLK to start
   while( NRF_CLOCK->EVENTS_HFCLKSTARTED == 0uL);
   // Wait for LFCLK to start
   while( NRF_CLOCK->EVENTS_LFCLKSTARTED == 0uL);
   // Clocks started
   return;
}

#else
// Unknown device
static void RadioTest_Clock_Init( void)
{
   // do nothing
	 return;
}
#endif


/** ***************************************************************************
*  RADIO TEST DELAY AFTER START
*
*  Code "loops" until delay in ticks has occurred
*  @returns     void
*  @param[in]   ticksStart - 32-bit value
*  @param[in]   ticksDelay - 32-bit value for number ot ticks from 'ticksStart'
*/
static void  RadioTest_DelayAfterStart( uint32_t ticksStart, uint32_t ticksDelay)
{
   uint32_t ticksAfterStart;
   ticksStart = RadioTest_Timer_Read();
   ticksAfterStart = RadioTest_Timer_TicksAfterStart( ticksStart);
   while( ticksAfterStart < ticksDelay)
   {
      ticksAfterStart = RadioTest_Timer_TicksAfterStart( ticksStart);
   }
   // done
   return;
}


/** ***************************************************************************
*  RADIO TEST GPIO INIT
*
*  Initializes the GPIO port for the LED.
*  @returns     void
*/
static void RadioTest_GPIO_Init( void)
{
   uint32_t pinInfo;
   // LED
   //   initial output value is low (for LED off)
   //   pin configured with input feedback disconnected, no input resistors
   //   pin configured as push-pull output
   RadioTest_LED_Off();
   // Create Pin Input info
   pinInfo = ( ((uint32_t)GPIO_PIN_CNF_INPUT_Disconnect << GPIO_PIN_CNF_INPUT_Pos) |
               ((uint32_t)GPIO_PIN_CNF_PULL_Disabled << GPIO_PIN_CNF_PULL_Pos)  |
               ((uint32_t)GPIO_PIN_CNF_SENSE_Disabled << GPIO_PIN_CNF_SENSE_Pos)
             );
   // Create Pin Output info
   pinInfo |=  ( ((uint32_t)GPIO_PIN_CNF_DIR_Output << GPIO_PIN_CNF_DIR_Pos) |
                 ((uint32_t)GPIO_PIN_CNF_DRIVE_S0S1 << GPIO_PIN_CNF_DRIVE_Pos)
               );
   // Set Pin Configuration
   NRF_GPIO->PIN_CNF[CONST_PIN_OUTPUT_LED] = pinInfo;
   // done
   return;
}


/** ***************************************************************************
*  RADIO TEST LED OFF
*
*  Turns off the LED
*  @returns     void
*/
static void  RadioTest_LED_Off( void)
{
   NRF_GPIO->OUTCLR = (1uL << CONST_PIN_OUTPUT_LED);
   return;
}


/** ***************************************************************************
*  RADIO TEST LED ON
*
*  Turns on the LED and returns the start time in Ticks
*  @returns     void
*/
static void  RadioTest_LED_On( void)
{
   NRF_GPIO->OUTSET = (1uL << CONST_PIN_OUTPUT_LED);
   // done
   return;
}


/** ***************************************************************************
*  RADIO TEST TIMER INIT
*
*  Initializes and Starts the Timer used by the Speed Test
*  @returns     void
*
*  @details
*  Timer 0 is sourced from HFCLK (16 MHz) or HFCLK/16; the source is automatically
*  selected based upon the pre-scaler value.  The timer prescaler is set to 2^4
*  so there is 1 microsecond between 'ticks' (prescaler of 2^4); timer size set
*  to 32-bits.
*
*  @warning
*  On the nRF51 not all timers can be configured for 32-bits; be careful if
*  modifying code to use a different timer.
*/
static void RadioTest_Timer_Init( void)
{
   // Stop Timer, Clear and Configure
   NRF_TIMER0->TASKS_STOP = 1uL;
   NRF_TIMER0->TASKS_CLEAR = 1uL;
   NRF_TIMER0->MODE = (TIMER_MODE_MODE_Timer << TIMER_MODE_MODE_Pos);
   NRF_TIMER0->BITMODE = (TIMER_BITMODE_BITMODE_32Bit << TIMER_BITMODE_BITMODE_Pos);
   NRF_TIMER0->PRESCALER  = ((uint32_t)4u << TIMER_PRESCALER_PRESCALER_Pos);
   // Start Timer
   NRF_TIMER0->TASKS_START = 1uL;
   //done
   return;
}


/** ***************************************************************************
*  RADIO TEST TIMER READ
*
*  Returns the value of the timer
*  @returns     uint32_t value of timer
*
*  @details
*  In the nRF51 architecture, the timer values can not be read directly.  A 
*  capture of the value is forced and then the value of the capture register is
*  returned.  This function uses CC[0].
*/
static uint32_t RadioTest_Timer_Read( void)
{
   NRF_TIMER0->TASKS_CAPTURE[0] = 1uL;
   (void)__NOP;
   return NRF_TIMER0->CC[0];
}


/** ***************************************************************************
*  RADIO TEST TIMER TICKS AFTER START
*
*  Returns the number of ticks after the "ticks start" value
*  @returns     uint32_t result of calculation
*  @param[in]   ticksStart - starting "ticks" value used in calculations
*
*  @note
*  If this function is passed a 'ticksStart' value equal to zero, the return 
*  value is the current value of the timer.
*
*  @note
*  The function defines a constant variable for timer mask.  The current code
*  uses Timer0, which is 32-bits.  Other timers in the Nordic processors may be 
*  implemented with less bits.  The timer mask allows for easy use of these 
*  "smaller" timers.  
*/
static uint32_t RadioTest_Timer_TicksAfterStart( uint32_t ticksStart)
{
   uint32_t  result;
   uint32_t  ticksNow;
   const uint32_t cntrMask = 0xFFFFFFFFuL;
   ticksNow = RadioTest_Timer_Read();
   result = RadioTest_Timer_TicksDelta( ticksNow, ticksStart, cntrMask);
   // done
   return result;
}


/** ***************************************************************************
*  RADIO TEST TIMER TICKS DELTA
*
*  Returns the difference between two "ticks" values using a mask.  The mask
*  allows the timer to be less than 32-bits wide.
*  @returns     uint32_t result of calculation
*  @param[in]   ticksStop  - ending "ticks" value used in calculations
*  @param[in]   ticksStart - starting "ticks" value used in calculations
*  @param[in]   ticksMask  - bit mask of "ticks" counter
*/
static __INLINE uint32_t RadioTest_Timer_TicksDelta( const uint32_t ticksStop,
                                               const uint32_t ticksStart, 
                                               const uint32_t ticksMask)
{
   uint32_t result;
   result = ((ticksStop - ticksStart) & ticksMask);
   return result;
}


/* ************** END OF FILE   CARRIERCARRFREQTEST_CR_C ******************* */

#ifndef _NRF51_IRQ_H
#define _NRF51_IRQ_H

/* ********************** FILE HEADER ****************************************
*  Created by Craig Goldman 2014-12-16
*  Last modified by Craig Goldman 2016-01-14
*
* Copyright 2014 64 Seconds Inc. as an unpublished work.
* All Rights Reserved.
*
* The following header listing and the binary program to which 
* it pertains are proprietary information of 64 Seconds Inc.
* All information contained here-in shall be considered
* company-confidential and may not be divulged in part or in
* whole, or in any way described, to any person without prior
* written permission of 64 Seconds Inc.
*
*  DESCRIPTION
*  This file is the public file for nRF51 Interrupt inline procedure prototypes
*/


/* ***************************************************************************
*  DOCUMENTATION
*
*  This is an include file that contains inline procedures for disabling and
*  enabling interrupts (also clear pending).  The file also declares a public
*  type which should be used for the interrupt priority of device drivers.
*
*  This file provides a simplier interface to the Nested Vector Interrupt
*  Controller (NVIC) hardware.
*/

/* ***************************************************************************
*  INCLUDE FILE
*/
#include <stdint.h>
#include "nrf51.h"


/* ***************************************************************************
*  PUBLIC TYPES
*/
// These value should be used when calling "IRQ_Enable"
typedef enum
{
   eIRQPRIORITY_LOW        = 0x03u,
   eIRQPRIORITY_MEDIUMLOW  = 0x03u,
   eIRQPRIORITY_MEDIUMHIGH = 0x01u,
   eIRQPRIORITY_HIGH       = 0x00u,
} irqpriority_t;
// NOTE: the nRF51 is a CORTEX M0 device and therefore only supports four 
//       programmable interrupt priority levels.
//       Interrupts for system faults have "negative" priority levels, which
//       makes them higher priority.


/* ***************************************************************************
*  PROTOTYPES FOR STATIC INLINE PROCEDURES
*/
static __INLINE void IRQ_ClearPending( IRQn_Type irqType);
static __INLINE void IRQ_Disable( IRQn_Type irqType);
static __INLINE void IRQ_Enable( IRQn_Type irqType, irqpriority_t priority);



/* ************************************************************************* */
/* ***************************************************************************
*  PUBLIC INLINE PROCEDURES
*/

/* ***************************************************************************
*  IRQ CLEAR PENDING
*
*  Clears any pending interrupt of 'irqType'
*/
static __INLINE void  IRQ_ClearPending( IRQn_Type irqType)
{
   NVIC_ClearPendingIRQ( irqType);
   return;
}


/* ***************************************************************************
*  IRQ DISABLE
*
*  Disables the interrupt of 'irqType'
*/
static __INLINE void  IRQ_Disable( IRQn_Type irqType)
{
   NVIC_DisableIRQ( irqType);
   return;
}


/* ***************************************************************************
*  IRQ ENABLE
*
*  Enables any new interrupt of 'irqType' at interrupt priority level 'priority'
*  Pending interrupt of this type are cleared before the interrupt priority is
*  changed and the interrupt is enabled.
*
*  NOTE: if this procedure is used to change priority level of an interrupt
*        that is already enabled; it is recommended that "IRQ_Disable" be
*        called before calling this procedure
*/
static __INLINE void  IRQ_Enable( IRQn_Type irqType, irqpriority_t priority)
{
   NVIC_ClearPendingIRQ( irqType);
   NVIC_SetPriority( irqType, (uint32_t)priority);
   NVIC_EnableIRQ( irqType);
   return;
}

#endif /* ifndef _NRF51_IRQ_H */

/* ************** END OF FILE   _NRF51_IRQ_H* ******************************* */

#ifndef _NRF51_GPIO_H
#define _NRF51_GPIO_H

/* ********************** FILE HEADER ****************************************
*  Created by Craig Goldman 2014-06-20
*
* Copyright 2014 64 Seconds Inc. as an unpublished work.
* All Rights Reserved.
*
* The following header listing and the binary program to which 
* it pertains are proprietary information of 64 Seconds Inc.
* All information contained here-in shall be considered
* company-confidential and may not be divulged in part or in
* whole, or in any way described, to any person without prior
* written permission of 64 Seconds Inc.
*
*  DESCRIPTION
*  This file is the public file for GPIO inline procedures and functions
*/


/* ***************************************************************************
*  INCLUDE FILE
*/
#include <stdint.h>
#include "nrf51.h"
#include "nrf51_bitfields.h"


/* ***************************************************************************
*  PUBLIC TYPES
*/
typedef enum
{
   eGPIOTE_POLARITY_LOTOHI = GPIOTE_CONFIG_POLARITY_LoToHi,
   eGPIOTE_POLARITY_HITOLO = GPIOTE_CONFIG_POLARITY_HiToLo,
   eGPIOTE_POLARITY_TOGGLE = GPIOTE_CONFIG_POLARITY_Toggle
} gpiotepolarity_t;

typedef enum
{
   ePINDETECT_OFF = GPIO_PIN_CNF_SENSE_Disabled,
   ePINDETECT_HI  = GPIO_PIN_CNF_SENSE_High,
   ePINDETECT_LO  = GPIO_PIN_CNF_SENSE_Low
} pindetect_t;

typedef enum
{
   ePINDRIVE_S0S1 = GPIO_PIN_CNF_DRIVE_S0S1,
   ePINDRIVE_H0S1 = GPIO_PIN_CNF_DRIVE_H0S1,
   ePINDRIVE_S0H1 = GPIO_PIN_CNF_DRIVE_S0H1,
   ePINDRIVE_H0H1 = GPIO_PIN_CNF_DRIVE_H0H1,
   ePINDRIVE_D0S1 = GPIO_PIN_CNF_DRIVE_D0S1,
   ePINDRIVE_D0H1 = GPIO_PIN_CNF_DRIVE_D0H1,
   ePINDRIVE_S0D1 = GPIO_PIN_CNF_DRIVE_S0D1,
   ePINDRIVE_H0D1 = GPIO_PIN_CNF_DRIVE_H0D1
} pindrive_t;

typedef enum
{
   ePININPUT_CONNECT    = GPIO_PIN_CNF_INPUT_Connect,
   ePININPUT_DISCONNECT = GPIO_PIN_CNF_INPUT_Disconnect
} pininput_t;

typedef enum
{
   ePINPULL_PULLNONE  = GPIO_PIN_CNF_PULL_Disabled,
   ePINPULL_PULLDOWN  = GPIO_PIN_CNF_PULL_Pulldown,
   ePINPULL_PULLUP    = GPIO_PIN_CNF_PULL_Pullup
} pinpull_t;

typedef enum
{
   ePINOUTPUT_ACTIVE  = GPIO_PIN_CNF_DIR_Output,
   ePINOUTPUT_OFF     = GPIO_PIN_CNF_DIR_Input
} pinoutput_t;


/* ***************************************************************************
*  PUBLIC INLINE PROCEDURES
*/

static __INLINE void  nRF51_GPIO_Init( void)
{
   // There are no static variables to initialize
   // Do nothing
   return;
}


static __INLINE void GPIO_PinConfig_Input( uint32_t    pin_number, 
                                           pininput_t  pinConnect, 
                                           pinpull_t   pullConfig, 
                                           pindetect_t pinDetect)
{
    uint32_t temp;
    temp = NRF_GPIO->PIN_CNF[pin_number];
    temp &= ~(  GPIO_PIN_CNF_INPUT_Msk | GPIO_PIN_CNF_PULL_Msk 
                                       | GPIO_PIN_CNF_SENSE_Msk);
    /*lint -e{845} // A '0' has been given as right argument to operator '|'" */
    temp |=  (  ((uint32_t)pinConnect << GPIO_PIN_CNF_INPUT_Pos)
              | ((uint32_t)pullConfig << GPIO_PIN_CNF_PULL_Pos)
              | ((uint32_t)pinDetect << GPIO_PIN_CNF_SENSE_Pos)
             );
   NRF_GPIO->PIN_CNF[pin_number] = temp;
   return;
}


static __INLINE void GPIO_PinConfig_Output( uint32_t    pin_number, 
                                            pinoutput_t pinDir, 
                                            pindrive_t  outDrive)
{
   uint32_t temp;
   temp = NRF_GPIO->PIN_CNF[pin_number];
   temp &= ~(  GPIO_PIN_CNF_DIR_Msk | GPIO_PIN_CNF_DRIVE_Msk);
   /*lint -e{845} // A '0' has been given as right argument to operator '|'" */
   temp |=  (  ((uint32_t)pinDir << GPIO_PIN_CNF_DIR_Pos)
             | ((uint32_t)outDrive << GPIO_PIN_CNF_DRIVE_Pos)
            );
   NRF_GPIO->PIN_CNF[pin_number] = temp;
   return;
}


static __INLINE uint32_t GPIO_Input_Get( uint32_t pin_number)
{
   return( NRF_GPIO->IN & (1uL << pin_number));
}


static __INLINE void GPIO_Output_Clr( uint32_t pin_number)
{
   NRF_GPIO->OUTCLR = (1uL << pin_number);
   return;
}


static __INLINE uint32_t GPIO_Output_Get( uint32_t pin_number)
{
   // returns the bit associated with the GPIO output regsiter
   return( (NRF_GPIO->OUTSET >> pin_number) & 0x00000001uL);
}

static __INLINE void GPIO_Output_Set( uint32_t pin_number)
{
   NRF_GPIO->OUTSET = (1uL << pin_number);
   return;
}

static __INLINE void GPIO_Output_Toggle( uint32_t pin_number)
{
   NRF_GPIO->OUT ^= (1uL << pin_number);
   return;
}

static __INLINE void GPIO_Outputs_ClrMask( uint32_t pinMask)
{
   NRF_GPIO->OUTCLR = ( pinMask);
   return;
}

static __INLINE void GPIO_Outputs_SetMask( uint32_t pinMask)
{
   NRF_GPIO->OUTSET = ( pinMask);
   return;
}


static __INLINE void GPIOTE_Disable( uint32_t configNum)
{
   if( configNum < 4uL)
   {
      NRF_GPIOTE->CONFIG[ configNum]
         = (GPIOTE_CONFIG_MODE_Disabled << GPIOTE_CONFIG_MODE_Pos);
   }
   return;
}

static __INLINE void GPIOTE_PinEvent( uint32_t configNum, 
                                      uint32_t pin_number, 
                                      gpiotepolarity_t polarity)
{
   if( configNum < 4uL)
   {
      NRF_GPIOTE->CONFIG[ configNum] 
         =  (  (pin_number << GPIOTE_CONFIG_PSEL_Pos)
             | (GPIOTE_CONFIG_MODE_Event << GPIOTE_CONFIG_MODE_Pos)
             | ((uint32_t)polarity << GPIOTE_CONFIG_POLARITY_Pos)
            );
   }
   return;
}


static __INLINE void GPIOTE_PinEvent_Disable( uint32_t configNum)
{
   if( configNum < 4uL)
   {
      NRF_GPIOTE->CONFIG[ configNum]
         = (GPIOTE_CONFIG_MODE_Disabled << GPIOTE_CONFIG_MODE_Pos);
   }
   return;
}


#endif /* ifndef _NRF51_GPIO_H */

/* ************** END OF FILE   _NRF51_GPIO_H* ***************************** */

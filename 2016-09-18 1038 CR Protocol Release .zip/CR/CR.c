#define CR_C

/** ********************* FILE HEADER ****************************************
*  @file
*  @brief      This is main file of the Coraindolo Radio Protocol
*  @author     Craig Goldman, CoAutomation Inc.
*  @date       created: 2015-01-13
*  @date       last modified by Craig Goldman 2016-09-10
*
*
*  @copyright  Copyright (c) 2015, 2016 64seconds Inc. and CoAutomation Inc.
*
*  @copyright
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  @copyright
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  @copyright
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*
*  @details
*  This file includes all of the code to operate the Coriandolo Radio Module
*  and to communicate between "Sensor" and "Base" devices with the Coriandolo
*  Radio Protocol.  The file hardware-level code to use the RTC1 module.
*  Hardware level code for the radio is found in "nRf51_RadioHw.c"
*
*  @brief
*  CR = Coriandolo Radio
*
*  @warning
*  *** THIS FILE SHOULD NOT BE MODIFIED. ***
*
*  @warning
*  Any modification to this file may cause the Coriandolo Radio Protocol to
*  operate improperly.
*/

/* ***************************************************************************
*  INCLUDE FILES
*/
#include <stdint.h>
#include <stdbool.h>
#include "nrf.h"
#include "CR_PublicTypes.h"
#include "CrBufr.h"
#include "CrDeviceId.h"
#include "CR.h"

// nRF51 Drivers
#include "Drivers/nRF51_IRQ.h"
#include "Drivers/nRF51_RadioHw.h"



/** ***************************************************************************
*  @mainpage
*  BRIEF DOCUMENTATION OF CORIANDOLO RADIO PROTOCOL
*
*  HUB-BASED COMMUNICATIONS NETWORK.
*  The Coriandolo Radio Protocol organizes devices into a network that is 
*  described as a "Hub and Spokes".  The communications network consists of one 
*  hub device and one or more remote devices. The protocol refers to the hub as 
*  the BASE device and the remote devices as SENSOR devices.  The roles of BASE 
*  and SENSOR are fixed while the radio protocol is "enabled".
*
*
*  SENSOR vs. BASE.
*  The SENSOR is the remote device; it is assumed to have limited power resources.
*  The BASE device is assumed to have much large power resources.  The Coriandolo 
*  Radio Protocol is biased to both minimizing radio power for the the SENSOR 
*  device and maximizing data throughput from the SENSOR to the BASE.  The
*  SENSOR device may disable its radio for extended periods of time to further 
*  reduce power.  The BASE device should always be listening, thus the radio for 
*  the BASE is always active and consuming power. Each communication between a 
*  SENSOR and a BASE is initiated by the SENSOR; further the SENSOR determines
*  the number of messages transmitted and received during an "Exchange".  A BASE
*  device always responds to a message successfully received from the SENSOR;
*  thus a BASE device always continues the SENSOR-BASE Exchange of messages.
*
*
*  MESSAGE vs. RADIO PACKET.
*  The Coriandolo Radio Protocol sends and receive messages between devices.  A
*  message consists of a "length" byte, followed by three bytes of the Coriandolo
*  Device Identifier, followed by up to 250 bytes of "data".  The value of the
*  "length" byte is the number of bytes in the Device Identifier plus the number
*  bytes of data in the message following the Device Identifier.
*
*  The software for the Coriandolo Radio Protocol sends this message as part of
*  a Radio Packet.  The Radio Packet contains a Preamble, three radio address 
*  bytes, the message (all parts described above) and a two-byte CRC value.
*  The three radio address bytes are controlled by the protocol and are distinct
*  from the three-byte Device Identifier.
*
*  The comments for this code will attempt to distinquish between the "Packet"
*  and the "Message", which is only part of the bytes transmitted/received by
*  the radio.
*
*
*  RADIO FREQUENCIES.
*  The Coriandolo Radio Protocol uses five fixed frequencies in the range of
*  2.400GHz to 2.500GHz.  The protocol controls when a device changes from using
*  one frequency to another.  When a device changes radio frequency it is termed
*  a "hop".  The order of frequency "hopping" is fixed by the protocol.
*  The frequencies used by the protocol are part of the protocol and are part
*  of the FCC testing process.  Changing the radio frequencies used or the order
*  frequency hopping IS A CHANGE TO THE PROTOCOL.
*  
*
*  BUILDING MESSAGES.
*  The application code must properly load the first four bytes of a message.
*  As noted above, the first byte of a message is the length byte; the next 
*  three bytes are the Device Identifier.  The Device Identifier is loaded
*  least-significant byte first.

*  MESSAGES TRANSMITTED BY THE SENSOR vs. MESSAGES TRANSMITTED BY THE BASE.
*  A message transmitted by the SENSOR will always include the Device Identifier 
*  of the SENSOR.  This MUST be the same value as provided to the code when the 
*  protocol is "Enabled".  A message transmitted by the BASE will include the 
*  Device Identifier of the SENSOR to which the message is targeted.  Since the 
*  BASE always transmits in response to receipt of a message from a SENSOR, the
*  target of a BASE message is always to the SENSOR that initiated the message 
*  exchange. Neither a SENSOR nor a BASE can transmit a single message to 
*  multiple devices. (CR Protocol has no multi-cast or broadcast messages.)
*
*
*  SENSOR RADIO COMMUNICATIONS.
*  The SENSOR initiates communications by sending a first message to the BASE.
*  This first message is called an "Announcement".  A SENSOR device transmits 
*  the Announcement by calling "CR_Announce".  The protocol supports two types
*  of Announcements -- a Specified Announcement and a Default Announcement.  A
*  specified Announcement is a "Message" transmitted by the SENSOR as described
*  above.  If the call to "CR_Announce" passes a pointer to a message, this is 
*  transmitted as the Specifiec Announcement.  If the call "CR_Announce" passes
*   a NULL POINTER, the SENSOR Announcement defaults to a minimum message with  
*  a length byte of '3' followed by the SENSOR Device Identifier.  This is 
*  called the "Default Announcement".
*
*  The "Default Announcement" is short to minimize transmit power.  CR Sensors
*  may be in an environment where BASE devices are not always within radio range.
*  In this situation, a significant majority of Announcements will never be
*  received by any BASE device.
*
*  The SENSOR device will transmit an Announcement even if there is no "ready" 
*  buffer for a receive message.  If there is a receive buffer available, the
*  SENSOR device will listen for a response message from a BASE device.  If a
*  response message is received following an Announcement and if the SENSOR
*  device has a message "ready" to transmit, the SENSOR device begins an 
*  Exchange.
*
*  An Exchange is a transmission of a message followed by listening for a 
*  response.  During an Exchange, the SENSOR will transmit a message only if 
*  there is a "ready" receive buffer.  The number of Exchanges is limited.  In
*  most applications, the number of Exchanges will be limited to the number of
*  messages "ready" to transmit and the number of buffers "ready" to receive.
*
*
*  BASE RADIO COMMUNICATIONS.
*  The BASE device begins to "Listen" for a SENSOR announcement by a call to
*  "CR_Listen".  Once started, the BASE device should always listens.  There 
*  is a brief gap when the receiver is disabled and then re-enabled to change 
*  frequencies.  If a BASE device has no "ready" buffers for receive messages,
*  the BASE device will stop listening and the application should take action 
*  to process messages already received or otherwise provide new buffers that 
*  are "ready" to receive messaages.  Listening re-starts with a call again
*  to "CR_Listen".  (If the BASE device is already "listening", a call to
*  "CR_Listen" is ignored with no errors.)
*
*  A BASE device will always respond to a received Announcement.  The response
*  is either a "ready" transmit message or a Default Response Message.
*  During an Exchange, the BASE device will transmit a message or Default 
*  Response, but it will listen for a new SENSOR message only if there is a 
*  "ready" receive buffer.  The BASE device continues the Exchange as long as 
*  it has received a valid message from the specific SENSOR of the Exchange, as 
*  long as the application software has not called "CR_Stop" and as long as the 
*  number of Exchanges has not exceeded the maximum count allowed.  In most 
*  applications, the number of Exchanges will be limited to the number of
*  buffers "ready" to receive, however, because "Listen" is done in the 
*  background, it is possible to remove received messages and process them
*  while the radio protocol is receiving new messages.
*
*
*  INTERRUPTS.
*  The code for both the nRF51 Hardware Radio Module and the nRF51 Hardware RTC 
*  Module (used for Radio Timeouts) use interrupts.  The interrupt priority for
*  these operations are set to the SAME HIGH LEVEL.  Thus these two interrupts 
*  will not "interrupt" each other and should execute in the order in which they 
*  occur.  The interrupt handler of the Radio hardware will disable the current
*  timeout interupt (and may start a new timeout period).  The interrupt handler
*  of the RTC Timeout hardware will "stop" the radio and disable the radio 
*  interrupt.
*/


/** **************************************************************************
*  @def CONFIG_PAYLOAD_LENGTHBYTE_MAX
*  CONFIGURATION CONSTANT FOR PAYLOAD LENGTH BYTE
*
*  This constant limits the number of bytes in a payload that follow the
*  length byte.  This number includes the Device Identifier value.
*  See definition of CONST_DEVICEID_SIZEINMESSAGE in "CR.h".
*/
#define CONFIG_PAYLOAD_LENGTHBYTE_MAX  ( 253u)

#if (CONFIG_PAYLOAD_LENGTHBYTE_MAX > 253)
Error.  Max Payload Length is 253 bytes
#endif


/* ***************************************************************************
*  RADIO PACKET CONSTANT
*/
#define CONST_LENGTHFIELD_INBYTES      (   1u)


/* ***************************************************************************
*  RADIO TIMEOUT CONSTANTS (in nanoseconds)
*  (do not change these constants)
*/
#define CONST_RADIO_LISTENFORANNOUNCE_TIMEOUT_NS ((uint32_t)380200000uL)     
#define CONST_RADIO_LISTENFORADDRESS_TIMEOUT_NS  ((uint32_t)  1700000uL)
#define CONST_RADIO_TX_ADDRESS_TIMEOUT_NS        ((uint32_t)   300000uL)
#define CONST_RADIO_MESSAGE_COMPLETE_TIMEOUT_NS  ((uint32_t)  2100000uL)


/* ***************************************************************************
*  ANNOUNCEMENT TRY CONSTANT
*  -- this is the number of times the Announcement message will transmit.  Each 
*     "try" transmits on a different frequency.
*  (Do not change this value)
*/
#define CONST_ANNOUNCEMENT_TRIES_MAX             (int)5


/* ***************************************************************************
*  ANNOUNCE EXCHANGE MAXIMUM
*  -- this is the maximum number of messages which will be "exchanged". The
*     first message received by a SENSOR unit is not part of this count.
*
*  NOTE: this number sets an upper bound for the maximum number of message 
*        exchanges for a SENSOR.  In practice, the number of messages exchanges
*        will be limited to the number of messages "ready" to transmit and 
*        "ready" receive buffers.  In other words, this constant is usually
*        not the limiting value.
*/
#define CONST_ANNOUNCE_EXCHANGE_MAX              (int)12
   

/* ***************************************************************************
*  LISTEN EXCHANGE MAXIMUM
*  -- this is the maximum number of messages which will be "exchanged". The
*     first message received by a BASE unit is not part of this count.
*
*  NOTE: this number sets an upper bound for the maximum number of message 
*        exchanges for a BASE.  In practice, the number of messages exchanges
*        will be limited to the number of messages "ready" to transmit and 
*        "ready" receive buffers.
*/
#define CONST_LISTEN_EXCHANGE_MAX                (int)12


/* ***************************************************************************
*  DEBUG MACROS
*
*  These are useful macros for setting GPIO pins high at the beginning of Rx
*  or Tx and then low at the end.  The programmer may use a independent pins
*  for Rx and Tx or the same pin.
*
*  Comment out definition of CONFIG_DEBUGPINS_ACTIVE to disable debug macros
*  When disabled, the debug macros will not generate any code.
*/
//#define CONFIG_DEBUGPINS_ACTIVE

// These definitions establish pin numbers for use debug; these are microprocessor
// port-pin numbers not pin numbers of the radio module.
// These are application dependant.
#define CONST_PIN_TESTPOINT_RX          ( 13u)
#define CONST_PIN_TESTPOINT_TX          (  7u)

#ifdef CONFIG_DEBUGPINS_ACTIVE
#include "Drivers/nRF51_GPIO.h"
#define MACRO_DEBUGPINRX_CONFIG         { GPIO_PinConfig_Output( CONST_PIN_TESTPOINT_RX, ePINOUTPUT_ACTIVE, ePINDRIVE_S0S1);}
#define MACRO_DEBUGPINRX_HIGH           { GPIO_Output_Set( CONST_PIN_TESTPOINT_RX);}
#define MACRO_DEBUGPINRX_LOW            { GPIO_Output_Clr( CONST_PIN_TESTPOINT_RX);}
#define MACRO_DEBUGPINTX_CONFIG         { GPIO_PinConfig_Output( CONST_PIN_TESTPOINT_TX, ePINOUTPUT_ACTIVE, ePINDRIVE_S0S1);}
#define MACRO_DEBUGPINTX_HIGH           { GPIO_Output_Set( CONST_PIN_TESTPOINT_TX);}
#define MACRO_DEBUGPINTX_LOW            { GPIO_Output_Clr( CONST_PIN_TESTPOINT_TX);}

#else
#define MACRO_DEBUGPINRX_CONFIG          /* do nothing */
#define MACRO_DEBUGPINRX_HIGH            /* do nothing */
#define MACRO_DEBUGPINRX_LOW             /* do nothing */
#define MACRO_DEBUGPINTX_CONFIG          /* do nothing */
#define MACRO_DEBUGPINTX_HIGH            /* do nothing */
#define MACRO_DEBUGPINTX_LOW             /* do nothing */
#endif


/* ***************************************************************************
*  PRIVATE TYPES
*/
/// @enum crprotocolrun_t
/// @brief
/// "Coriandolo Radio Protocol Run" is an enumerated type that controls the 
///    ability of the protocol to execute an "Exchange" or re-start "Listen".
///    It is intended to be used to gently "stop" the CR protocol.
/// @note
///    NUMERICAL VALUES ARE SUBJECT TO CHANGE
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE
typedef enum
{
   eCRPROTOCOLRUN_STOP = 0,       ///< STOP the protocol at next completed op
   eCRPROTOCOLRUN_GO              ///< Protocol may run
} crprotocolrun_t;


/// @enum crstate_t
/// @brief
/// "Coriandolo Radio Protocol State" is an enumerated type that indicates the
///     the operational status of the radio
/// @note
///    NUMERICAL VALUES ARE SUBJECT TO CHANGE
///    ALWAYS USE THE ENUMERATED CONSTANTS NOT NUMERICAL VALUE
typedef enum
{
   eCRSTATE_ERROR = 0,                 ///< CR State Error occurred
   eCRSTATE_DISABLED,                  ///< CR State is Disabled
   eCRSTATE_IDLE,                      ///< CR State IDLE - powered, configured, not operating
   eCRSTATE_ANNOUNCE_BEGIN,            ///< CR SENSOR beginning Announcement
   eCRSTATE_ANNOUNCE_TX,               ///< CR SENSOR transmitting Announcement
   eCRSTATE_ANNOUNCE_RX,               ///< CR SENSOR Receiving after Announcement
   eCRSTATE_ANNOUNCE_EXCHG_RX,         ///< CR SENSOR Receiving after Announcement Tx Exchange Msg
   eCRSTATE_ANNOUNCE_EXCHG_TX,         ///< CR SENSOR Announcement Exchange Msg Tx
   eCRSTATE_LISTEN_BEGIN,              ///< CR BASE Begin Listen for Annoucement
   eCRSTATE_LISTEN_RX,                 ///< CR BASE Receving Announcement
   eCRSTATE_LISTEN_EXCHG_RX,           ///< CR BASE Receving Exchange Msg from SENSOR
   eCRSTATE_LISTEN_EXCHG_TX,           ///< CR BASE Transmitting Exchange Msg to SENSOR
   eCRSTATE_TEST                       ///< Device is in TEST mode - not operating CR Protocol
} crstate_t;


/// @struct crstateinfo_t
/// @brief
///  "Coriandolo State Information" is a structure type that contains the
//      information used by the protocol state machine
typedef struct
{
   crstate_t  crState;                 ///< CR Device State
   int        announcementTries;       ///< CR SENSOR Announcement Tries
   int        exchangeCount;           ///< CR Device Count of Exchanged Messages
   crbufrinfo_t*   rxInfoPtr;          ///< Pointer to Rx Buffer Info Structure
   crbufrinfo_t*   txInfoPtr;          ///< Pointer to Tx Buffer Info Pointer
   crprotocolrun_t runFlag;            ///< Device Stop/Go Flag
} crstateinfo_t;


/// @typedef rtcptr_t
/// @brief
/// Used as a pointer type to an RTC module
typedef NRF_RTC_Type*  rtcptr_t;



/* ***************************************************************************
*  PRIVATE VOLATILE VARIABLES
*
*  These static variables are declared 'volatile' because they may be modified
*  within interrupts.  By declaring these variable 'volatile', the code should 
*  always read a new value from memory and not cache or store the variable in 
*  a register.
*/
static volatile uint32_t       s_radioAddressTimestamp;
static volatile crstateinfo_t  s_myStateInfo;

// This structure is used to capture a "Time Stamp"
static struct
{
   volatile uint32_t*  captureTaskPtr;
   volatile const uint32_t* captureRegPtr;
} s_myTicksCntrInfo;



/* ***************************************************************************
*  PRIVATE VARIABLES
*/
static deviceinfo_t   s_myDeviceInfo;
static crhwtimer_t    s_myCrHwTimer;
static bool           s_discardDefaultMsg;

// Statics for Sensor Announcement Message
static crbufrinfo_t  s_announcementInfo;
static uint8_t       s_announceDefaultMsg[ (CONST_DEVICEID_SIZEINMESSAGE + 1)];

// Statics for Base Default Response Message
crbufrinfo_t   s_defaultResponseInfo;
uint8_t        s_defaultResponseMsg[ (CONST_DEVICEID_SIZEINMESSAGE + 1)];

// Static related to timing
/// Structure 's_timeoutValuesInTicks' contains calculated values for radio 
/// timeouts.  These values are set by "CR_TimeoutValues_Calc".
static struct
{
   uint32_t  radioListenFor1stMsgTimeout;   ///< timeout radio listening for first message
   uint32_t  radioListenForAddressTimeout;  ///< timeout radio listening for address received
   uint32_t  radioTxAddressTimeout;         ///< timeout radio transmitter start to address transmit
   uint32_t  radioMessageCompleteTimeout;   ///< timeout radio message rx/tx complete after address
} s_timeoutValuesInTicks;

// Statics related to Frequency-hopping
/// 's_hopFreqIndex' is the index value for the frequency hoping table.
static uint32_t        s_hopFreqIndx;
/// 's_hopFreqTable' is the list of hopping frequencies for Corriandolo Radio.
/// @warning
/// Changing the values in 's_hopFreqTable' is a change to the protocol.
const static uint32_t  s_hopFreqTable[] = {2472uL, 
                                           2402uL, 
                                           2422uL, 
                                           2446uL, 
                                           2480uL};

// 's_alwaysZero' a 32-bit value that is always zero.
//    Certain pointers are set to point to this variable so they always have 
//    a valid pointer address that derefeernces to a known value.
static const uint32_t  s_alwaysZero = 0uL;

// 's_taskDoNothing'
// This may be used as a subsitute "Task" variable for Ticks Capture if no
//   hardware "task" register is needed.  In which case, writing a '1' to
//   's_taskDoNothing' does nothing.
//   This is NOT a pointer to a procedure.
//   Refer to ARM processor documentation of "Task" registers.
static uint32_t s_taskDoNothing;


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE CORIANDOLO RADIO PROTOCOL EVENTS
*/
static void  CR_ProtocolEvent_Disable( void);
static void  CR_ProtocolEvent_Enable( void);
static void  CR_ProtocolEvent_RadioPktEnd( void);
static void  CR_ProtocolEvent_Timeout( void);


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE CORIANDOLO RADIO PROTOCOL STARTS, STEPS, WRAPUPS
*/
static void  CR_ProtocolStart_Announce( void);
static void  CR_ProtocolStart_Listen( void);

static void  CR_ProtocolStep_AnnounceRcvd( void);
static void  CR_ProtocolStep_AnnounceRcvdExchng( void);
static void  CR_ProtocolStep_AnnounceTxBegin( void);
static void  CR_ProtocolStep_AnnounceTxEnd( void);
static void  CR_ProtocolStep_ExchangeTxEnd( crstate_t nextState);
static void  CR_ProtocolStep_ListenRcvd( void);
static void  CR_ProtocolStep_ListenRcvdExchng( void);

static void  CR_ProtocolWrapUp_Announce( void);
static void  CR_ProtocolWrapUp_Listen( void);


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE CORIANDOLO RADIO EVENTS
*
*  These occur during reception or transmission of radio packets.
*  They format for these procedures must correspond to type 'callback_t'
*/
static void  CR_RadioEvent_PacketBegin( void* radioStatusPtr);
static void  CR_RadioEvent_PacketEnd( void* radioStatusPtr);


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE PROTOCOL SUPPORT FUNCTIONS/PROCEDURES
*/
static          void    CR_AnnouncementDefault_Build( uint8_t* msgBufr, 
                                                      const uint32_t deviceId);
static          void    CR_AnnouncementInfo_Load( uint8_t* announcementMsgPtr);
static  crbufrinfo_t*   CR_BaseResponseMsgInfo_GetPtr( const uint32_t sensorId);
static    crstatus_t    CR_ConvertStateToStatus( const crstate_t crState);
static          void    CR_DefaultResponseMsg_Build( uint8_t* msgBufr, 
                                                     const uint32_t deviceId);
static __INLINE void    CR_ExchangeStatus_Set( crbufrinfo_t* txInfoPtr,
                                               const crbufrstatus_t rxStatus);
static __INLINE bool    CR_IsDefaultResponseMsg( uint8_t msgBufr[]);
static          bool    CR_MyCounterInfo_Set( const crcntrinfo_t* crCntrInfo);
static          bool    CR_MyDeviceInfo_Set( const deviceinfo_t* deviceInfoPtr);
static          void    CR_ProtocolBufrs_Init( void);
static          void    CR_RadioAddresses_Set( const crtype_t crDeviceType,
                                               const uint16_t radioConnection);
static __INLINE void    CR_RadioChannel_HopToNext( void);
static void             CR_RxEnableStart( crbufrinfo_t* rxInfoPtr, 
                                          const uint32_t timeout);
static crbufrstatus_t   CR_RxMessage_CheckCRC( crbufrinfo_t* rxInfoPtr);
static crbufrstatus_t   CR_RxMessage_Process( crbufrinfo_t* rxInfoPtr,
                                               const uint32_t matchDeviceId);
static          bool    CR_RxMessage_RemoveDefaultMsg( crbufrinfo_t* rxInfoPtr);
static __INLINE void    CR_TxFlags_Handle( crbufrinfo_t* txInfoPtr,
                                            const uint32_t timeValue);
static          void    CR_TxMessage_ProcessSent( crbufrinfo_t* txInfoPtr);
static          void    CR_TxMessage_Start( crbufrinfo_t* txInfoPtr, 
                                            const uint32_t timeout);


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE TIME SUPPORT FUNCTIONS
*/
static __INLINE uint32_t  CR_Ticks_Calc( uint32_t nanoSec, uint32_t nanoSecPerTick);
static          void      CR_TicksCapture_Init( crtickscntr_t crTicksCntrSelect);
static __INLINE uint32_t  CR_TicksCapture_Now( void);
static          bool      CR_TimeoutCntr_IsLegal( const crhwtimer_t crTimerSelect);
static          void      CR_TimeoutCntr_Stop( const crhwtimer_t crTimerSelect);
static          void      CR_TimeoutCntr_Start( const crhwtimer_t crTimerSelect);
static          void      CR_TimeoutValues_Calc( uint32_t nanosecondsPerTick);


/* ***************************************************************************
*  PROTOTYPES FOR PRIVATE RTC HARDWARE DRIVERS
*/
static __INLINE rtcptr_t    NRF51_RTC_GetPtr( const crhwtimer_t crTimerSelect);
static __INLINE     void    NRF51_RTC_Interrupt_Disable( const crhwtimer_t crTimerSelect);
static __INLINE     void    NRF51_RTC_Interrupt_Enable( const crhwtimer_t crTimerSelect);
static __INLINE     void    NRF51_RTC_InterruptPending_Clr( const crhwtimer_t crTimerSelect);
static __INLINE     void    NRF51_RTC_ClrRadioTimeout( const crhwtimer_t crTimerSelect);
static __INLINE     void    NRF51_RTC_SetRadioTimeout( const crhwtimer_t crTimerSelect,
                                                       const uint32_t  timeoutValue);
static              void    NRF51_RTC_Start( const crhwtimer_t crTimerSelect);
static              void    NRF51_RTC_Stop( const crhwtimer_t crTimerSelect);



/*  **************************************************************************/
/** ***************************************************************************
*  MODULE INITIALIZATION PROCEDURE
*
*  -- All modules must have a "..._Init" procedure to initialize static 
*  variables to known values.
*  @returns   void
*/
void CR_Init( void)
{
   // Initialize static variables to "safe" values
   //   's_myTicksCntrPtr' is initially set to point to 's_alwaysZero' to make
   //   sure it always has a valid address.  It is over-written in "CR_Enable"
   s_hopFreqIndx = 0uL;
   s_myDeviceInfo.deviceID = 0uL;
   s_myDeviceInfo.deviceType = eCRTYPE_ERROR;
   s_myCrHwTimer = eCRHWTIMER_ERROR;
   s_myTicksCntrInfo.captureTaskPtr = &s_taskDoNothing;
   s_myTicksCntrInfo.captureRegPtr = &s_alwaysZero;
   // The Coriandolo Radio Protocol State is an error unitl a call to 
   // either "CR_Disable" or "CR_Enable"
   s_myStateInfo.crState = eCRSTATE_ERROR;
   s_myStateInfo.announcementTries = 0;
   s_myStateInfo.exchangeCount = 0;
   s_myStateInfo.rxInfoPtr = CONST_NULLPTR;
   s_myStateInfo.txInfoPtr = CONST_NULLPTR;
   s_myStateInfo.runFlag = eCRPROTOCOLRUN_STOP;
   // Configure DEBUG I/O
   MACRO_DEBUGPINRX_CONFIG;
   MACRO_DEBUGPINTX_CONFIG;
   return;
}


/* ***************************************************************************/
/* ***************************************************************************
*  PUBLIC PROCEDURES for CR OPERATIONS -- in alphabetical order
*/

/** ***************************************************************************
*  CORIANDOLO RADIO ANNOUNCE
*
*  Starts a Coriandolo Radio Announcement.
*  @returns     void
*  @param[in]   announcementMsgPtr - pointer to bytes of a message for 
*                                    Announcement; this may be a NULL POINTER
*
*  The SENSOR communicates with the BASE using a process that consists of two 
*  phases -- the Announcement and the Announcement Exchange.
*
*  "CR_Announce" is called with one parameter - a pointer to message, which
*  is used as the "Announcement".  If the pointer is a NULL POINTER, the device 
*  will transmit a "Default Announcement"
*
*  During the Announcement phase, the "Announcement" is transmitted, then the 
*  radio listens for a response message.  If no message is received, a radio 
*  "channel hop" is performed and the process is repeated.  The "Announcement" 
*  may be transmitted up to 5 times on different radio channels.  If while 
*  listening, a response message is received, the Announcement phase ends and 
*  the Exchange phase begins.
*
*  In the Exchange phase, the radio tranmsits a message from the buffer and 
*  listens for responding message.  If a message is received, the process 
*  repeats; otherwise the Exchange phase terminates.  While in the Exchange 
*  phase, the radio remains on a single channel.  Because the number of messages
*  in the Buffer Information Structure Array is limited, the number of "exchanges" 
*  in the Exchange phase is limited.
*
*  @note
*  SHOULD BE CALLED ONLY FOR CR_TYPE SENSOR -- but this is not checked.
*
*  @note
*  A call to this procedure will be ignored if the device is not IDLE.
*  The application should check that the Coriandolo Radio Status is 
*  eCR_STATUS_IDLE before calling this procedure.
*
*  @note
*  The application should also check the status after the call for an ERROR 
*  value.
*/
void  CR_Announce( uint8_t* announcementMsgPtr)
{
   if( s_myDeviceInfo.deviceType == eCRTYPE_SENSOR)
   {
      // *** CRITICAL SECTION BEGIN ***
      // Atomic conditional change of state so code is thread-safe in multi-tasking
      // Disable interrupts by setting PRIMASK
      __set_PRIMASK( 1);
      if( s_myStateInfo.crState == eCRSTATE_IDLE)
      {
         s_myStateInfo.crState = eCRSTATE_ANNOUNCE_BEGIN;
      }
      // Enable interrupt by clearing PRIMASK
      __set_PRIMASK( 0);   
      // *** CRITICAL SECTION END ***
      //
      // Start CR Protocol
      CR_AnnouncementInfo_Load( announcementMsgPtr);
      CR_ProtocolStart_Announce();
      // Code may return while radio is active
   }
   // done
   return;
}


/** ***************************************************************************
*  CORIANDOLO RADIO DISABLE
*
*  Disables the Coriandolo Radio Protocol.
*  @returns   void
*
*  This procedure stops any radio activity and disables the radio hardware.
*/
void  CR_Disable( void)
{
   // Invoke a "Disable" CR Protocol Event
   CR_ProtocolEvent_Disable();
   return;
}

/** ***************************************************************************
*  CORIANDOLO RADIO ENABLE
*
*  Enables the Coriandolo Radio Protocol and Radio Hardware.
*  @returns    Status of the CR Protocol - a value of type 'crstatus_t'
*  @param[in]  deviceInfoPtr - pointer to structure that describes Device Info
*  @param[in]  crCntrInfoPtr - pointer to structure that specifies Counter usage
*  
*
*  Initializes the static information needed for the CR Protcol.
*  CLEARS all information about Received and Transmitted messages
*  (including a re-initialization of all message buffer statics).
*  Sets the proper configuration of the radio hardware.
*
*  @note
*  The contents of the Device Information structure and the CrCounter Information
*  structure should be set carefully for proper operation of the CR Protocol.
*  The values are "loaded" by this function and are not changed until the next 
*  call.
*/
crstatus_t  CR_Enable( const deviceinfo_t*  deviceInfoPtr,
                       const crcntrinfo_t*  crCntrInfoPtr) 
{
   crstatus_t  crStatus;
   bool  valuesOK;
   CR_Init();
   // Set Device Information and Counter Information
   valuesOK = CR_MyDeviceInfo_Set( deviceInfoPtr);
   if( valuesOK == true)
   {
      valuesOK = CR_MyCounterInfo_Set( crCntrInfoPtr);
   }
   // If values are OK, then "enable" protocol
   if( valuesOK == true)
   {
      // Passed parameters are valid
      // Configure Radio HW and Enable the Interrupt Callbacks
      Callback_Init();
      RadioHw_Init();
      RadioHw_Config();
      RadioHw_Callbacks_Set( CR_RadioEvent_PacketBegin, CR_RadioEvent_PacketEnd);
      // Initialize the radio addresses to be used
      CR_RadioAddresses_Set( deviceInfoPtr->deviceType, deviceInfoPtr->connectionValue);
      CR_TimeoutCntr_Start( s_myCrHwTimer);
      CR_ProtocolEvent_Enable();
   }
   else
   {
      // An error occurred during enable
      // Force a radio disable
      CR_ProtocolEvent_Disable();
   }
   // Get status - do not wait = 'false'
   crStatus = CR_Status_Get();
   return crStatus;
}


/** ***************************************************************************
*  CORIANDOLO RADIO LISTEN
*
*  This is the procedure that is called by an Application on a BASE device to
*  to start the Coriandolo Radio Protocol radio communications.
*  @returns    void
*
*  The LISTEN process consists of two phases -- the Monitor Phase and the 
*  Exchange Phase.
*
*  The LISTEN procedure performs a radio channel "hop" then MONITORS one radio
*  frequency listening for an incoming message from a SENSOR.  If no message is
*  received before a "timeout" occurs, Coriandolo Radio performs a radio
*  channel "hop" then MONITORS the next radio frequency for an incoming message
*  for a SENSOR.  If a message is received (any good radio packet) an EXCHANGE
*  is started.  In the EXCHANGE phase, the device sends only messages ready to 
*  transmit that have "matching" Device Identifiers or a "Default Response 
*  Message".  The Default Response Message is transmitted only if there is no 
*  message with a matching Device ID in the transimit buffer ready to transmit.
*  BECAUSE OF THE DEFAULT RESPONSE MESSAGE, A CORIANDOLO BASE DEVICE WILL ALWAYS
*  SEND A RESPONSE TO A RECEIVED MESSAGE FROM A SENSOR DEVICE.
*
*  @note
*  SHOULD BE CALLED ONLY FOR CR_TYPE BASE -- but this is not checked.
*
*  @note
*  A call to this procedure will be ignored if the device is not IDLE.
*
*  @note
*  The Default Response Message simply is a message containing only a Device
*  Identifier.  A "default" version is created during "enable".  So it does not 
*  need to be "loaded" here.
*
*  @note
*  IMPORTANT NOTE: The application should check the status after the call
*                  for an ERROR or IDLE value.
*/
void  CR_Listen( void)
{
   if( s_myDeviceInfo.deviceType == eCRTYPE_BASE)
   {
      // *** CRITICAL SECTION BEGIN ***
      // Atomic conditional change of state so code is thread-safe in multi-tasking
      // Disable interrupts by setting PRIMASK
      __set_PRIMASK( 1);
      if( s_myStateInfo.crState == eCRSTATE_IDLE)
      {
         s_myStateInfo.crState = eCRSTATE_LISTEN_BEGIN;
      }
      // Enable interrupt by clearing PRIMASK
      __set_PRIMASK( 0);   
      // *** CRITICAL SECTION END ***
      //
      // Start CR Protocol
      CR_ProtocolStart_Listen();
      // Code may return while radio is active
   }
   // done
   return;
}


/** ***************************************************************************
*  CORIANDOLO RADIO STATUS GET
*
*  Returns the status of the Coriandolo Radio Protocol.
*  @returns    crStatus -- Status of the CR Protocol.
*
*  The CR protocol status is an enumerated constant calculated from the "state"
*  of the protocol.
*/
crstatus_t  CR_Status_Get( void)
{
   crstatus_t  crStatus;
   // Get status and return
   crStatus = CR_ConvertStateToStatus( s_myStateInfo.crState);
   return crStatus;
}


/** ***************************************************************************
*  CORIANDOLO RADIO STOP
*
*  Performs a "Gentle" stop of the Radio Protocol.
*  @returns    void
*
*  Sets internal state variables to cause the protocol to cease execution then
*  waits for execution to stop.
*  This code will Stop the protocol almost immediately, if the BASE device is
*  "Listening" otherwise, the protcol waits until a BASE or SENSOR exchange is 
*  complete.
*/
void  CR_Stop( void)
{
   // Change the status of the "Protocol Run Flag" to STOP
   //    this should be an atomic operation   
   s_myStateInfo.runFlag = eCRPROTOCOLRUN_STOP;
   //
   // *** CRITICAL SECTION BEGIN ***
   // Atomic conditional change of state so code is thread-safe in multi-tasking
   // Disable interrupts by setting PRIMASK
   __set_PRIMASK( 1);
   if( (s_myStateInfo.crState == eCRSTATE_LISTEN_BEGIN) ||
       (s_myStateInfo.crState == eCRSTATE_LISTEN_RX)   )
   {
      // Radio is just "listening"
      // Stop the timeout timer, "Stop" the radio operation
      CR_TimeoutCntr_Stop( s_myCrHwTimer);
      (void)RadioHw_ForceIdle();
   }
   else
   {
      // Protocol is actively in Announcement or in an Exchange
      // Do nothing
   }
   // Enable interrupt by clearing PRIMASK
   __set_PRIMASK( 0);   
   // *** CRITICAL SECTION END ***
   //
   // Wait for Radio Stop to complete before returning
   (void)RadioHw_WaitForIdle();
   s_myStateInfo.crState = eCRSTATE_IDLE;
   return;
 }


 /** ***************************************************************************
*  CORIANDOLO RADIO ADD RECEIVE MESSAGE BUFFER
*
*  Adds a buffer that will be used to contain a received message to the 
*  Receive array of  Buffer Information.
*  @returns   boolean 'true' if no error occurred.
*  @param[in]  rxBufr - pointer to memory for receiving a message
*  @param[in]  rxBufrSize - number of bytes in memory pointed to by 'rxBufr'
*
*  @warning
*  This code is not safe for mulit-threaded environments.
*  Multi-threaded application code should inhibit "task-switching" when calling.
*/
bool  CR_AddRxBufr( uint8_t* rxBufr, const uint8_t rxBufrSize)
{
   crbufrinfo_t*   crBufrInfoPtr;
   crbufrstatus_t  status;
   bool  isSuccess;
   crBufrInfoPtr = CrBufr_Rx_FindUnused();
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      // Found unused buffer slot
      // "Add" the buffer to the Rx Info structure
      status = CrBufr_LoadRxBufrInfo( crBufrInfoPtr, rxBufr, rxBufrSize, eCRRXFLAGS_NONE);
   }
   else
   {
      status = eCRBUFRSTATUS_ERROR;
   }
   // Set return value
   if( status == eCRBUFRSTATUS_RXREADY)
   {
      isSuccess = true;
   }
   else
   {
      isSuccess = false;
   }
   return isSuccess;
}


/** ***************************************************************************
*  CORIANDOLO RADIO ADD TRANSMIT MESSAGE
*
*  Adds a transmit message (with a message size byte, DeviceId and payload) to 
*  the Transmit array of  Buffer Information.
*  @returns   boolean 'true' if no error occurred.
*  @param[in]  txMsg - pointer to bytes of transmit message
*  @param[in]  txFlags - flags enumerated constant) associated with tx message
*  @param[in]  mode  - value of enumerated type 'addmsgmode_t' that determines
*                      the "mode" for adding the message into Transmit array of 
*                      Buffer Information
*
*  This code adds a message into the array of messages to be transmitted if an  
*  UNUSED slot is found.  Added messages are given a "sequence number" to ensure
*  that messages "added" earlier are given priority to transmit.
*  If no UNUSED slot is found AND 'mode' is eADDMSGMODE_FORCE, the CR Protocol 
*  will remove a message from the array of transmit and place this message in 
*  that slot.
*
*  @warning
*  Application code should not modify a transmit message once it has been  
*  "added" until it is removed.
*
*  @warning
*  This code is not safe for mulit-threaded environments.
*  Multi-threaded application code should inhibit "task-switching" when calling.
*/
bool  CR_AddTxMsg( uint8_t* txMsg, const crtxflags_t txFlags, 
                                   const addmsgmode_t mode)
{
   crbufrinfo_t*   crBufrInfoPtr;
   crbufrstatus_t  status;
   uint32_t        deviceIdValue;
   unsigned int    txLength;
   bool            isSuccess;
   // Find UNUSED place to put new tx message
   crBufrInfoPtr = CrBufr_Tx_FindUnused();
   // If no UNSED Buffer available, 'txMsg' is real and 'forceAdd' is true
   if( (crBufrInfoPtr == CONST_NULLPTR) && 
       (mode == eADDMSGMODE_FORCE) &&
       (txMsg != CONST_NULLPTR)  )
   { 
      // Find oldest buffer ready to transmit and remove it
      //   "CrBufr_BufrInfo_SetUnused" can handle NULL POINTER if necessary.
      crBufrInfoPtr = CrBufr_Tx_FindNextTxReady( CONST_DEVICEID_ALWAYS_MATCH);
      CrBufr_BufrInfo_SetUnused( crBufrInfoPtr);
      // 'crBufrInfoPtr' now points to UNUSED info structure
   }
   if( (crBufrInfoPtr != CONST_NULLPTR) && 
       (mode != eADDMSGMODE_ERROR) &&
       (txMsg != CONST_NULLPTR) )
   {
      // Found unused buffer slot
      // Get 'txLength' from the first byte of the message
      txLength = (unsigned int)*txMsg;
      if( txLength <= CONFIG_PAYLOAD_LENGTHBYTE_MAX)
      {
         // The total length is 1 more than this first byte
         txLength += 1u;      
         // Get the Device Identifier value from 'txMsg'.
         // -- it starts at the second byte
         CrDeviceId_GetBytes( &deviceIdValue, (txMsg+1));
         // "Add" the buffer to the Tx Info structure
         status = CrBufr_LoadTxBufrInfo( crBufrInfoPtr, 
                                         txMsg, 
                                         (uint8_t)txLength,
                                         txFlags, 
                                         deviceIdValue);
         // load complete
      }
      else
      {
         // tx payload size is bad
         status = eCRBUFRSTATUS_ERROR;
      }
   }
   else
   {
      // no "unused" buffer available or bad parameter
      status = eCRBUFRSTATUS_ERROR;
   }
   // Set return value
   if( status == eCRBUFRSTATUS_TXREADY)
   {
      isSuccess = true;
   }
   else
   {
      isSuccess = false;
   }
   return isSuccess;
}


/** ***************************************************************************
*  CORIANDOLO RADIO GET RECEIVE MESSAGE
*
*  Returns a pointer to a RECEIVED message that has a matching Device Identifier
*  to 'matchDeviceId'.
*  @returns     pointer to bytes of a "received message" with matching Device
*               Identifier.
*  @param[in]   matchDeviceId - filter messages to be returned by matching
*                               Device Indentifier 
*  @param[out]  tickValuePtr - pointer to 32-bit memory to return "Ticks Value" 
*                              of message; may be NULL POINTER
*
*  The caller may pass a value of 'matchDeviceId' of CONST_DEVICEID_ALWAYS_MATCH
*  to allow messages with any Device Identifier to match.
*
*  If no "received" message in the Coriandolo Information structure has a 
*  matching Device Identifier, a value equal to CONST_NULLPTR is returned.
*
*  If the value returned by the function is not equal-to CONST_NULLPTR and 
*  the passed pointer 'tickValuePtr' also is not equal-to CONST_NULLPTR, then
*  '*tickValuePtr' is set to the "Tick Value" related to the beginning of the  
*  message as received.
*
*  The size of the received message is in the first byte of the received message
*  (the size does not include the first byte); the Device Id of the received 
*  message is in the next bytes of the message.
*
*  Except for CONST_NULLPTR, the return value of the function call will equal 
*  one of the receive buffers that was a parameter of "CR_AddRxBufr". 
*/
uint8_t*  CR_GetRxMsg( uint32_t  matchDeviceId, uint32_t*  tickValuePtr)
{
   crbufrinfo_t*   crBufrInfoPtr;
   uint8_t*  msgPtr;
   crBufrInfoPtr = CrBufr_Rx_FindNextRxRcvd( matchDeviceId);
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      // Return pointer to "Rx Msg"
      msgPtr = CrBufr_BufrInfo_GetMsgPtr( crBufrInfoPtr);
      // Check if "Tick Value" should be copied
      if( tickValuePtr != CONST_NULLPTR) 
      {
         // Copy the received Tick Value, to the pointed location
         *tickValuePtr = CrBufr_BufrInfo_GetTickValue( crBufrInfoPtr);
      }
   }
   else
   {
      // No Buffer with an appropriate message was found
      // The return value is CONST_NULLPTR; '*tickValuePtr' is not modified
      msgPtr = CONST_NULLPTR;
   }
   // done
   return msgPtr;
}


/** ***************************************************************************
*  CORIANDOLO RADIO GET TRANMITED MESSAGE
*
*  Returns a pointer to a tranmit message, which has been SENT.
*  @returns     pointer to bytes of a "transmitted message".
*  @param[in]   matchDeviceId - filter messages to be returned by matching
*                               Device Indentifier
*  @param[out]  tickValuePtr - pointer to 32-bit memory to return "Ticks Value" 
*                              of message; may be NULL POINTER
*  @param[out]  exchangeStatusPtr - pointer to memory to return "Exchange Status" 
*                                   of message; may be NULL POINTER
*
*  The caller may pass a value of 'matchDeviceId' of CONST_DEVICEID_ALWAYS_MATCH
*  to allow messages with any Device Identifier to match.
*
*  Transmit messages that are ready to be sent, but have not been sent will 
*  not be returned.  The returned message must have that has a matching Device
*  Identifier to 'matchDeviceId'.  If no "transmitted" message in the Coriandolo
*  Information structure has a matching Device Identifier, a value equal to 
*  CONST_NULLPTR is returned.
*
*  If the value returned by the function is not equal-to CONST_NULLPTR and 
*  the passed pointer 'tickValuePtr' also is not equal-to CONST_NULLPTR, then
*  '*tickValuePtr' is set to the "Tick Value" related to the beginning of the  
*  message when transmitted.
*
*  If the value returned by the function is not equal-to CONST_NULLPTR and 
*  the passed pointer 'exchangeStatusPtr' also is not equal-to CONST_NULLPTR, 
*  then '*exchangeStatusPtr' is set to the "Exchange Status" (one of the 
*  enumerated constants) of the message.
*/
uint8_t*  CR_GetTxMsg( uint32_t  matchDeviceId, 
                       uint32_t*  tickValuePtr, 
                       exchangestatus_t* exchangeStatusPtr)
{
   crbufrinfo_t*   crBufrInfoPtr;
   uint8_t*  msgPtr;
   crBufrInfoPtr = CrBufr_Tx_FindNextTxSent( matchDeviceId);
   if( crBufrInfoPtr != CONST_NULLPTR)
   {
      // Return pointer to "Tx Msg"
      msgPtr = CrBufr_BufrInfo_GetMsgPtr( crBufrInfoPtr);
      // Check if "Tick Value" should be copied
      if( tickValuePtr != CONST_NULLPTR) 
      {
         // Copy the received Tick Value, to the pointed location
         *tickValuePtr = CrBufr_BufrInfo_GetTickValue( crBufrInfoPtr);
      }
      if( exchangeStatusPtr != CONST_NULLPTR)
      {
         // Copy the "Exchange Status Value"
         *exchangeStatusPtr = CrBufr_BufrInfo_GetStatusExchange( crBufrInfoPtr);
      }
   }
   else
   {
      // No transmit message; the return value is CONST_NULLPTR; 
      // '*tickValuePtr' is not modified
      // '*exchangeStatusPtr' is not modified
      msgPtr = CONST_NULLPTR;
   }
   // done
   return msgPtr;
}


/** ***************************************************************************
*  CORIANDOLO RADIO GET TRANSMIT MESSAGE INFORMATION
*
*  This procedure will return the "Ticks Value" and the "Exchange Status" for
*  a Tranmsit message.
*  @returns    void
*  @param[in]  txMsgPtr - pointer to transmit message for which info is requested 
*                         (used as identifier)
*  @param[out] tickValuePtr - pointer to 32-bit memory to return "Ticks Value" 
*                             of message; may be NULL POINTER
*  @param[out] exchangeStatusPtr - pointer to memory to return "Exchange Status" 
*                                  of message; may be NULL POINTER
*
*  The procedure is passed 'txMsgPtr', which is used to match the message pointer
*  in one of the transmit information buffers.  This procedure also may be called
*  to get information about the last Specific Announcement message (not a default
*  announcement).  The 'txMsgPtr' may point to a message that is ready to transmit
*  or one that has been transmitted.  Ticks Value will not be set if 
*  'ticksValuePtr' is NULL POINTER; Exchange Status will not be set if 
*  'exchangeStatusPtr' is NULL POINTER
*
*  @note
*  The information is available only for the message pointer passed to the most
*  recent call to "CR_Announce".  Information related to a "Default Announcement"
*  can not be returned by this procedure.
*/
void  CR_GetTxMsgInfo( const uint8_t* txMsgPtr,
                       uint32_t* tickValuePtr, 
                       exchangestatus_t* exchangeStatusPtr)
{
   crbufrinfo_t*  txBufrPtr;
   uint8_t* lastAnnounceMsg;
   // Check if 'txMsgPtr' is the last Announcement message
   lastAnnounceMsg = CrBufr_BufrInfo_GetMsgPtr( &s_announcementInfo);
   if( txMsgPtr == lastAnnounceMsg)
   {
      // The desired buffer is 's_announcementInfo'
      txBufrPtr = &s_announcementInfo;
   }
   else
   {
      // Search the Transmit Information Array for a match
      txBufrPtr = CrBufr_Tx_FindMatchingBufr( txMsgPtr);
   }
   // Check if buffer ptr was found
   if( txBufrPtr != CONST_NULLPTR)
   {
      // Copy found info
      // Set "Ticks Value" if pointer is not NULL POINTER
      if( tickValuePtr != CONST_NULLPTR)
      {
         *tickValuePtr = CrBufr_BufrInfo_GetTickValue( &s_announcementInfo);
      }
      // Set "Exchange Status" if pointer is not NULL POINTER
      if( exchangeStatusPtr != CONST_NULLPTR)
      {
         *exchangeStatusPtr = CrBufr_BufrInfo_GetStatusExchange( &s_announcementInfo);
      }
   }
   // done
   return;
}


/** ***************************************************************************
*  CR REMOVE RECEIVE BUFFER
*
*  Removes the buffer "pointed to" by 'rxBufrPtr' from the Receive Buffer 
*  Information structure.
*  @returns     boolean 'true' if message found and removed
*  @param[in]   rxBufrPtr - pointer to recieve buffer that was "added" by call
*                           to "CR_AddRxBufr" (used as identifier)
*
*  @note
*  Code has been added to make this function safe for multi-threaded applications
*/
bool  CR_RemoveRxBufr( const uint8_t* rxBufrPtr)
{
   crbufrinfo_t*  rxBufrInfoPtr;
   crbufrstatus_t  rxBufrStatus;
   bool  isSuccess;
   // Find the Buffer Information Structure that uses 'rxBufrPtr'
   rxBufrInfoPtr = CrBufr_Rx_FindMatchingBufr( rxBufrPtr);
   //
   // *** CRITICAL SECTION BEGIN ***
   // Atomic conditional change of status to prevent interrupt-based problems
   // Disable interrupts by setting PRIMASK
   __set_PRIMASK( 1);
   // Set buffer information to UNUSED if buffer status is NOT "Rx Busy"
   //   and NOT "Null"
   //   "CrBufr_BufrInfo_GetStatus" can accept a NULL POINTER
   rxBufrStatus = CrBufr_BufrInfo_GetStatus( rxBufrInfoPtr);
   if( (rxBufrStatus != eCRBUFRSTATUS_NULL) &&
       (rxBufrStatus != eCRBUFRSTATUS_RXBUSY)  )
   {
      // Set Buffer Information to Unused
      // NOTE: 'rxBufrPtr' can not be NULL POINTER because status is not NULL
      CrBufr_BufrInfo_SetUnused( rxBufrInfoPtr);
      isSuccess = true;
   }
   else
   {
      isSuccess = false;
   }
   // Enable interrupt by clearing PRIMASK
   __set_PRIMASK( 0);   
   // *** CRITICAL SECTION END ***
   //
   return isSuccess;
}


/** ***************************************************************************
*  CR REMOVE TRANSMIT MESSAGE
*
*  Removes the message "pointed to" by 'txMsgPtr' from the Transmit Buffer 
*  Information structure.
*  @returns     boolean 'true' if message found and removed
*  @param[in]   txMsgPtr - pointer to bytes of transmitted message that was 
*                          "added" by call to "CR_AddTxMsg" ((used as identifier)
*
*  @note
*  Code has been added to make this function safe for multi-threaded applications
*/
bool  CR_RemoveTxMsg( const uint8_t* txMsgPtr)
{
   crbufrinfo_t*  txBufrInfoPtr;
   crbufrstatus_t  txBufrStatus;
   bool  isSuccess;
   // Find the Buffer Information Structure that uses 'txMsgPtr'
   txBufrInfoPtr = CrBufr_Tx_FindMatchingBufr( txMsgPtr);
   //
   // *** CRITICAL SECTION BEGIN ***
   // Atomic conditional change of status to prevent interrupt-based problems
   // Disable interrupts by setting PRIMASK
   __set_PRIMASK( 1);
   // Set buffer information to UNUSED if buffer status is NOT "Tx Busy" and 
   //    NOT "Null"
   //    "CrBufr_BufrInfo_GetStatus" can accept a NULL POINTER
   txBufrStatus = CrBufr_BufrInfo_GetStatus( txBufrInfoPtr);
   if( (txBufrStatus != eCRBUFRSTATUS_NULL) &&
       (txBufrStatus != eCRBUFRSTATUS_TXBUSY)  )
   {
      // Set Buffer Information to Unused
      // NOTE: 'txBufrPtr' can not be NULL POINTER because status is not NULL
      CrBufr_BufrInfo_SetUnused( txBufrInfoPtr);
      isSuccess = true;
   }
   else
   {
      isSuccess = false;
   }
   // Enable interrupt by clearing PRIMASK
   __set_PRIMASK( 0);   
   // *** CRITICAL SECTION END ***
   //
   return isSuccess;
}


/* ***************************************************************************/
/* ***************************************************************************
*  PUBLIC PROCEDURE for CR TESTING
*/

/** ***************************************************************************
*  CORIANDOLO RADIO TEST TRANSMIT CONSTANT CARRIER
*
*  Causes the radio device to transmit a "carrier" signal.
*  It is made available for TESTING-ONLY.
*  @returns    void
*  @param[in]  freqMHz - frequency of transmission in MHz.
*
*  This procedure will enable the device to transmit a carrier signal indefinately
*  on a fixed frequency.  Transmission ends with a call to "CR_Disable" or 
*  disconnecting power.
*
*  @note
*  The timeout timer should not be running.  It can cause unexpected results.
*  If it the timeout timer might have been enabled, the application should 
*  call "CR_Disable" prior to calling this procedure.
*
*  @warning
*  THIS ACTIVITY IS INCOMPATABLE WITH OTHER ACTIVITIES OF THE CORIANDOLO RADIO 
*  PROTOCOL.
*/
void  CR_Test_TxConstantCarrier( const uint32_t freqMHz)
{
   // Set 's_myStateInfo' so status functions operate
   s_myStateInfo.crState = eCRSTATE_TEST;
   // Configure the Radio Hardware
   RadioHw_Config();
   // Set frequency and start transmit of carrier signal
   RadioHw_FrequencySet( freqMHz);
   RadioHw_TxStartConstantCarrier();
   // Carrier signal continues to transmit after code "returns"
   return;
}



/* ************************************************************************* */
/* ***************************************************************************
*  PRIVATE CORIANDOLO RADIO PROTOCOL EVENT FUNCTIONS -- in alphabetical order
*/

/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL EVENT DISABLE
*
*  A Radio Disable Event has occurred.
*  "Shutdown" the radio protocol by stopping the radio immediately and turning
*  off the radio timeout timer.
*
*  NOTE: this procedure does not affect contents of Radio Buffers, etc.
*        so application can "get" Rx and Tx information
*
*  MODIFIES STATIC VARIABLE: 's_myStateInfo'
*/
static void  CR_ProtocolEvent_Disable( void)
{
   // Stop the Timeout Counter
   CR_TimeoutCntr_Stop( s_myCrHwTimer);
   // Shutdown the radio hardware
   RadioHw_Shutdown();
   // Set all State Information values
   s_myStateInfo.runFlag = eCRPROTOCOLRUN_STOP;
   s_myStateInfo.crState = eCRSTATE_DISABLED;
   s_myStateInfo.announcementTries = 0u;
   s_myStateInfo.exchangeCount = 0u;
   s_myStateInfo.rxInfoPtr = CONST_NULLPTR;
   s_myStateInfo.txInfoPtr = CONST_NULLPTR;
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL EVENT ENABLE
*
*  Initializes the variables and structures used by the protocol then sets
*  the state to IDLE
*
*  MODIFIES STATIC VARIABLE: 's_myStateInfo'
*  NOTE: the protocol 'runFlag' should be set to STOP when the protocol is IDLE
*/
static void  CR_ProtocolEvent_Enable( void)
{
   // Initialize Protocol information
   //   (assumes radio hardware has already been initialized)
   CR_ProtocolBufrs_Init();
   s_myStateInfo.runFlag = eCRPROTOCOLRUN_STOP;
   s_myStateInfo.crState = eCRSTATE_IDLE;
   return;

}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL EVENT RADIO PACKET END
*
*  A Radio "Packet End" Event has been signalled indicating the radio hardware
*  has finished transmit of a message or receipt of a new message
*  "Step" the CR Protocol based on the current Protocol State.
*
*  MODIFIES STATIC VAR: 's_myStateInfo'
*  IMPORTANT NOTE: this procedure is always called during an interrupt.
*/
static void  CR_ProtocolEvent_RadioPktEnd( void)
{
   if( s_myStateInfo.crState == eCRSTATE_ANNOUNCE_TX)
   {
      // Radio "End" means eCRSTATE_ANNOUNCE_TX has completed Tx Message
      CR_ProtocolStep_AnnounceTxEnd();
   }
   else if( s_myStateInfo.crState == eCRSTATE_ANNOUNCE_RX)
   {
      // Radio "End" means eCRSTATE_ANNOUNCE_RX has completed with Received Message
      CR_ProtocolStep_AnnounceRcvd();
   }
   else if( s_myStateInfo.crState == eCRSTATE_ANNOUNCE_EXCHG_TX)
   {
      // Radio "End" means eCRSTATE_ANNOUNCE_EXCHG_TX has completed Tx
      //   next step may be eCRSTATE_ANNOUNCE_EXCHG_RX
      CR_ProtocolStep_ExchangeTxEnd( eCRSTATE_ANNOUNCE_EXCHG_RX);
   }
   else if( s_myStateInfo.crState == eCRSTATE_ANNOUNCE_EXCHG_RX)
   {
      // Radio "End" means eCRSTATE_ANNOUNCE_EXCHG_RX has completed with Rx Message
      CR_ProtocolStep_AnnounceRcvdExchng();
   }
   else if( s_myStateInfo.crState == eCRSTATE_LISTEN_RX)
   {
      // Radio "End" means eCRSTATE_LISTEN has completed with Received Message
      CR_ProtocolStep_ListenRcvd();
   }
   else if( s_myStateInfo.crState == eCRSTATE_LISTEN_EXCHG_TX)
   {
      // Radio "End" means eCRSTATE_LISTEN_EXCHG_TX has completed Tx
      //   next step may be eCRSTATE_LISTEN_EXCHG_RX
      CR_ProtocolStep_ExchangeTxEnd( eCRSTATE_LISTEN_EXCHG_RX);
   }
   else if( s_myStateInfo.crState == eCRSTATE_LISTEN_EXCHG_RX)
   {
      // Radio "End" means eCRSTATE_LISTEN_EXCHG_RX has completed with Rx Message
      CR_ProtocolStep_ListenRcvdExchng();
   }
   //
   else
   {
      // Unknown state for Event Radio End
      // A serious error has occurred
      // Stop the radio
      (void)RadioHw_ForceIdle();
      s_myStateInfo.runFlag = eCRPROTOCOLRUN_STOP;
      s_myStateInfo.crState = eCRSTATE_ERROR;
   }
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL EVENT TIMEOUT
*
*  A Radio Timeout Event has occurred.
*  "Stop" the Radio operation, then update the state and buffer information.
*
*  MODIFIES STATIC VARIABLE: 's_myStateInfo'
*  IMPORTANT NOTE: this procedure is always called during an interrupt.
*/
static void  CR_ProtocolEvent_Timeout( void)
{
   crtxflags_t  txMsgFlags;
   // Stop the Radio
   (void)RadioHw_ForceIdle();
   // Determine radio state, so buffer information is set correctly
   if( s_myStateInfo.crState == eCRSTATE_ANNOUNCE_RX)
   {
      // Timeout occurred while waiting for response on Announcement
      // This is normal part of the protocol.
      // Rx Buffer Status should be BUSY; must leave status as BUSY
      // Transmit another announcement
      // -- transmit and receive buffer information is already set
      CR_ProtocolStep_AnnounceTxBegin();
   }
   else if( s_myStateInfo.crState == eCRSTATE_LISTEN_RX)
   {
      // Timeout occurred while waiting for a Rx message during Listen
      // Change the Rx Buffer Status from BUSY to RXREADY
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.rxInfoPtr, eCRBUFRSTATUS_RXREADY);
      // "Finish" listen. (This is not an error.)
      CR_ProtocolWrapUp_Listen();
   }
   else if( s_myStateInfo.crState == eCRSTATE_LISTEN_EXCHG_RX)
   {
      // Timeout occurred while waiting for a Rx message during Listen Exchange
      // Change the Rx Buffer Status from BUSY to RXREADY
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.rxInfoPtr, eCRBUFRSTATUS_RXREADY);
      // Get the message flags for the last transmitted message (needed for Auto-Retry)
      txMsgFlags = CrBufr_BufrInfo_GetTxMsgFlags( s_myStateInfo.txInfoPtr);
      if( txMsgFlags == eCRTXFLAGS_AUTORETRY)
      {
         // The Transmit message was sent with AUTO-RETRY flag
         // Set status/exchange status so message will transmit again
         CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXREADY);
         CrBufr_BufrInfo_SetStatusExchange( s_myStateInfo.txInfoPtr, eEXCHANGE_MSG_RDY);
      }
      else
      {
         // Tx message was already marked as sent; leave it alone
      }
      // "Finish" listen. (This is not an error.)
      CR_ProtocolWrapUp_Listen();
   }
   else if( s_myStateInfo.crState == eCRSTATE_ANNOUNCE_EXCHG_RX)
   {
      // Timeout occurred while waiting for a Rx message during Announce Exchange
      // Tx message must have been sent; it may not have been received
      // Change the Rx Buffer Status from BUSY to RXREADY
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.rxInfoPtr, eCRBUFRSTATUS_RXREADY);
      // Get the message flags for the last transmitted message (needed for Auto-Retry)
      txMsgFlags = CrBufr_BufrInfo_GetTxMsgFlags( s_myStateInfo.txInfoPtr);
      if( txMsgFlags == eCRTXFLAGS_AUTORETRY)
      {
         // The Transmit message was sent with AUTO-RETRY flag
         // Set status/exchange status so message will transmit again
         CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXREADY);
         CrBufr_BufrInfo_SetStatusExchange( s_myStateInfo.txInfoPtr, eEXCHANGE_MSG_RDY);
      }
      else
      {
         // Tx message was already marked as sent; leave it alone
      }
      // Terminate Radio activities.  (This is not an error)
      CR_ProtocolWrapUp_Announce();
   }
   else if( s_myStateInfo.crState == eCRSTATE_LISTEN_EXCHG_TX)
   {
      // Timeout occurred while message was transmitting during Listen Exchange
      // This should never happen
      // Message transmission may or may not have completed because of timeout
      // Radio was "stopped" by code at top of procedure
      // Change the Rx Buffer Status from BUSY to RXREADY so Rx Buffer may be used again
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.rxInfoPtr, eCRBUFRSTATUS_RXREADY);
      // Change the Tx Buffer Status from BUSY to READY so message may be sent again
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXREADY);
      CrBufr_BufrInfo_SetStatusExchange( s_myStateInfo.txInfoPtr, eEXCHANGE_MSG_RDY);
      // "Finish" listen.
      // This is an error, but we are going to try and re-start "Listening" anyway.
      CR_ProtocolWrapUp_Listen();
   }
   else if( (s_myStateInfo.crState == eCRSTATE_ANNOUNCE_TX) ||
            (s_myStateInfo.crState == eCRSTATE_ANNOUNCE_EXCHG_TX) )
   {
      // Timeout occurred while message was transmitting
      // This should never happen
      // Message transmission may or may not have completed because of timeout
      // Radio was "stopped" by code at top of procedure
      // Change the Rx Buffer Status from BUSY to RXREADY so Rx Buffer may be used again
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.rxInfoPtr, eCRBUFRSTATUS_RXREADY);
      // Change the Tx Buffer Status from BUSY to READY so message may be sent again
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXREADY);
      CrBufr_BufrInfo_SetStatusExchange( s_myStateInfo.txInfoPtr, eEXCHANGE_MSG_RDY);
      // Call "Finish" Announcement for clean-up and completing STOP
      CR_ProtocolWrapUp_Announce();
   }
   else
   {
      // Unknown radio protocol state
      // This condition should never occur
      // Radio was "stopped" by code at top of procedure
      s_myStateInfo.runFlag = eCRPROTOCOLRUN_STOP;
      s_myStateInfo.crState = eCRSTATE_ERROR;
   }
   // done
   return;
}


/* ************************************************************************* */
/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL CODE -- in alphabetical order
*/

/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL START ANNOUNCEMENT
*
*  Starts a Coriandolo Radio Announcement.
*
*  MODIFIES STATIC VARIABLE: 's_myStateInfo'
*  NOTE: this code assumes Announcement structure, 's_announcementInfo', has
*        already been loaded with desired announcement message.
*
*  NOTE: the 'crState" must be eCRSTATE_ANNOUNCE_BEGIN which is set with
*        interrupts disabled
*/
static void  CR_ProtocolStart_Announce( void)
{
   // Start Announcement if state was set to BEGIN
   if( s_myStateInfo.crState == eCRSTATE_ANNOUNCE_BEGIN)
   {
      // "Announcement" structure has already been loaded
      // Fetch pointer to announcement info
      s_myStateInfo.txInfoPtr = &s_announcementInfo;
      //    and change buffer status to BUSY (previous announcement status is ignored)
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXBUSY);
      // Pre-fetch pointer to ready receive info for fast tx-rx turnaround
      //    and change buffer status to BUSY (if receive buffer exists)
      //    It is OK if code starts Announcement with no Rx Buffer
      s_myStateInfo.rxInfoPtr = CrBufr_Rx_FindNextRxReady();
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.rxInfoPtr, eCRBUFRSTATUS_RXBUSY);
      // Set other information into 's_myStateInfo' to start announcements
      s_myStateInfo.announcementTries = 0;
      s_myStateInfo.exchangeCount = 0;
      s_myStateInfo.runFlag = eCRPROTOCOLRUN_GO;
      CR_ProtocolStep_AnnounceTxBegin();
   }
   else
   {
      // state variable has unexpected
      // this may occur if there is multi-tasking
      // do nothing
   }
   // Done
   // This code may return while radio is in operation
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL START LISTEN
*
*  Starts a Coriandolo Radio Listen.
*
*  MODIFIES STATIC VARIABLE: 's_myStateInfo'
*  NOTE: the 'crState" must be eCRSTATE_LISTEN_BEGIN which is set with
*        interrupts disabled
*/
static void  CR_ProtocolStart_Listen( void)
{
   // Starting LISTEN if state was set to BEGIN
   // Start "Listen" only if current state is LISTEN BEGIN
   if( s_myStateInfo.crState == eCRSTATE_LISTEN_BEGIN)
   {
      // Start "Listening" for Announcement from SENSOR
      s_myStateInfo.rxInfoPtr = CrBufr_Rx_FindNextRxReady();
      if( s_myStateInfo.rxInfoPtr != CONST_NULLPTR)
      {
         // Change buffer status from READY to BUSY
         CrBufr_BufrInfo_SetStatus( s_myStateInfo.rxInfoPtr, eCRBUFRSTATUS_RXBUSY);
         // Radio Channel "Hop" before starting to Listen
         CR_RadioChannel_HopToNext();
         // Begin listening
         s_myStateInfo.exchangeCount = 0;
         s_myStateInfo.runFlag = eCRPROTOCOLRUN_GO;
         s_myStateInfo.crState = eCRSTATE_LISTEN_RX;
         CR_RxEnableStart( s_myStateInfo.rxInfoPtr,
                           s_timeoutValuesInTicks.radioListenFor1stMsgTimeout);
      }
      else
      {
         // No Rx buffer is ready
         // This is NOT an error, CR goes idle
         s_myStateInfo.runFlag = eCRPROTOCOLRUN_STOP;
         s_myStateInfo.crState = eCRSTATE_IDLE;
      }
   }
   else
   {
      // state variable has unexpected value
      // this may occur if there is multi-tasking
      // do nothing
   }
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL STEP ANNOUNCEMENT RECEIVED
*
*  As part of the CR Protocol, the SENSOR has received a message following
*  transmit of an Announcement.
*  This is not considered an "Exchange" since the transmitted message is an
*  Announcement and not from the Transmit Buffer Information Array.
*
*  MODIFIES STATIC VARIABLE: 's_myStateInfo'
*  IMPORTANT NOTE: this procedure is always called during an interrupt.
*/
static void  CR_ProtocolStep_AnnounceRcvd( void)
{
   crbufrstatus_t  rxStatus;
   // Process received message - must match my Sensor Device Identifier
   rxStatus = CR_RxMessage_Process( s_myStateInfo.rxInfoPtr, s_myDeviceInfo.deviceID);
   // Set the exchange status of the last transmitted message
   CR_ExchangeStatus_Set( s_myStateInfo.txInfoPtr, rxStatus);
   if( rxStatus == eCRBUFRSTATUS_RXMSGRCVD)
   {
      // If we are "discarding" default messages, do it
      if( s_discardDefaultMsg == true)
      {
         // Remove message
         (void)CR_RxMessage_RemoveDefaultMsg( s_myStateInfo.rxInfoPtr);
      }
      // Pre-fetch receive buffer, then get message to Transmit
      // NOTE: SENSOR must have a message ready to transmit and an "RxReady" 
      //       receive buffer to start an "exchange"
      s_myStateInfo.rxInfoPtr = CrBufr_Rx_FindNextRxReady();
      s_myStateInfo.txInfoPtr = CrBufr_Tx_FindNextTxReady( s_myDeviceInfo.deviceID);
      if( (s_myStateInfo.txInfoPtr != CONST_NULLPTR) &&
          (s_myStateInfo.rxInfoPtr != CONST_NULLPTR)  )
      {
         // Both Rx Buffer and Tx Message "ready"
         CrBufr_BufrInfo_SetStatus( s_myStateInfo.rxInfoPtr, eCRBUFRSTATUS_RXBUSY);
         CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXBUSY);
         // Transmit new message
         s_myStateInfo.crState = eCRSTATE_ANNOUNCE_EXCHG_TX;
         CR_TxMessage_Start( s_myStateInfo.txInfoPtr,
                             s_timeoutValuesInTicks.radioTxAddressTimeout);
      }
      else
      {
         // Rx Buffer or Tx Message not available
         CR_ProtocolWrapUp_Announce();
      }
   }
   else
   {
      // 'rxStatus' is not received message
      // This happens when radio fails to receive a "good" message
      // Because of call to "CR_RxMessage_Process", 'rxStatus' must be 
      //    eCRBUFRSTATUS_RXREADY
      // Transmit another announcement
      //    Both Rx and Tx info can be re-used from last message
      CR_ProtocolStep_AnnounceTxBegin();
   }
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL STEP ANNOUNCEMENT RECEIVED EXCHANGE 
*
*  As part of the CR Protocol, the SENSOR has received a message following
*  transmit during an Announcement Exchange. (Reception as part of the "Exchange",
*  not reception immediately after the Announcement.)
*  To continue to transmit messages and listen for receive messages, the
*  received message must be valid after "processing", the "Run flag" must be
*  set to GO and the protocol must not have reached the limit for Exchanges.
*
*  MODIFIES STATIC VARIABLE: 's_myStateInfo'
*  IMPORTANT NOTE: this procedure is always called during an interrupt.
*/
static void  CR_ProtocolStep_AnnounceRcvdExchng( void)
{
   crbufrstatus_t  rxStatus;
   crtxflags_t     txMsgFlags;
   // Process Response to last transmitted message
   rxStatus = CR_RxMessage_Process( s_myStateInfo.rxInfoPtr, s_myDeviceInfo.deviceID);
   // Set the exchange status of the transmit information
   CR_ExchangeStatus_Set( s_myStateInfo.txInfoPtr, rxStatus);
   s_myStateInfo.exchangeCount += 1;
   // Get the message flags for the last transmitted message (needed for Auto-Retry)
   txMsgFlags = CrBufr_BufrInfo_GetTxMsgFlags( s_myStateInfo.txInfoPtr);
   if( (rxStatus == eCRBUFRSTATUS_RXMSGRCVD)  &&
       (s_myStateInfo.runFlag == eCRPROTOCOLRUN_GO) &&
       (s_myStateInfo.exchangeCount <= CONST_ANNOUNCE_EXCHANGE_MAX) )
   {
      // If we are "discarding" default messages, do it
      if( s_discardDefaultMsg == true)
      {
         (void)CR_RxMessage_RemoveDefaultMsg( s_myStateInfo.rxInfoPtr);
      }
      // Pre-fetch receive buffer, then get message to Transmit
      // NOTE: SENSOR must have a "RxReady" receive buffer to transmit
      //       a message during an exchange
      s_myStateInfo.rxInfoPtr = CrBufr_Rx_FindNextRxReady();
      s_myStateInfo.txInfoPtr = CrBufr_Tx_FindNextTxReady( s_myDeviceInfo.deviceID);
      if( (s_myStateInfo.txInfoPtr != CONST_NULLPTR) &&
          (s_myStateInfo.rxInfoPtr != CONST_NULLPTR)  )
      {
         // Change Rx Buffer Info Status from READY to BUSY
         CrBufr_BufrInfo_SetStatus( s_myStateInfo.rxInfoPtr, eCRBUFRSTATUS_RXBUSY);
         // Change Tx Buffer Info Status from READY to BUSY
         CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXBUSY);
         // Transmit message
         s_myStateInfo.crState = eCRSTATE_ANNOUNCE_EXCHG_TX;                  
         CR_TxMessage_Start( s_myStateInfo.txInfoPtr,
                             s_timeoutValuesInTicks.radioTxAddressTimeout);
      }
      else
      {
         // Either no messages "ready" to transmit or no "ready" receive buffer
         // Terminate Exchanges.  (This is not an error)
         CR_ProtocolWrapUp_Announce();
      }
   }
   else if( (rxStatus != eCRBUFRSTATUS_RXMSGRCVD) &&
            (txMsgFlags == eCRTXFLAGS_AUTORETRY)  )
   {
      // No message received or received message is not valid, BUT the Transmit
      //    message was sent with AUTO-RETRY flag
      // Set status/exchange status so message will transmit again
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXREADY);
      CrBufr_BufrInfo_SetStatusExchange( s_myStateInfo.txInfoPtr, eEXCHANGE_MSG_RDY);
      // Because of call to "CR_RxMessage_Process", 'rxStatus' must be 
      //    eCRBUFRSTATUS_RXREADY
      // Terminate Exchanges.  (This is not an error)
      CR_ProtocolWrapUp_Announce();
   }
   else
   {
      // No message received or received message is not valid
      // No Tranmsit AUTO-RETRY
      // Because of call to "CR_RxMessage_Process", 'rxStatus' must be 
      //    eCRBUFRSTATUS_RXREADY
      // Terminate Exchanges.  (This is not an error)
      CR_ProtocolWrapUp_Announce();
   }
   // done
   return;   
}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL STEP ANNOUNCEMENT TRANSMIT BEGIN
*
*  As part of the CR Protocol, begin transmit of an Announcement.
*  Code checks that the protocol has not reached the limit for announcements.
*  Forces a "hop" to a new Radio Channel.
*
*  MODIFIES STATIC VARIABLE: 's_myStateInfo'
*/
static void  CR_ProtocolStep_AnnounceTxBegin( void)
{
   if( s_myStateInfo.announcementTries < CONST_ANNOUNCEMENT_TRIES_MAX)
   {
      s_myStateInfo.crState = eCRSTATE_ANNOUNCE_TX;
      // CR Protocol "hops" to next radio channel before transmitting an Announcement
      CR_RadioChannel_HopToNext();
      // Change buffer status to BUSY (previous announcement status is ignored)
      //  and exchange status to Message Ready
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXBUSY);
      CrBufr_BufrInfo_SetStatusExchange( s_myStateInfo.txInfoPtr, eEXCHANGE_MSG_RDY);
      // Transmit Announcement Message (already set in 'txInfoPtr')
      CR_TxMessage_Start( s_myStateInfo.txInfoPtr, 
                          s_timeoutValuesInTicks.radioTxAddressTimeout);
   }
   else
   {
      // No Announcement because out of "tries"
      // Change the Rx Buffer Status from BUSY to RXREADY so Rx Buffer may be used again
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.rxInfoPtr, eCRBUFRSTATUS_RXREADY);
      // Change the Tx Buffer Status from BUSY to READY so message may be sent again
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXREADY);
      CrBufr_BufrInfo_SetStatusExchange( s_myStateInfo.txInfoPtr, eEXCHANGE_MSG_RDY);
      // "Wrap-up" announcement
      CR_ProtocolWrapUp_Announce();
   }
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL STEP ANNOUNCEMENT TRANSMIT END
*
*  As part of the CR Protocol, the Transmit of a SENSOR Announcement has completed.
*  Update message and state information and then listen for a new message (if 
*  a receive buffer is available) or send the announcement again.
*
*  IMPORTANT NOTE: this procedure is always called during an interrupt.
*/
static void  CR_ProtocolStep_AnnounceTxEnd( void)
{
   // Increment number of "Announcement Tries"
   //   (value checked in "CR_ProtocolStep_AnnounceTxBegin")
   s_myStateInfo.announcementTries += 1;
   // Process sent transmitted message
   CR_TxMessage_ProcessSent( s_myStateInfo.txInfoPtr);
   // Check Receive Info pointer (already fetched)
   if( s_myStateInfo.rxInfoPtr != CONST_NULLPTR)
   {
      // Start receive
      s_myStateInfo.crState = eCRSTATE_ANNOUNCE_RX;
      CR_RxEnableStart( s_myStateInfo.rxInfoPtr,
                        s_timeoutValuesInTicks.radioListenForAddressTimeout);
   }
   else
   {
      // No Receive buffer.  (This is not an error)
      // So, don't receive, just "begin" the same announcement again
      //   Both Rx and Tx info can be re-used from last announcdement
      CR_ProtocolStep_AnnounceTxBegin();
   }
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL STEP EXCHANGE TRANSMIT END
*
*  As part of the CR Protocol, the Transmit of a message as part of an Exchange
*  has completed.
^  (Exchange may be part of a SENSOR Announcement or BASE Listen.)
*
*  MODIFIES STATIC VARIABLE: 's_myStateInfo'
*  IMPORTANT NOTE: this procedure is always called during an interrupt.
*/
static void  CR_ProtocolStep_ExchangeTxEnd( crstate_t nextState)
{
   // Process Tx Message
   CR_TxMessage_ProcessSent( s_myStateInfo.txInfoPtr);
   // Check Receive Info pointer (already fetched)
   if( s_myStateInfo.rxInfoPtr != CONST_NULLPTR)
   {
      // Start exchange receive
      s_myStateInfo.crState = nextState;
      CR_RxEnableStart( s_myStateInfo.rxInfoPtr,
                        s_timeoutValuesInTicks.radioListenForAddressTimeout);
   }
   else
   {
      // No Receive buffer
      // Terminate Exchanges.  (This is not an error)
      if( nextState == eCRSTATE_LISTEN_EXCHG_RX)
      {
         // Finish "Listen"
         CR_ProtocolWrapUp_Listen();
      }
      else
      {
         // Finish "Announcement" processs
         CR_ProtocolWrapUp_Announce();
      }
   }
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL STEP LISTEN RECEIVED
*
*  The BASE device has received a message while listening for a ANNOUNCEMENT.
*  Process the recieved message.  If received message is valid, get the Device
*  Identifier and use it 
*
*  MODIFIES STATIC VAR: 's_myStateInfo'
*  IMPORTANT NOTE: this procedure is always called during an interrupt.
*/
static void  CR_ProtocolStep_ListenRcvd( void)
{
   uint32_t  sensorDeviceId;
   crbufrstatus_t  rxStatus;
   // Process Response - match any Device Identifier
   rxStatus = CR_RxMessage_Process( s_myStateInfo.rxInfoPtr, CONST_DEVICEID_ALWAYS_MATCH);
   if( rxStatus == eCRBUFRSTATUS_RXMSGRCVD)
   {
      // Get Device Identifier from received message
      //   ('rxInfoPtr' is information of last received message)
      sensorDeviceId = CrBufr_BufrInfo_GetDeviceId( s_myStateInfo.rxInfoPtr);
      // Fetch a READY Response Message to the sensor or Build Default Response
      //   -- function call always returns a non-null pointer
      s_myStateInfo.txInfoPtr = CR_BaseResponseMsgInfo_GetPtr( sensorDeviceId);
      // Pre-fetch the receive buffer
      s_myStateInfo.rxInfoPtr = CrBufr_Rx_FindNextRxReady();
      // Change Rx Info Status from READY to BUSY
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.rxInfoPtr, eCRBUFRSTATUS_RXBUSY);
      // Change Tx Info Status from READY to BUSY
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXBUSY);
      // Transmit new message as part of exchange
      s_myStateInfo.crState = eCRSTATE_LISTEN_EXCHG_TX;
      CR_TxMessage_Start( s_myStateInfo.txInfoPtr,
                          s_timeoutValuesInTicks.radioTxAddressTimeout);
      // NOTE: BASE device will transmit message in response to a received 
      //       Announcement even if NO "ready" receive buffer is available.  
      //       Transmitted message may be from Tx Information Array or may be 
      //       Default Response.
   }
   else
   {
      // Valid message not received
      // Finish "Listen"
      // Because of call to "CR_RxMessage_Process", 'rxStatus' must be 
      //    eCRBUFRSTATUS_RXREADY
      CR_ProtocolWrapUp_Listen();
   }
   // done
   return;
}



/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL STEP LISTEN RECEIVED EXCHANGE
*
*  The BASE device has received a message while listening as part of an Exchange.
*  Get the Sensor Device Identifier from the last Transmitted message and use
*  it to process the receive message and to get the next message to transmit
*  for the Exchange.  Pre-fetch a receive buffer for the next exchange.
*  Transmit the new message starting a new exchange.
*
*  Code checks that the protocol has not reached the limit for Exchanges.
*  Code also checks "Run Flag" is not set to STOP (is set to GO)
*
*  MODIFIES STATIC VAR: 's_myStateInfo'
*  NOTE: message can not be received if there is no "ready" receive buffer
*  IMPORTANT NOTE: this procedure is always called during an interrupt.
*/
static void  CR_ProtocolStep_ListenRcvdExchng( void)
{
   uint32_t  sensorDeviceId;
   crbufrstatus_t  rxStatus;
   crtxflags_t     txMsgFlags;
   // Get Device Identifier from last transmitted message to Sensor
   sensorDeviceId = CrBufr_BufrInfo_GetDeviceId( s_myStateInfo.txInfoPtr);
   // Process Response to last transmitted message - match 'sensorDeviceId'
   rxStatus = CR_RxMessage_Process( s_myStateInfo.rxInfoPtr, sensorDeviceId);
   // Set the exchange status of the transmit information
   CR_ExchangeStatus_Set( s_myStateInfo.txInfoPtr, rxStatus);
   s_myStateInfo.exchangeCount += 1;
   // Get the message flags for the last transmitted message (needed for Auto-Retry)
   txMsgFlags = CrBufr_BufrInfo_GetTxMsgFlags( s_myStateInfo.txInfoPtr);
   // Continue exchange only if last message was received, the "Run Flag" is
   //    set to GO and exchanges are not greater-than maximum count
   if( (rxStatus == eCRBUFRSTATUS_RXMSGRCVD) &&
       (s_myStateInfo.runFlag == eCRPROTOCOLRUN_GO) &&
       (s_myStateInfo.exchangeCount <= CONST_LISTEN_EXCHANGE_MAX) )
   {
      // Fetch a READY Response Message to the sensor or Build Default Response
      //   -- function call always returns a non-null pointer
      s_myStateInfo.txInfoPtr = CR_BaseResponseMsgInfo_GetPtr( sensorDeviceId);
      // Pre-fetch receive buffer
      s_myStateInfo.rxInfoPtr = CrBufr_Rx_FindNextRxReady();
      // Change Rx Info Status from READY to BUSY
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.rxInfoPtr, eCRBUFRSTATUS_RXBUSY);
      // Change Tx Info Status from READY to BUSY
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXBUSY);
      // Transmit message
      s_myStateInfo.crState = eCRSTATE_LISTEN_EXCHG_TX;                  
      CR_TxMessage_Start( s_myStateInfo.txInfoPtr,
                          s_timeoutValuesInTicks.radioTxAddressTimeout);
   }
   else if( (rxStatus != eCRBUFRSTATUS_RXMSGRCVD) &&
            (txMsgFlags == eCRTXFLAGS_AUTORETRY)  )
   {
      // No message received or received message is not valid, BUT the Transmit
      //    message was sent with AUTO-RETRY flag
      // Set status/exchange status so message will transmit again
      CrBufr_BufrInfo_SetStatus( s_myStateInfo.txInfoPtr, eCRBUFRSTATUS_TXREADY);
      CrBufr_BufrInfo_SetStatusExchange( s_myStateInfo.txInfoPtr, eEXCHANGE_MSG_RDY);
      // Because of call to "CR_RxMessage_Process", 'rxStatus' must be 
      //    eCRBUFRSTATUS_RXREADY
      // Terminate Listen Exchanges.  (This is not an error)
      CR_ProtocolWrapUp_Listen();
   }
   else
   {
      // Terminate Listen Exchanges.  (This is not an error)
      // Because of call to "CR_RxMessage_Process", 'rxStatus' must be 
      //    eCRBUFRSTATUS_RXREADY
      CR_ProtocolWrapUp_Listen();
   }
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL WRAP UP ANNOUNCE
*
*  The SENSOR device has finished the Announcement and, if applicable, the
*  Announcement Exchange.  This procedure contains common code for completing 
*  the SENSOR Announcement.
*/
static void  CR_ProtocolWrapUp_Announce( void)
{
   // Set the 'runFlag' to STOP
   s_myStateInfo.runFlag = eCRPROTOCOLRUN_STOP;
   // Make sure radio has finished "Stop", then change CR State to IDLE
   (void)RadioHw_WaitForIdle();
   s_myStateInfo.crState = eCRSTATE_IDLE;
}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL WRAP UP LISTEN
*
*  The BASE device has finished listening for an Announcement and, if applicable,
*  the Listen Exchange.  This procedure contains common code for completing the
*  BASE LISTEN (and possibly restarting BASE listen).
*/
static void  CR_ProtocolWrapUp_Listen( void)
{
   // Make sure radio has finished "Stop"
   (void)RadioHw_WaitForIdle();
   // The "CR_Listen" automatically re-starts if "Run Flag" is GO
   if( s_myStateInfo.runFlag == eCRPROTOCOLRUN_GO)
   {
      s_myStateInfo.crState = eCRSTATE_LISTEN_BEGIN;
      CR_ProtocolStart_Listen();
   }
   else
   {
      // The 'runFlag' is not set to "Go"
      //   - set it to "Stop" (it may have been an invalid value)
      s_myStateInfo.runFlag = eCRPROTOCOLRUN_STOP;
      // Change CR State to IDLE
      s_myStateInfo.crState = eCRSTATE_IDLE;
   }
   // done
   return;
}



/* ************************************************************************* */
/* ***************************************************************************
*  PRIVATE CORIANDOLO RADIO RADIO EVENT FUNCTIONS -- in alphabetical order
*/

/* ***************************************************************************
*  CORIANDOLO RADIO RADIO EVENT PACKET BEGIN
*
*  This is called from "RadioHw.c" as a callback on a "Packet Begin" event
*/
static void  CR_RadioEvent_PacketBegin( void* radioStatusPtr)
{
   s_radioAddressTimestamp = CR_TicksCapture_Now();
   // Clear radio timeout
   NRF51_RTC_ClrRadioTimeout( s_myCrHwTimer);
   // Handle Flags for Tx or Rx
   if( *(radiostatus_t*)radioStatusPtr == eRADIOSTATUS_TX)
   {
      MACRO_DEBUGPINTX_HIGH;
      CR_TxFlags_Handle( s_myStateInfo.txInfoPtr, s_radioAddressTimestamp);
      // done with ADDRESS EVENT during transmit
   }
   else
   {
      // Presumes Rx State
      MACRO_DEBUGPINRX_HIGH;
      // done with ADDRESS EVENT during receive
   }
   // Set new Timeout value for radio message complete
   NRF51_RTC_SetRadioTimeout( s_myCrHwTimer, s_timeoutValuesInTicks.radioMessageCompleteTimeout);
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO RADIO EVENT PACKET END
*
*  This is called from "RadioHw.c" as a callback on a "Packet End" event
*/
static void  CR_RadioEvent_PacketEnd( void* radioStatusPtr)
{
      MACRO_DEBUGPINTX_LOW;
      MACRO_DEBUGPINRX_LOW;
      // Clear radio timeout
      NRF51_RTC_ClrRadioTimeout( s_myCrHwTimer);
      // Handle the "End" Event
      CR_ProtocolEvent_RadioPktEnd();
      // ignore value of 'radioStatusPtr' - this added to avoid warning
      (void)(radioStatusPtr);
      // done
      return;
}


/* ***************************************************************************/
/* ***************************************************************************
*  PRIVATE CORIANDOLO RADIO PROTOCOL SUPPORT FUNCTIONS -- in alphabetical order
*/

/* ***************************************************************************
*  CORIANDOLO RADIO ANNOUNCEMENT DEFAULT BUILD
*
*  Loads the bytes of for a "Default Announcement" into 'msgBufr'
*     The Default Announcement contains only the Device Identifier
*  NOTE: this procedure does not check size of 'msgBufr'
*/
static void  CR_AnnouncementDefault_Build( uint8_t* msgBufr, 
                                           const uint32_t deviceId)
{
   msgBufr[0] = (uint8_t)CONST_DEVICEID_SIZEINMESSAGE;
   CrDeviceId_PutBytes( deviceId, &(msgBufr[1]));
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO ANNOUNCEMENT INFORMATION LOAD
*
*  "Loads" the Announcement Message into a special transmit info structure
*/
static void  CR_AnnouncementInfo_Load( uint8_t* announcementMsgPtr)
{
   uint8_t  announcementLength; 
   // Load a Buffer Information structure with the Announcement Message
   if( announcementMsgPtr != CONST_NULLPTR)
   {
      // Use the passed message as the Announcement
      //    Load it into the static "Announcement Info"
      // The total transmit length is the first byte of the Announcement Message plus 1
      announcementLength = (*announcementMsgPtr + (uint8_t)1);
      CrBufr_LoadTxBufrInfo( &s_announcementInfo, 
                             announcementMsgPtr,
                             announcementLength,
                             eCRTXFLAGS_NONE,
                             s_myDeviceInfo.deviceID);
   }
   else
   {
      // Use Default Announcement Message
      //    Load it into the static "Announcement Info"
      announcementLength = (CONST_DEVICEID_SIZEINMESSAGE + 1);
      CrBufr_LoadTxBufrInfo( &s_announcementInfo, 
                             s_announceDefaultMsg,
                             announcementLength,
                             eCRTXFLAGS_NONE,
                             s_myDeviceInfo.deviceID);
   }
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO BASE RESPONSE MESSAGE INFORMATION GET POINTER
*
*  This function returns a pointer to a BASE device Response Message Buffer
*  Information structure.  This pointer refers to either a message in the
*  BASE Transmit Buffer Information array or the Default Response Message.
*  The Default Response Message is modified to contain the passed 'deviceId'
*
*  NOTE: This function NEVER returns CONST_NULLPTR.
*  NOTE: This function was constructed so that runs in about same amount of time
*        regardless of whether default response is used or not.
*/
static  crbufrinfo_t*  CR_BaseResponseMsgInfo_GetPtr( const uint32_t sensorId)
{
   crbufrinfo_t*  responseBufrInfoPtr;
   uint8_t*  defaultResponseMsgPtr;
   // Update Default Response Message and Response Buffer Info with 'deviceId'
   defaultResponseMsgPtr = CrBufr_BufrInfo_GetMsgPtr( &s_defaultResponseInfo);
   // Because this is 's_defaultResponseInfo', 'defaultResponseMsgPtr' can not 
   //   be NULL POINTER
   CR_DefaultResponseMsg_Build( defaultResponseMsgPtr, sensorId);
   CrBufr_BufrInfo_SetDeviceId( &s_defaultResponseInfo, sensorId);
   CrBufr_BufrInfo_SetStatus( &s_defaultResponseInfo, eCRBUFRSTATUS_TXREADY);
   // Get message to Transmit
   responseBufrInfoPtr = CrBufr_Tx_FindNextTxReady( sensorId);
   if( responseBufrInfoPtr == CONST_NULLPTR)
   {
      // No message to transmit
      // use default "ack" message
      responseBufrInfoPtr = &s_defaultResponseInfo;
   }
   // done
   return responseBufrInfoPtr;
}


/* ***************************************************************************
*  CORIANDOLO RADIO CONVERT STATE TO STATUS
*
*  Converts Coriandolo State Value to Croriandolo Status Value
*/
static crstatus_t  CR_ConvertStateToStatus( const crstate_t crState)
{
   crstatus_t  crStatus;
   switch( crState)
   {
      case eCRSTATE_DISABLED:
            crStatus = eCR_STATUS_DISABLED;
            break;
      case eCRSTATE_IDLE:
            crStatus = eCR_STATUS_IDLE;
            break;
      case eCRSTATE_ANNOUNCE_BEGIN:
      case eCRSTATE_ANNOUNCE_RX:
      case eCRSTATE_ANNOUNCE_TX:
            crStatus = eCR_STATUS_SENSORANNOUNCE;
            break;
      case eCRSTATE_ANNOUNCE_EXCHG_RX:
      case eCRSTATE_ANNOUNCE_EXCHG_TX:
            crStatus = eCR_STATUS_SENSOREXCHANGE;
            break;
      case eCRSTATE_LISTEN_BEGIN:
      case eCRSTATE_LISTEN_RX:
            crStatus = eCR_STATUS_BASELISTEN;
            break;
      case eCRSTATE_LISTEN_EXCHG_RX:
      case eCRSTATE_LISTEN_EXCHG_TX:
            crStatus = eCR_STATUS_BASEEXCHANGE;
            break;
      case eCRSTATE_ERROR:
      case eCRSTATE_TEST:
      default:
            crStatus = eCR_STATUS_ERROR;
            break;
   }
   // done
   return crStatus;
}


/* ***************************************************************************
*  CORIANDOLO RADIO DEFAULT RESPONSE MESSAGE BUILD
*
*  Loads the bytes of for a Default Response Message into 'msgBufr'
*     The Default Response Message contains only the Device Identifier
*  NOTE: this procedure does not check size of 'msgBufr'
*/
static void  CR_DefaultResponseMsg_Build( uint8_t* msgBufr,
                                          const uint32_t deviceId)
{
   msgBufr[0] = (uint8_t)CONST_DEVICEID_SIZEINMESSAGE;
   CrDeviceId_PutBytes( deviceId, &(msgBufr[1]));
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO EXCHANGE STATUS SET
*
*  Sets the "Exchange Status" for the transmit buffer from the receive status.
*  This allows the code to determine that if a transmitted message has a
*  corresponding received message (but not which corresponding receive message).
*/
static __INLINE void  CR_ExchangeStatus_Set( crbufrinfo_t* txInfoPtr,
                                             const crbufrstatus_t rxStatus)
{
   if( rxStatus == eCRBUFRSTATUS_RXMSGRCVD)
   {
      CrBufr_BufrInfo_SetStatusExchange( txInfoPtr, eEXCHANGE_RX_RCVD);
   }
   else
   {
      CrBufr_BufrInfo_SetStatusExchange( txInfoPtr, eEXCHANGE_NO_RX);
   }
   // done
   return;
}

/* ***************************************************************************
*  CORIANDOLO RADIO IS DEFAULT RESPONSE MESSAGE
*
*  Returns 'true' if the message in the buffer is a Default Response Message.
*  Only checks if the message size in the first byte is equal-to 
*  CONST_DEVICEID_SIZEINMESSAGE
*  
*  For additional info see "CR_DefaultResponseMsg_Build"
*/
static __INLINE bool  CR_IsDefaultResponseMsg( uint8_t msgBufr[])
{
   bool  isDefault;
   if( (uint16_t)(msgBufr[0]) == (uint16_t)CONST_DEVICEID_SIZEINMESSAGE)
   {
      isDefault = true;
   }
   else
   {
      isDefault = false;
   }
   return isDefault;
}


/* ***************************************************************************
*  CORIANDOLO RADIO MY COUNTER INFORMATION SET
*
*  Analyses and copies counter/timer information passed by higher-level code
*  into the appropriate static variables.
*  Returns 'true' if passed information is valid
*
*  MODIFIES STATIC VARIABLE: 's_myCrHwTimer'
*  MODIFIES STATIC VARIABLE: 's_myTicksCntrPtr'
*/
static bool  CR_MyCounterInfo_Set( const crcntrinfo_t* crCntrInfo)
{
   bool  cntrInfoIsValid;
   if( crCntrInfo == CONST_NULLPTR)
   {
      cntrInfoIsValid = false;
   }
   else if( crCntrInfo->revision != 0uL)
   {
      cntrInfoIsValid = false;
   }
   else
   {
      // Set statics
      s_myCrHwTimer = crCntrInfo->crTimerSelect;
      CR_TicksCapture_Init( crCntrInfo->crTicksCntrSelect);
      // check for legal value of 's_myCrHwTimer'
      cntrInfoIsValid = CR_TimeoutCntr_IsLegal( s_myCrHwTimer);
   }
   // done
   return cntrInfoIsValid;
}


/* ***************************************************************************
*  CORIANDOLO RADIO MY DEVICE INFORMATION SET
*
*  Analyses and copies Device Information passed by higher-level code into the
*  appropriate static variables.
*  Returns 'true' if passed information is valid
*
*  MODIFIES STATIC VARIABLE: 's_myDeviceInfo'
*/
static bool  CR_MyDeviceInfo_Set( const deviceinfo_t* deviceInfoPtr)
{
   bool  deviceInfoIsValid;
   if( deviceInfoPtr == CONST_NULLPTR)
   {
      deviceInfoIsValid = false;
   }
   else if( deviceInfoPtr->revision != 0uL)
   {
      // Revision of passed Device Info structure can not be processed
      deviceInfoIsValid = false;
   }
   else
   {
      // Copy structure into static
      s_myDeviceInfo = *deviceInfoPtr;
      // Set statics
      deviceInfoIsValid = CrDeviceID_IsLegal( s_myDeviceInfo.deviceID);
      if( (s_myDeviceInfo.deviceType != eCRTYPE_BASE) && 
          (s_myDeviceInfo.deviceType != eCRTYPE_SENSOR))
      {
         deviceInfoIsValid = false;
      }
      // All connection values are valid
      // Set a DEFAULT Rx Option
      if( s_myDeviceInfo.deviceOption == eCRDEVICEOPT_REMOVE_DEFAULT_ACKS)
      {
         s_discardDefaultMsg = true;
      }
      else
      {
         s_discardDefaultMsg = false;
      }
   }
   // done
   return deviceInfoIsValid;   
}


/* ***************************************************************************
*  CORIANDOLO RADIO PROTOCOL BUFFERS INITIALIZE
*
*  Resets the Protocol Buffers, builds default messages and initializes structures.
*  This code builds SENSOR default Announcement message as well as building and
*  initializing variables for BASE default resppnse message, even though only one
*  set of variables will actually be used.
*/
static void  CR_ProtocolBufrs_Init( void)
{
   uint8_t*  responseMsgPtr;
   // Reset the buffers used by the CR Protocol
   CrBufr_Init();
   // PreLoad the Default Response Message variables (only needed for BASE)
   //    use a Sensor Device Identifier of zero
   //    Return value of "CrBufr_LoadTxBufrInfo" is not needed
   responseMsgPtr = CrBufr_BufrInfo_GetMsgPtr( &s_defaultResponseInfo);
   CR_DefaultResponseMsg_Build( responseMsgPtr, 0x00000000uL);
   (void)CrBufr_LoadTxBufrInfo( &s_defaultResponseInfo, 
                                s_defaultResponseMsg, 
                                (CONST_DEVICEID_SIZEINMESSAGE + 1),
                                eCRTXFLAGS_NONE,
                                s_myDeviceInfo.deviceID);
   // Build Default Announcement message (only needed for SENSOR)
   CR_AnnouncementDefault_Build( s_announceDefaultMsg, s_myDeviceInfo.deviceID);
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO RADIO ADDRESSES SET
*
*  This procedure sets the Base and Sensor Radio Addresses used for the low-
*  level Radio Link.  The Addresses are set based upon the "Device Type" and 
*  the "Connection" Value.
*
*  NOTE: The procedure creates two 64-bit addresses, but the largest possible
*        nRF51 radio address is 5 bytes (40 bits).
*  
*  The 64-bit BASE address...
*     The upper 32-bits is set to 0x00000051 
*     The lower 32-bit is set to the "Connection" Value shifted left 16-bits
*  The 64-bit SENSOR address...
*     The upper 32-bits is set to 0x000000A8
*     The lower 32-bit is set to the "Connection" Value shifted left 16-bits.
*
*  NOTE TO READER: Do not over-think choice of address constants.  These values 
*                  are similar-to, but different than an older version of code.
*                  For that code version, the values were chosen just to be
*                  "different" than other known nRF51 uses.
*
*  NOTE TO READER: Do not confuse Radio Addresses with Device Identifiers.
*                  Radio addresses are totally independent of Device Identifiers.
*                  The Radio addresses are found at the beginning of the radio
*                  packet and used by the radio hardware.  The Device 
*                  Identifiers are contained in the radio packet payload
*                  (the message) and used by the Coriandolo Protocol to identify
*                  unigue devices.
*/
static void  CR_RadioAddresses_Set( const crtype_t crDeviceType,
                                    const uint16_t radioConnection)
{
   uint64_t  addressBase;
   uint64_t  addressSensor;
   addressBase = (((uint64_t)0x00000051uL) << 32) + 
                 (((uint64_t)radioConnection) << 16);
   addressSensor = (((uint64_t)0x000000A8uL) << 32) + 
                   (((uint64_t)radioConnection) << 16);
   if( crDeviceType == eCRTYPE_SENSOR)
   {
      // Sensor devices receive messages with 'addressSensor' 
      //            and transmit with 'addressBase'
      RadioHw_AddressRx_Set( addressSensor);
      RadioHw_AddressTx_Set( addressBase);
   }
   else if( crDeviceType == eCRTYPE_BASE)
   {
      // Base devices receive messages with 'addressBase'
      //          and transmit with 'addressSensor'
      RadioHw_AddressRx_Set( addressBase);
      RadioHw_AddressTx_Set( addressSensor);
   }
   else
   {
      // Error has occurred
      // Do NOT SET RADIO ADDRESSES
      __NOP();
   }
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO RADIO CHANNEL HOP TO NEXT
*
*  This code calls "RadioHw_FrequencySet" from values in 's_hopFreqTable'
*  (which are presumed valid) so it does not check return value of that function.
*/
static __INLINE void  CR_RadioChannel_HopToNext( void)
{
   s_hopFreqIndx += 1uL;
   if( s_hopFreqIndx >= ( sizeof( s_hopFreqTable)/4))
   {
      s_hopFreqIndx = 0uL;
   }
   (void)RadioHw_FrequencySet( s_hopFreqTable[ s_hopFreqIndx]);
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO RX LISTEN START
*
*  Starts Radio Reception and returns
*  This procedure does not wait for reception to complete
*
*  NOTE: this code does NOT check 'rxInfoPtr' for NULL POINTER
*        or for valid contents of the structure
*  NOTE: this code does NOT check 'timeout' for a valid value
*/
static void  CR_RxEnableStart( crbufrinfo_t* rxInfoPtr, const uint32_t timeout)
{
   uint8_t*  rxBufrPtr;
   uint8_t  rxBufrSize;
   // Wait any previous Radio operation to complete
   (void)RadioHw_WaitForIdle();
   // Start the radio timeout
   NRF51_RTC_SetRadioTimeout( s_myCrHwTimer, timeout);
   // Get the Buffer length; Get the receive buffer
   //    -- higher level code should have checked for valid 'rxInfoPtr'
   rxBufrSize = CrBufr_BufrInfo_GetSize( rxInfoPtr);
   rxBufrPtr = CrBufr_BufrInfo_GetMsgPtr( rxInfoPtr);
   RadioHw_RxStart( rxBufrPtr, rxBufrSize);
   MACRO_DEBUGPINRX_HIGH;
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO RECEIVE MESSAGE CHECK CRC
*
*  Checks CRC of a newly received radio packet
*  The buffer status should indicate a "Receive Busy"
*
*  IMPORTANT NOTE: this procedure is always called during an interrupt.
*/
static crbufrstatus_t  CR_RxMessage_CheckCRC( crbufrinfo_t* rxInfoPtr)
{
   crbufrstatus_t  rxBufrStatus;
   bool rcvdPktIsGood;
   // Check radio receive message only if status is RXBUSY
   rxBufrStatus = CrBufr_BufrInfo_GetStatus( rxInfoPtr);
   if( rxBufrStatus == eCRBUFRSTATUS_RXBUSY)
   {
      rcvdPktIsGood = RadioHw_RxPacket_IsOK();
      if( rcvdPktIsGood == true)
      {
         // Change status from RXBUSY to RXMSGRCVD
         CrBufr_BufrInfo_SetStatus( rxInfoPtr, eCRBUFRSTATUS_RXMSGRCVD);
         rxBufrStatus = eCRBUFRSTATUS_RXMSGRCVD;
      }
      else
      {
         // Change status from RXBUSY to RXMSGERROR
         CrBufr_BufrInfo_SetStatus( rxInfoPtr, eCRBUFRSTATUS_RXMSGERROR);
         rxBufrStatus = eCRBUFRSTATUS_RXMSGERROR;
      }
   }
   // done
   return rxBufrStatus;
 }
   

/* ***************************************************************************
*  CORIANDOLO RADIO RECEIVE MESSAGE PROCESS
*
*  "Processes" the received message.
*  If the received message does not have status eCRBUFRSTATUS_RXMSGRCVD, then
*  the status Byte is set to eCRBUFRSTATUS_RXREADY; this makes the buffer 
*  available for another receive.
*  The received "SensorId" is compared to 'matchDeviceId'; if the compare result
*  is "not equal" the status byte is set to  eCRBUFRSTATUS_RXREADY.
*
*  At the end of this function, the message buffer status is either 
*  eCRBUFRSTATUS_RXMSGRCVD or eCRBUFRSTATUS_RXREADY.
*
*  NOTE: "CrBufr_BufrInfo_GetStatus" can handle 'rxInfoPtr' equal to NULL POINTER
*  IMPORTANT NOTE: this procedure is always called during an interrupt.

*/ 
static crbufrstatus_t  CR_RxMessage_Process( crbufrinfo_t*  rxInfoPtr,
                                             const uint32_t matchDeviceId)
{
   crbufrstatus_t  rxBufrStatus;
   uint8_t*  msgPtr;
   uint32_t  deviceIdValue;
   bool      sensorIdMatches;
   rxBufrStatus = CR_RxMessage_CheckCRC( rxInfoPtr);
   if( rxBufrStatus == eCRBUFRSTATUS_RXMSGRCVD)
   {
      // Message was received correctly; the value of the Device Identifier in
      // the messge must match 'matchDeviceId' value else message is "tossed".
      // Copy Device Identifier from message to information structure.
      msgPtr = CrBufr_BufrInfo_GetMsgPtr( rxInfoPtr);
      CrDeviceId_GetBytes( &deviceIdValue, (msgPtr + 1));
      CrBufr_BufrInfo_SetDeviceId( rxInfoPtr, deviceIdValue);
      // Compare "Device ID" of received message to 'matchDeviceId'
      sensorIdMatches = CrDeviceID_IsMatch( deviceIdValue, matchDeviceId); 
      if( sensorIdMatches == true)
      {
         // "Sensor Id" matches
         // Copy timeStamp of Address to information structure
         CrBufr_BufrInfo_SetTickValue( rxInfoPtr, s_radioAddressTimestamp);
         // Assign a Receive Sequence Number
         CrBufr_Rx_AssignRcvdSequenceNum( rxInfoPtr);
         // status remains eCRBUFRSTATUS_RXMSGRCVD
      }
      else
      {
         // "Sensor Id" does not Match
         // Throw away message by changing status from RXMSGRCVD to RXREADY
         CrBufr_BufrInfo_SetStatus( rxInfoPtr, eCRBUFRSTATUS_RXREADY);
         rxBufrStatus = eCRBUFRSTATUS_RXREADY;
      }
   }
   else
   {
      // Message was not received correctly
      //    (could be Message CRC Error or could be Receive Timeout)
      // Throw away message by changing status to RxReady
      CrBufr_BufrInfo_SetStatus( rxInfoPtr, eCRBUFRSTATUS_RXREADY);
      rxBufrStatus = eCRBUFRSTATUS_RXREADY;
   }
   // done
   return rxBufrStatus;
}
 
 
/* ***************************************************************************
*  CORIANDOLO RADIO RECEIVE MESSAGE REMOVE DEFAULT MESSAGE
*
*  Checks message in 'rxInfoPtr'.  If message is a default message, it is 
*  removed by setting the Receive Buffer to "Ready".
*  Returns 'true' if message was removed; otherwise returns false
*
*  If any error is detected, nothing happens.
*
*  NOTE: this function does not check if message status indicates "received
*        message"; this should be done by higher-level code.
*/
static bool  CR_RxMessage_RemoveDefaultMsg( crbufrinfo_t* rxInfoPtr)
{
   uint8_t* msgPtr;
   bool  isDefaultMsg;
   bool  msgDiscarded;
   msgDiscarded = false;
   msgPtr = CrBufr_BufrInfo_GetMsgPtr( rxInfoPtr);
   if( msgPtr != CONST_NULLPTR)
   {
      isDefaultMsg = CR_IsDefaultResponseMsg( msgPtr);
      if( isDefaultMsg == true)
      {
         // Throw away message by changing status to RxReady
         CrBufr_BufrInfo_SetStatus( rxInfoPtr, eCRBUFRSTATUS_RXREADY);
         msgDiscarded = true;
      }
   }
   return msgDiscarded;
}


/* ***************************************************************************
*  CORIANDOLO RADIO TRANSMIT FLAGS HANDLE
*
*  If SYNC FLAG, over-writes the time value into the last four bytes of the 
*  message.
*
*  NOTE: this code does not check 'txInfoPtr' for NULL POINTER
*/
static __INLINE void  CR_TxFlags_Handle( crbufrinfo_t* txInfoPtr,
                                         const uint32_t timeValue)
{
   unsigned int  txTotalSize;
   uint8_t*  txMsgBytes;
   crtxflags_t  txFlags;
   // Check for transmit sync flag
   txFlags = CrBufr_BufrInfo_GetTxMsgFlags( txInfoPtr);
   if( txFlags == eCRTXFLAGS_SYNC)
   {
      // Get pointer to the transmit message bytes
      //   total size is the value found in first byte + 1
      txMsgBytes = CrBufr_BufrInfo_GetMsgPtr( txInfoPtr);
      txTotalSize = (unsigned int)(txMsgBytes[0]) + 1u;
      // Put "Radio Address Timestamp in last four bytes of message
      //    last four bytes are located at "txMsgBytes[ txTotalSize - 4]"
      //    NOTE: last 4 bytes must be assumed "Byte Aligned", so must do byte writes
      txMsgBytes[ txTotalSize - 4u] = (uint8_t)timeValue;
      txMsgBytes[ txTotalSize - 3u] = (uint8_t)(timeValue>>8);
      txMsgBytes[ txTotalSize - 2u] = (uint8_t)(timeValue>>16);
      txMsgBytes[ txTotalSize - 1u] = (uint8_t)(timeValue>>24);
      // end of "Sync Flag"
   }
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO TRANSMIT MESSAGE PROCESS SENT
*
*  Message processing after successfully transmitting a message
*
*  IMPORTANT NOTE: this procedure is always called during an interrupt.
*/
static void  CR_TxMessage_ProcessSent( crbufrinfo_t* txInfoPtr)
{
   // Change Tx Buffer Information Status from BUSY to MSGSENT
   CrBufr_BufrInfo_SetStatus( txInfoPtr, eCRBUFRSTATUS_TXMSGSENT);
   // Copy timeStamp to information structure
   CrBufr_BufrInfo_SetTickValue( txInfoPtr, s_radioAddressTimestamp);
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO TX MESSAGE START
*
*  Starts a Radio Transmission and returns
*  This procedure does not wait for transmit to complete
*
*  NOTE: this code does NOT check 'txInfoPtr' for NULL POINTER
*        or for valid contents of the structure
*  NOTE: this code does NOT check 'timeout' for a valid value
*  NOTE: the "Maximum Packet Length" can be set to the "Maximum Payload Length"
*        for transmission, because the DMA will only transfer the number bytes
*        specified in the first byte pointed to by 'bufrPtr'
*        (unless it is greater than CONFIG_PAYLOAD_LENGTHBYTE_MAX)
*/
static void  CR_TxMessage_Start( crbufrinfo_t* txInfoPtr, const uint32_t timeout)
{
   uint8_t*  txMsgPtr;
   // Wait any previous Radio operation to complete
   (void)RadioHw_WaitForIdle();
   // Start radio timeout
   NRF51_RTC_SetRadioTimeout( s_myCrHwTimer, timeout);
   // Get the transmit message
   //    -- higher level code should have checked for valid 'txInfoPtr'
   txMsgPtr = CrBufr_BufrInfo_GetMsgPtr( txInfoPtr);
   // Start the radio transmitter
   //  -- inform radio hardware that payload is max length
   //  -- this means message payload size is limited by first byte of payload
   RadioHw_TxStart( txMsgPtr, CONFIG_PAYLOAD_LENGTHBYTE_MAX);
   MACRO_DEBUGPINTX_HIGH;
   // done
   return;
}



/* ***************************************************************************/
/* ***************************************************************************
*  PRIVATE TIME SUPPORT FUNCTIONS
*/

/* ***************************************************************************
*  CORIANDOLO RADIO TICKS CALCULATE
*
*  Calculates a value in "ticks" from a time in nanoseconds and nanoseconds-
*  per-tick.
*
*  NOTE: this function always rounds-up
*/
static __INLINE uint32_t  CR_Ticks_Calc( uint32_t nanoSec, uint32_t nanoSecPerTick)
{
   uint32_t ticks;
   if( nanoSecPerTick > 0)
   {
      ticks = (nanoSec + (nanoSecPerTick - 1uL))/nanoSecPerTick;
   }
   else
   {
      ticks = 0xFFFFFFFFuL;
   }
   return ticks;
}


/* ***************************************************************************
*  CORIANDOLO RADIO TICKS CAPTURE INITIALIZE
*
*  Sets the static variable(s) associated with capturing the ticks value from
*  the selected "Ticks Counter"
*
*  Hardware Timers have both an associated "Task" register as well as a register
*  from which to read the value.  Hardware RTC have only a register from which
*  to read the value.
*/
static void  CR_TicksCapture_Init( crtickscntr_t crTicksCntrSelect)
{
   switch( crTicksCntrSelect)
   {
      case eCRTICKSCNTR_TIMER0_CC0:
            s_myTicksCntrInfo.captureTaskPtr = &(NRF_TIMER0->TASKS_CAPTURE[0]);
            s_myTicksCntrInfo.captureRegPtr  = &(NRF_TIMER0->CC[0]);
            break;
      case eCRTICKSCNTR_TIMER0_CC1:
            s_myTicksCntrInfo.captureTaskPtr = &(NRF_TIMER0->TASKS_CAPTURE[1]);
            s_myTicksCntrInfo.captureRegPtr  = &(NRF_TIMER0->CC[1]);
            break;
      case eCRTICKSCNTR_TIMER0_CC2:
            s_myTicksCntrInfo.captureTaskPtr = &(NRF_TIMER0->TASKS_CAPTURE[2]);
            s_myTicksCntrInfo.captureRegPtr  = &(NRF_TIMER0->CC[2]);
            break;
      case eCRTICKSCNTR_TIMER0_CC3:
            s_myTicksCntrInfo.captureTaskPtr = &(NRF_TIMER0->TASKS_CAPTURE[3]);
            s_myTicksCntrInfo.captureRegPtr  = &(NRF_TIMER0->CC[3]);
            break;
      case eCRTICKSCNTR_TIMER1_CC0:
            s_myTicksCntrInfo.captureTaskPtr = &(NRF_TIMER1->TASKS_CAPTURE[0]);
            s_myTicksCntrInfo.captureRegPtr  = &(NRF_TIMER1->CC[0]);
            break;
      case eCRTICKSCNTR_TIMER1_CC1:
            s_myTicksCntrInfo.captureTaskPtr = &(NRF_TIMER1->TASKS_CAPTURE[1]);
            s_myTicksCntrInfo.captureRegPtr  = &(NRF_TIMER1->CC[1]);
            break;
      case eCRTICKSCNTR_TIMER1_CC2:
            s_myTicksCntrInfo.captureTaskPtr = &(NRF_TIMER1->TASKS_CAPTURE[2]);
            s_myTicksCntrInfo.captureRegPtr  = &(NRF_TIMER1->CC[2]);
            break;
      case eCRTICKSCNTR_TIMER1_CC3:
            s_myTicksCntrInfo.captureTaskPtr = &(NRF_TIMER1->TASKS_CAPTURE[3]);
            s_myTicksCntrInfo.captureRegPtr  = &(NRF_TIMER1->CC[3]);
            break;
      case eCRTICKSCNTR_RTC0:
            s_myTicksCntrInfo.captureTaskPtr = &s_taskDoNothing;
            s_myTicksCntrInfo.captureRegPtr  = &(NRF_RTC0->COUNTER);
            break;
      case eCRTICKSCNTR_RTC1:
            s_myTicksCntrInfo.captureTaskPtr = &s_taskDoNothing;
            s_myTicksCntrInfo.captureRegPtr  = &(NRF_RTC1->COUNTER);
            break;
      default:
            // The default selection is NONE
            // this is not considered an error
            s_myTicksCntrInfo.captureTaskPtr = &s_taskDoNothing;
            s_myTicksCntrInfo.captureRegPtr  = &s_alwaysZero;
            break;
   }
   // Done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO TICKS CAPTURE NOW
*
*  Function forces a "Ticks Counter Capture" and returns the 32-bit value.
*/
static __INLINE uint32_t  CR_TicksCapture_Now( void)
{
   uint32_t  ticksValue;
   // Capture 'ticks' value by writing a '1' to activate Capture Task, 
   //    then reading captured value
   // NOTE: not all "capture registers" are set by a "capture task",
   //       so read "capture register" as early as possible.
   *(s_myTicksCntrInfo.captureTaskPtr) = 1u;
   __NOP();
   ticksValue = *(s_myTicksCntrInfo.captureRegPtr);
   return ticksValue;
}


/* ***************************************************************************
*  CORIANDOLO RADIO TIMEOUT COUNTER IS LEGAL
*/
static bool  CR_TimeoutCntr_IsLegal( const crhwtimer_t crTimerSelect)
{
   bool  isLegal;
   rtcptr_t  rtcPtr;
   rtcPtr = NRF51_RTC_GetPtr( crTimerSelect);
   if( rtcPtr != CONST_NULLPTR)
   {
      isLegal = true;
   }
   else
   {
      isLegal = false;
   }
   return isLegal;
}


/* ***************************************************************************
*  CORIANDOLO RADIO TIMEOUT COUNTER STOP
*
*  Stops the Timeout Cntr.
*  If the selection is not valid, nothing happens.
*/
static void  CR_TimeoutCntr_Stop( const crhwtimer_t crTimerSelect)
{
   NRF51_RTC_Interrupt_Disable( s_myCrHwTimer);
   NRF51_RTC_Stop( s_myCrHwTimer);
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO TIMEOUT COUNTER START
*
*  Starts the Timeout Cntr.
*  If the selection is not valid, nothing happens.
*/
static void  CR_TimeoutCntr_Start( const crhwtimer_t crTimerSelect)
{
   // Calculate Timeout Values -- assumes 32KHz clock for timeout timer
   CR_TimeoutValues_Calc( 30517uL /*nanoseconds-per-tick (32768Hz)*/);
   NRF51_RTC_Start( crTimerSelect);
   NRF51_RTC_Interrupt_Enable( crTimerSelect);
   // done
   return;
}


/* ***************************************************************************
*  CORIANDOLO RADIO TIMEOUT VALUES CALCULATE
*
*  Calculates timeout values in clock 'ticks'
*/
static void CR_TimeoutValues_Calc( uint32_t nanosecondsPerTick)
{
   s_timeoutValuesInTicks.radioListenFor1stMsgTimeout = 
         CR_Ticks_Calc( CONST_RADIO_LISTENFORANNOUNCE_TIMEOUT_NS, nanosecondsPerTick);
   s_timeoutValuesInTicks.radioListenForAddressTimeout = 
         CR_Ticks_Calc( CONST_RADIO_LISTENFORADDRESS_TIMEOUT_NS, nanosecondsPerTick);
   s_timeoutValuesInTicks.radioTxAddressTimeout = 
         CR_Ticks_Calc( CONST_RADIO_TX_ADDRESS_TIMEOUT_NS, nanosecondsPerTick);
   s_timeoutValuesInTicks.radioMessageCompleteTimeout = 
         CR_Ticks_Calc( CONST_RADIO_MESSAGE_COMPLETE_TIMEOUT_NS, nanosecondsPerTick);
   return;
}



/* ***************************************************************************/
/* ***************************************************************************
*  NRF RTC HARDWARE DRIVERS -- in alphabetical order
*/

/* ***************************************************************************
*  NRF51 RTC GET POINTER
*
*  This code returns a pointer to the RTC hardware registers.
*  This code supports only RTC1.
*/
static __INLINE rtcptr_t  NRF51_RTC_GetPtr( const crhwtimer_t crTimerSelect)
{
   rtcptr_t  rtcPtr;
   switch( crTimerSelect)
   {
      case eCRHWTIMER_RTC1:
            rtcPtr = NRF_RTC1;
            break;
      default:
            rtcPtr = CONST_NULLPTR;
            break;
   }
   return( rtcPtr);

}


/* ***************************************************************************
*  NRF51 RTC INTERRUPT DISABLE
*
*  Calls the interrupt disable procedure for selected CR Timer
*  This code supports only RTC1.
*/
static __INLINE void  NRF51_RTC_Interrupt_Disable( const crhwtimer_t crTimerSelect)
{
   switch( crTimerSelect)
   {
      case eCRHWTIMER_RTC1:
            IRQ_Disable( RTC1_IRQn);
            break;
      default:
            // do nothing
            break;
   }
   return;
}


/* ***************************************************************************
*  NRF51 RTC INTERRUPT ENABLE
*
*  Calls the interrupt enable procedure for selected CR Timer
*  This code supports only RTC1.
*
*  NOTE: RTC and the Radio are set at the same high priority so they will not
*        interrupt each other.
*/
static __INLINE void  NRF51_RTC_Interrupt_Enable( const crhwtimer_t crTimerSelect)
{
   switch( crTimerSelect)
   {
      case eCRHWTIMER_RTC1:
            IRQ_Enable( RTC1_IRQn, eIRQPRIORITY_HIGH);
            break;
      default:
            // do nothing
            break;
   }
   return;
}


/* ***************************************************************************
*  NRF51 RTC INTERRUPT PENDING CLEAR
*
*  This code calls the appropriate procedure to clear a pending interrupt for
*  the selected CR Timer.
*  This code supports only RTC1.
*/
static __INLINE void  NRF51_RTC_InterruptPending_Clr( const crhwtimer_t crTimerSelect)
{
   switch( crTimerSelect)
   {
      case eCRHWTIMER_RTC1:
            IRQ_ClearPending( RTC1_IRQn);
            break;
      default:
            // do nothing
            break;
   }
   return;
}


/* ***************************************************************************
*  NRF51 RTC CLEAR RADIO TIMEOUT
*
*  Clears the RTC Timeout using CC[0]
*  This code supports any RTC timer supported by "NRF51_RTC_GetPtr"
*/
static __INLINE void  NRF51_RTC_ClrRadioTimeout( const crhwtimer_t crTimerSelect)
{
   rtcptr_t  rtcPtr;
   rtcPtr = NRF51_RTC_GetPtr( crTimerSelect);
   if( rtcPtr != CONST_NULLPTR)
   {
      // Disable Interrupt on CC[0]
      rtcPtr->INTENCLR = (RTC_INTENCLR_COMPARE0_Enabled << RTC_INTENCLR_COMPARE0_Pos);
      // Clear pending interrupt, if any
      NRF51_RTC_InterruptPending_Clr( crTimerSelect);
      // Clear flag
      rtcPtr->EVENTS_COMPARE[0] = 0u;
   }
   // done
   return;
}


/* ***************************************************************************
*  NRF51 RTC SET RADIO TIMEOUT
*
*  Sets the RTC Timeout into CC[0] by adding 'ticksValue' to the current value
*  of the RTC Timer.  Then enables the "timeout" interrupt.
*  This code supports any RTC timer supported by "NRF51_RTC_GetPtr"
*/
static __INLINE void  NRF51_RTC_SetRadioTimeout( const crhwtimer_t crTimerSelect, 
                                                 const uint32_t  timeoutValue)
{
   rtcptr_t  rtcPtr;
   uint32_t  timeNow;
   rtcPtr = NRF51_RTC_GetPtr( crTimerSelect);
   if( rtcPtr != CONST_NULLPTR)
   {
      // Disable Interrupt on CC[0]
      rtcPtr->INTENCLR = (RTC_INTENCLR_COMPARE0_Enabled << RTC_INTENCLR_COMPARE0_Pos);
      // Clear pending interrupt, if any
      NRF51_RTC_InterruptPending_Clr( crTimerSelect);
      // Set the timeout
      timeNow = rtcPtr->COUNTER;
      rtcPtr->CC[0] = (timeNow + timeoutValue);
      // Clear flag
      rtcPtr->EVENTS_COMPARE[0] = 0u;
      // Enable Interrupt on CC[0]
      rtcPtr->INTENSET = (RTC_INTENSET_COMPARE0_Enabled << RTC_INTENSET_COMPARE0_Pos);
   }
   // done
   return;
}


/* ***************************************************************************
*  NRF51 RTC START
*
*  "Starts" the selected RTC timer.
*  This code supports any RTC timer supported by "NRF51_RTC_GetPtr"
*/
static void  NRF51_RTC_Start( const crhwtimer_t crTimerSelect)
{
   rtcptr_t  rtcPtr;
   rtcPtr = NRF51_RTC_GetPtr( crTimerSelect);
   if( rtcPtr != CONST_NULLPTR)
   {
      // Disable interrupts, events
      rtcPtr->INTENCLR = 0xFFFFFFFFuL;
      rtcPtr->EVTEN = 0uL;
      // Start the RTC module to run from 32KHz-divided-by-1
      // (the effective prescaler is 'PRESCALER' + 1)
      rtcPtr->PRESCALER = 0u;
      rtcPtr->TASKS_START = 1u;
   }
   // done
   return;
}


/* ***************************************************************************
*  NRF51 RTC STOP
*
*  "Stops" the selected RTC timer from counting
*  This code supports any RTC timer supported by "NRF51_RTC_GetPtr"
*/
static void  NRF51_RTC_Stop( const crhwtimer_t crTimerSelect)
{
   rtcptr_t  rtcPtr;
   rtcPtr = NRF51_RTC_GetPtr( crTimerSelect);
   if( rtcPtr != CONST_NULLPTR)
   {
      rtcPtr->TASKS_STOP = 1u;
   }
   // done
   return;
}



/** ***************************************************************************
*  INTERRUPT HANDLER FOR RTC1
*
*  Processes interrupts from RTC1 CC0 compare match as "timeout".
*  Clears flags if some other reason trigged the interrupt
*
*  @note
*  This is a very limited interrupt handler to trigger on CC[0] register 
*  compares.  It is used for Radio time-outs.
*/
void RTC1_IRQHandler(void)
{
   rtcptr_t  rtcPtr;
   // RTC Interrupt
   rtcPtr = NRF_RTC1;
   if( rtcPtr->EVENTS_COMPARE[0] != 0uL)
   {
      // RTC1 Compare[0] Event
      // This means a radio timeout has occurred
      // Clear the interrupt the flag
      rtcPtr->EVENTS_COMPARE[0] = 0uL;
      // Handle the TIMEOUT Event
      CR_ProtocolEvent_Timeout();
   }
   else
   {
      // This may occur if a Radio Timeout occurred, but was later cleared by
      // the radio code.  It may also occur if some other RTC Event was set 
      // by mistake.
      // Just in case, force the other event flags to zero.
      // NOTE: in some NRF51 parts RTC0 does not have an EVENT COMPARE[3]; 
      //       - the code will execute without error or fault.
      rtcPtr->EVENTS_COMPARE[1] = 0uL;
      rtcPtr->EVENTS_COMPARE[2] = 0uL;
      rtcPtr->EVENTS_COMPARE[3] = 0uL;
      rtcPtr->EVENTS_OVRFLW = 0uL;
      rtcPtr->EVENTS_TICK = 0uL;
   }
   // end-of-interrupt
}



/* ************** END OF FILE   CR_C *************************************** */

#ifndef _NRF51_CLOCK_H
#define _NRF51_CLOCK_H

/* ********************** FILE HEADER ****************************************
*  Created by Craig Goldman 2014-12-16
*
* Copyright 2014 64 Seconds Inc. as an unpublished work.
* All Rights Reserved.
*
* The following header listing and the binary program to which 
* it pertains are proprietary information of 64 Seconds Inc.
* All information contained here-in shall be considered
* company-confidential and may not be divulged in part or in
* whole, or in any way described, to any person without prior
* written permission of 64 Seconds Inc.
*
*  DESCRIPTION
*  This file is the public file for CLOCK inline procedure prototypes
*/


/* ***************************************************************************
*  DOCUMENTATION
*
*  The nRF51 device supports two clocks - HFCLK (the high-frequency clock) and
*  LFCLK (the low-frequency clock).
*
*  HFCLK
*  The high-frequency clock module generates multiple internal clock signals.
*  There are two potential sources to generate these internal clocks - an internal
*  16MHz RC oscilator or the HFCLK crystal oscillator.  The HFCLK crystal 
*  oscillator pins can be connected to a 16MHz AT-cut crystal, a 32MHz AT-cut
*  crystal or a 16MHz digital clock source.  On power-up the HFCLK module uses
*  the RC oscillator.  This oscillator automatically turns off when the crystal
*  is activated and automatically re-starts if the crystal is disabled.
*
*  The CR Radio Module hardware has a 16MHz crystal.  This should be "started"
*  by the programmer before the radio is used. The programmer should execute a
*  call to "Clock_HFClk_StartXtal" to activate the crystal.  There is a delay 
*  before the crystal is fully operational.  The application programmer should 
*  invoke "Clock_HFClk_WaitForStartUp" to make sure the external crystal is 
*  fully running.  When not transmitting or receiving, the Radio Module can
*  operate at lower power, but with less accurate timing by either not starting 
*  the crystal or invoking "Clock_HFClk_StopXtal" to stop the crystal oscillator.
*  If the crystal oscillator is "stopped", the internal RC oscillator will 
*  automatically start to support CPU and peripheral timing.
*
*  NOTE: This code supports only a 16MHz crystal (not a 32MHz crystal) as a 
*        source for HFCLK module.
*
*  LFCLK
*  There are three potential sources for the LFCLK - an internal RC oscillator,
*  a 32KHz clock created by dividing down the 16MHz clock and an external crystal.
*  The CR Radio Module hardware has a 32KHz crystal which the programmer should
*  consider using.  (It is very low power.)  The programmer should execute a
*  call to "Clock_LFClk_StartXtal" to activate the crystal.  The application 
*  programmer should invoke "Clock_LFClk_WaitForStartUp" to make sure the 
*  external crystal is fully running before using it for timing.
*  If the 32KHz crystal is not activated, this code will use the RC oscillator
*  by default.  The internal 32KHz RC oscillator may be calibrated using the
*  16MHz crystal, but this module does not provide support to do this.
*  SINCE THE 32KHz CRYSTAL HAS BEEN INCLUDED WITH THE HARDWARE, IT IS RECOMMENDED
*  THAT IT BE USED.
*/
/* ***************************************************************************
*  INCLUDE FILE
*/
#include <stdint.h>
#include "nrf51.h"
#include "nrf51_bitfields.h"


/* ***************************************************************************
*  PUBLIC TYPES
*/
typedef enum
{
   eCLKSOURCE_RC    = 0,
   eCLKSOURCE_XTAL  = 1
} clksource_t;


/* ***************************************************************************
*  PROTOTYPES FOR STATIC INLINE PROCEDURES
*/
static __INLINE void         nRF51_Clock_Init( void);
static __INLINE clksource_t  nRF51_Clock_HFCLK_Source_Get( void);
static __INLINE void         nRF51_Clock_HFClk_StartXtal( void);
static __INLINE void         nRF51_Clock_HFClk_StopXtal( void);
static __INLINE void         nRF51_Clock_HFClk_WaitForStartUp( void);
static __INLINE void         nRF51_Clock_LFClk_StartXtal( void);
static __INLINE void         nRF51_Clock_LFClk_WaitForStartUp( void);



/* ***************************************************************************
*  PUBLIC INLINE PROCEDURES
*/

static __INLINE void  nRF51_Clock_Init( void)
{
   // There are no static variables to initialize
   // Do nothing
   return;
}


static __INLINE clksource_t  nRF51_Clock_HFCLK_Source_Get( void)
{
   clksource_t  clkSource;
   uint32_t     maskedValue;
   maskedValue = (NRF_CLOCK->HFCLKSTAT & CLOCK_HFCLKSTAT_SRC_Msk);
   maskedValue = (maskedValue >> CLOCK_HFCLKSTAT_SRC_Pos);
   clkSource = (clksource_t)maskedValue;
   return clkSource;
}


static __INLINE void  nRF51_Clock_HFClk_StartXtal( void)
{
   // Set for 16MHz crystal
   NRF_CLOCK->XTALFREQ = CLOCK_XTALFREQ_XTALFREQ_16MHz;
   // Start high-frequency crystal oscillator 
   NRF_CLOCK->EVENTS_HFCLKSTARTED  = 0uL;
   NRF_CLOCK->TASKS_HFCLKSTART = 1uL;
   // Do not wait for start to complete
   return;
}


static __INLINE void  nRF51_Clock_HFClk_StopXtal( void)
{
   // Turn off HF Clock
   NRF_CLOCK->TASKS_HFCLKSTOP = 1uL;
   // Do not wait for stop to complete
   return;
}

static __INLINE void  nRF51_Clock_HFClk_WaitForStartUp( void)
{
   while( NRF_CLOCK->EVENTS_HFCLKSTARTED == 0uL);
   return;
}


static __INLINE void  nRF51_Clock_LFClk_StartXtal( void)
{
   // Start low-frequency crystal and use as source for LFCLK
   NRF_CLOCK->LFCLKSRC = CLOCK_LFCLKSRC_SRC_Xtal;
   NRF_CLOCK->EVENTS_LFCLKSTARTED = 0uL;
   NRF_CLOCK->TASKS_LFCLKSTART = 1uL;
   // Do not wait for start to complete
   return;
}

static __INLINE void  nRF51_Clock_LFClk_WaitForStartUp( void)
{
   while( NRF_CLOCK->EVENTS_LFCLKSTARTED == 0uL);
   return;
}


#endif /* ifndef _NRF51_CLOCK_H */

/* ************** END OF FILE   _NRF51_CLOCK_H* ***************************** */

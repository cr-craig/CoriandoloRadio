var searchData=
[
  ['uart_5fenable',['UART_Enable',['../_u_a_r_t_8c.html#acd0afa9164610f7048c1f740ee65217c',1,'UART_Enable(volatile uarthardware_t *uarthwPtr, const uartconfig_t *uartConfigPtr):&#160;UART.c'],['../_u_a_r_t_8h.html#acd0afa9164610f7048c1f740ee65217c',1,'UART_Enable(volatile uarthardware_t *uarthwPtr, const uartconfig_t *uartConfigPtr):&#160;UART.c']]],
  ['uart_5finit',['UART_Init',['../_u_a_r_t_8c.html#ad5cbed2a2222bb84e8b5c1caaa50634e',1,'UART_Init(void):&#160;UART.c'],['../_u_a_r_t_8h.html#ad5cbed2a2222bb84e8b5c1caaa50634e',1,'UART_Init(void):&#160;UART.c']]]
];

var searchData=
[
  ['announcementtries',['announcementTries',['../structcrstateinfo__t.html#a8710f563afe132afff7cd88cefa687be',1,'crstateinfo_t']]]
];

var searchData=
[
  ['msgflagsbyte',['msgFlagsByte',['../structcrbufrinfo__t.html#af0e31719f54d271b294216acca54a3d9',1,'crbufrinfo_t']]]
];
